// modules/1_sessiebeheer.js

import { verkoopManager } from './16_VerkoopManager.js';
import { loadData, db } from './3_data.js';
import { toonVerkoopKnoppen } from './8_verkoopscherm.js';

// Module-interne state, geen globale 'window' objecten meer.
let actieveSessieRef = null; // { eventKey, sessieId }
let actieveSessie = null;

const SESSIE_REF_KEY = 'actieveSessieRef';

// ---------- helpers ----------

/** * Slaat de referentie naar de actieve sessie op in de module en localStorage.
 * Deze wordt geëxporteerd omdat andere modules (zoals 2_sessieherstel.js) deze mogelijk nodig hebben.
 */
export function setActieveSessieRef(eventKey, sessieId) {
  actieveSessieRef = { eventKey: String(eventKey), sessieId: String(sessieId) };
  try {
    localStorage.setItem(SESSIE_REF_KEY, JSON.stringify(actieveSessieRef));
  } catch (e) {
    console.warn('Kon actieveSessieRef niet opslaan:', e);
  }
}

/** Maakt de actieve sessie referentie leeg. */
function clearActieveSessieRef() {
  actieveSessieRef = null;
  actieveSessie = null;
  try {
    localStorage.removeItem(SESSIE_REF_KEY);
  } catch (e) {
    console.warn('Kon actieveSessieRef niet verwijderen:', e);
  }
}

/** Leest de opgeslagen sessie referentie uit localStorage. */
function readStoredRef() {
  try {
    const raw = localStorage.getItem(SESSIE_REF_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    console.warn('Kon actieveSessieRef niet lezen:', e);
    return null;
  }
}

/** Haalt unieke event keys uit de lokale database als fallback. */
function uniqueKeysFromDb() {
  if (!db?.evenementen) return [];
  
  const keys = db.evenementen.map(ev => String(ev?.id || ev?.naam || '').trim());
  // Gebruik een Set voor snelle en efficiënte de-duplicatie.
  return [...new Set(keys.filter(k => k))];
}


// ---------- sessie beheer ----------

/**
 * Start een nieuwe verkoopsessie.
 * Bij een fout wordt teruggevallen op een lokale (offline) sessie.
 */
export async function startSession(eventKey, meta = {}) {
  try {
    const sessie = await verkoopManager.createSession(eventKey, meta);
    actieveSessie = sessie;
    setActieveSessieRef(eventKey, sessie.id);
  } catch (err) {
    // Fallback: lokale sessie
    const fakeId = `local-${Date.now()}`;
    actieveSessie = {
      id: fakeId,
      eventKey: String(eventKey),
      startTime: new Date().toISOString(),
      endTime: 'OPEN',
      meta: meta
    };
    setActieveSessieRef(eventKey, fakeId);
    console.warn(`ℹ️ createSession niet beschikbaar; lokale sessie gestart: ${fakeId}`, err);
  }
  toonVerkoopKnoppen();
}

/**
 * Sluit de momenteel actieve sessie.
 */
export async function closeActiveSession() {
  if (!actieveSessieRef) {
    console.warn('Geen actieve sessie om te sluiten.');
    return;
  }

  const { eventKey, sessieId } = actieveSessieRef;

  try {
    // Probeer de sessie server-side te sluiten.
    await verkoopManager.closeSession(eventKey, sessieId);
  } catch (err) {
    console.warn(`ℹ️ closeSession niet beschikbaar; lokale sessie wordt gewist.`, err);
  } finally {
    // Ruim altijd de lokale referentie op, ongeacht het resultaat.
    clearActieveSessieRef();
    toonVerkoopKnoppen();
  }
}

/**
 * Controleert bij de start of er een opgeslagen sessie is en herstelt deze indien nog geldig.
 */
async function initializeSession() {
  const ref = readStoredRef();
  if (!ref || !ref.eventKey) { // Extra check op eventKey
    if(ref) {
        console.warn('Opgeslagen sessie referentie is corrupt (geen eventKey), wordt opgeruimd.');
        clearActieveSessieRef();
    } else {
        console.log('ℹ️ Geen opgeslagen sessie gevonden.');
    }
    return;
  }

  try {
    const sessie = await verkoopManager.getSession(ref.eventKey, ref.sessieId);
    // Herstel alleen als de sessie op de server nog steeds open is.
    if (sessie && String(sessie.endTime) === 'OPEN') {
      actieveSessieRef = ref;
      actieveSessie = sessie;
      console.log(`✅ Actieve sessie ${ref.sessieId} hersteld voor event ${ref.eventKey}`);
    } else {
      console.log('ℹ️ Opgeslagen sessie is niet meer OPEN, wordt opgeruimd.');
      clearActieveSessieRef();
    }
  } catch (error) {
    console.warn('ℹ️ Opgeslagen sessie kon niet worden opgehaald, wordt opgeruimd.', error);
    clearActieveSessieRef();
  }
}


// ---------- app init ----------

/**
 * Initialiseert de applicatie: checkt auth, laadt data en herstelt een eventuele sessie.
 */
export async function initApp() {
  try {
    // 1. Authenticatie check
    if (!localStorage.getItem('gebruiker')) {
      window.location.href = '/login.html';
      return; // Stop de executie
    }

    // 2. Basisdata laden
    await loadData();

    // 3. Lijst van evenementen ophalen (met fallback naar lokale DB)
    let keys = [];
    try {
      // Geef de voorkeur aan de server-lijst
      keys = await verkoopManager.listEvents();
    } catch {
      console.warn("Kon event lijst niet van server halen, fallback naar lokale DB.");
      keys = uniqueKeysFromDb();
    }
    
    // 4. Manifesten "warmen" (parallel ophalen, falen is geen ramp)
    if (keys && keys.length > 0) {
        const manifestPromises = keys.map(k =>
            verkoopManager.getManifest(k).catch(e => {
                console.warn(`Manifest ophalen mislukt voor ${k}`, e);
                return null; // Zorgt dat Promise.all niet faalt op een enkele error
            })
        );
        await Promise.all(manifestPromises);
    }

    // 5. Sessie herstellen (de nieuwe, gecombineerde functie)
    await initializeSession();

    // 6. UI updaten na succesvolle initialisatie
    toonVerkoopKnoppen();

  } catch (e) {
    console.error('Fatale fout tijdens initialisatie:', e);
    // Optioneel: toon een foutmelding aan de gebruiker in de UI
  }
}

// ---------- auto-start ----------
initApp();


// ---------- exports voor externe modules ----------
// Andere modules kunnen de status lezen zonder deze direct te kunnen wijzigen.
export const getActieveSessie = () => actieveSessie;
export const getActieveSessieRef = () => actieveSessieRef;

// Exporteer ook clearActieveSessieRef voor het geval een andere module die nodig heeft.
export { clearActieveSessieRef };