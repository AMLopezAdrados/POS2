// 📦 8_verkoopscherm.js — Verkoopscherm met basket + directe verkoop + voorraadbeheer

import { db, saveVoorraad } from './3_data.js';
import { showAlert } from './4_ui.js';
import { verkoopManager } from './16_VerkoopManager.js';

let basket = [];
let basketMode = false;
let clickBlocked = false;

// ====== Publieke API ======
export function toonVerkoopKnoppen() {
  const container = document.getElementById('verkoop-container');
  if (!container) return;

  container.innerHTML = '';

  const producten = db.producten || [];
  producten.forEach(prod => {
    const voorraad = getVoorraad(prod.id);
    const btn = document.createElement('button');
    btn.className = 'verkoop-btn';
    btn.textContent = `${prod.naam} (${voorraad})`;

    btn.addEventListener('click', () => handleVerkoopClick(prod));
    container.appendChild(btn);
  });

  renderBasketPanel();
}

export function toggleBasketMode() {
  basketMode = !basketMode;
  basket = [];
  toonVerkoopKnoppen();
  showAlert(basketMode ? '🧺 Basket modus aan' : '🧺 Basket modus uit');
}

// ====== Click handling ======
async function handleVerkoopClick(prod) {
  if (clickBlocked) return;
  blockClicks();

  try {
    if (basketMode) {
      basket.push(prod);
      renderBasketPanel();
    } else {
      await doeVerkoop(prod);
    }
  } catch (err) {
    console.error('❌ Fout bij verkoop:', err);
    showAlert('❌ Verkoop mislukt', 'error');
  } finally {
    unblockClicks();
  }
}

async function doeVerkoop(prod) {
  const sessie = getActieveSessie();
  if (!sessie) {
    showAlert('⚠️ Geen actieve sessie', 'warning');
    return;
  }

  const eventNaam = resolveEventNaam(sessie);
  const verkoop = {
    product: prod.naam,
    prijs_usd: Number(prod.prijs_usd) || 0,
    prijs_eur: null,
    tijd: new Date().toISOString(),
    type: 'verkoop'
  };

  await verkoopManager.addSale(eventNaam, sessie.id, verkoop);

  // voorraad verminderen
  updateVoorraad(prod.id, -1);
  await saveVoorraad();

  showAlert(`✅ Verkocht: ${prod.naam}`, 'success');
  toonVerkoopKnoppen();
}

// ====== Basket ======
export async function bevestigBasket() {
  const sessie = getActieveSessie();
  if (!sessie) { showAlert('⚠️ Geen actieve sessie'); return; }
  if (basket.length === 0) { showAlert('🧺 Mandje leeg'); return; }

  const eventNaam = resolveEventNaam(sessie);

  const verkopen = basket.map(p => ({
    product: p.naam,
    prijs_usd: Number(p.prijs_usd) || 0,
    prijs_eur: null,
    tijd: new Date().toISOString(),
    type: 'verkoop'
  }));

  await Promise.all(verkopen.map(v => verkoopManager.addSale(eventNaam, sessie.id, v)));

  // voorraad verminderen
  basket.forEach(p => updateVoorraad(p.id, -1));
  await saveVoorraad();

  showAlert(`✅ Basket bevestigd (${basket.length} items)`, 'success');
  basket = [];
  toonVerkoopKnoppen();
}

function renderBasketPanel() {
  const panel = document.getElementById('basket-panel');
  if (!panel) return;

  panel.innerHTML = '';
  if (!basketMode) { panel.style.display = 'none'; return; }
  panel.style.display = 'block';

  const ul = document.createElement('ul');
  basket.forEach((p, i) => {
    const li = document.createElement('li');
    li.textContent = p.naam;
    const rm = document.createElement('button');
    rm.textContent = '❌';
    rm.className = 'rm-btn';
    rm.addEventListener('click', () => {
      basket.splice(i, 1);
      renderBasketPanel();
    });
    li.appendChild(rm);
    ul.appendChild(li);
  });
  panel.appendChild(ul);

  const confirm = document.createElement('button');
  confirm.textContent = '✅ Bevestig basket';
  confirm.className = 'btn-green';
  confirm.addEventListener('click', bevestigBasket);
  panel.appendChild(confirm);
}

// ====== Helpers ======
function getActieveSessie() {
  return window.actieveSessieRef?.sessie || null;
}
function resolveEventNaam(sessie) {
  return window.actieveSessieRef?.event?.naam || (sessie.eventNaam ?? 'onbekend');
}
function getVoorraad(prodId) {
  return (db.voorraad?.[prodId]?.aantal) ?? 0;
}
function updateVoorraad(prodId, delta) {
  if (!db.voorraad) db.voorraad = {};
  if (!db.voorraad[prodId]) db.voorraad[prodId] = { aantal: 0 };
  db.voorraad[prodId].aantal += delta;
}

// ====== Click-blocker ======
function blockClicks() {
  clickBlocked = true;
  document.body.classList.add('click-blocked');
  setTimeout(unblockClicks, 800); // failsafe
}
function unblockClicks() {
  clickBlocked = false;
  document.body.classList.remove('click-blocked');
}

// ====== Styles ======
injectStylesOnce();
function injectStylesOnce() {
  if (document.getElementById('verkoopStyles')) return;
  const css = document.createElement('style');
  css.id = 'verkoopStyles';
  css.textContent = `
    .verkoop-btn {
      display:inline-block; margin:.3rem; padding:.6rem 1rem;
      font-size:1rem; border-radius:12px; border:1px solid #ccc;
      background:#fefefe; cursor:pointer;
    }
    .verkoop-btn:hover { background:#f7f7f7; }
    #basket-panel { margin-top:1rem; padding:.5rem; border:1px solid #ddd; border-radius:12px; background:#fafafa; }
    #basket-panel ul { list-style:none; padding:0; margin:0 0 .5rem 0; }
    #basket-panel li { display:flex; justify-content:space-between; align-items:center; padding:.25rem 0; }
    .rm-btn { background:#ffebee; border:1px solid #f5c6cb; border-radius:8px; cursor:pointer; padding:.2rem .5rem; }
    .btn-green { background:#2A9626; color:#fff; border:none; border-radius:10px; padding:.45rem .7rem; font-weight:900; cursor:pointer; }
    body.click-blocked { pointer-events:none; }
  `;
  document.head.appendChild(css);
}