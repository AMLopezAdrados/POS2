// modules/16_VerkoopManager.js

const BASE = 'https://olgascheese.net/api/verkopen';
const LS_KEY = 'vm_local_sessions_v1';

// ---------- Caching ----------
// Eenvoudige in-memory caches om herhaalde requests te voorkomen.
const manifestCache = new Map();
const sessionsIndexCache = new Map();
const sessionCache = new Map();

// ---------- Utils ----------

const encodeSeg = (seg) => encodeURIComponent(String(seg ?? '').replace(/\/+/g, '').trim());

const makePaths = (eventKey) => {
  const k = encodeSeg(eventKey);
  const root = `${BASE}/${k}`;
  return {
    root,
    manifest: `${root}/manifest.json`,
    sessionsIndex: `${root}/sessions/index.json`,
    sessionFile: (id) => `${root}/sessions/${encodeSeg(id)}.json`,
  };
};

/**
 * Voert een fetch request uit en gooit een error als de status niet ok is.
 * Behandelt 404 als een 'niet gevonden' en retourneert null.
 */
async function tryJson(url) {
  try {
    const response = await fetch(url, { cache: 'no-cache' });
    if (response.status === 404) {
      return null; // Bestand niet gevonden, dit is een verwachte situatie.
    }
    if (!response.ok) {
      throw new Error(`HTTP ${response.status} voor ${url}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Fetch error voor ${url}:`, error);
    throw error; // Gooi de error door zodat de aanroeper erop kan reageren.
  }
}

// ---------- localStorage Helpers ----------

const readLS = () => {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
};

const writeLS = (obj) => {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(obj ?? {}));
  } catch (e) {
    console.warn('Kon niet naar localStorage schrijven:', e);
  }
};

const lsGet = (eventKey, id) => readLS()[eventKey]?.[id] ?? null;

const lsSet = (eventKey, sessionObj) => {
  const all = readLS();
  if (!all[eventKey]) {
    all[eventKey] = {};
  }
  all[eventKey][sessionObj.id] = sessionObj;
  writeLS(all);
};

const lsClose = (eventKey, id) => {
  const all = readLS();
  if (all[eventKey]?.[id]) {
    all[eventKey][id].endTime = new Date().toISOString();
    writeLS(all);
  }
};

// ---------- API Functies ----------

/** Genereert een standaard fallback manifest. */
const createFallbackManifest = (eventKey) => ({
  id: eventKey,
  naam: eventKey,
  versie: 1,
  createdAt: new Date().toISOString(),
});

export async function getManifest(eventKey) {
  const key = String(eventKey);
  if (manifestCache.has(key)) {
    return manifestCache.get(key);
  }

  const { manifest: manifestUrl } = makePaths(key);
  try {
    const manifest = await tryJson(manifestUrl);
    const result = manifest ?? createFallbackManifest(key);
    manifestCache.set(key, result);
    return result;
  } catch {
    // Bij een netwerkfout, retourneer ook de fallback.
    const fallback = createFallbackManifest(key);
    manifestCache.set(key, fallback);
    return fallback;
  }
}

export async function getSessionsIndex(eventKey) {
  const key = String(eventKey);
  if (sessionsIndexCache.has(key)) {
    return sessionsIndexCache.get(key);
  }

  const { sessionsIndex: idxUrl } = makePaths(key);
  try {
    const json = await tryJson(idxUrl);
    // Zorg ervoor dat we altijd een array teruggeven.
    const sessions = Array.isArray(json) ? json : (json?.sessions ?? []);
    sessionsIndexCache.set(key, sessions);
    return sessions;
  } catch {
    return []; // Bij fouten, retourneer een lege lijst.
  }
}

export async function getSession(eventKey, sessieId) {
  const key = String(eventKey);
  const id = String(sessieId);
  const cacheKey = `${key}::${id}`;

  if (sessionCache.has(cacheKey)) {
    return sessionCache.get(cacheKey);
  }

  // Eerst lokaal checken (offline-first).
  const localSession = lsGet(key, id);
  if (localSession) {
    sessionCache.set(cacheKey, localSession);
    return localSession;
  }

  // Dan via het netwerk.
  const url = makePaths(key).sessionFile(id);
  const networkSession = await tryJson(url);
  if (networkSession) {
    sessionCache.set(cacheKey, networkSession);
  }
  return networkSession;
}

export async function getSessions(eventKey) {
  const ids = await getSessionsIndex(eventKey);
  if (!ids.length) {
    return [];
  }

  // Vraag alle sessies parallel op.
  const sessionPromises = ids.map(id => getSession(eventKey, id));
  const sessions = await Promise.all(sessionPromises);

  // Filter eventuele null-resultaten (sessies die niet gevonden werden).
  return sessions.filter(s => s !== null);
}

// ---------- API: Mutaties (lokaal) ----------

export function createSession(eventKey, meta = {}) {
  const key = String(eventKey);
  const now = new Date();
  const id = now.toISOString().replace(/[:.]/g, '-');
  const sessie = {
    id,
    eventKey: key,
    startTime: now.toISOString(),
    endTime: 'OPEN',
    meta,
    verkopen: [],
  };

  lsSet(key, sessie);
  sessionCache.set(`${key}::${id}`, sessie);
  return sessie; // Direct returnen, geen Promise nodig.
}

export function closeSession(eventKey, sessieId) {
  const key = String(eventKey);
  const id = String(sessieId);
  const cacheKey = `${key}::${id}`;

  lsClose(key, id);

  // Werk de in-memory cache bij als die bestaat.
  if (sessionCache.has(cacheKey)) {
    sessionCache.get(cacheKey).endTime = new Date().toISOString();
  }
  return true; // Direct returnen.
}

// ---------- Bundel Loader ----------

export async function load(eventKey, withSessions = true) {
  const manifestPromise = getManifest(eventKey);
  const sessionsPromise = withSessions ? getSessions(eventKey) : Promise.resolve([]);

  const [manifest, sessions] = await Promise.all([manifestPromise, sessionsPromise]);
  return { manifest, sessions: sessions ?? [] };
}

// ---------- Legacy Shims (onveranderd) ----------
const rootHas = () => Promise.resolve(true);
const fetchRootOnce = () => Promise.resolve(true);

// ---------- Public Export ----------
// Bundel alle functies in een enkel object voor compatibiliteit met de bestaande architectuur.
export const verkoopManager = {
  getManifest,
  getSessionsIndex,
  getSessions,
  getSession,
  // Pas create/close session aan om een resolved Promise te returnen voor 100% compatibiliteit.
  createSession: (...args) => Promise.resolve(createSession(...args)),
  closeSession: (...args) => Promise.resolve(closeSession(...args)),
  load: (eventKey) => load(eventKey, true),
  rootHas,
  fetchRootOnce,
};