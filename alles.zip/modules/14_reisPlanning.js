// modules/14_reisPlanning.js
// Reisplanner — maandkalender + twee wizards (Voorraad & Beschikbaarheid) + quick-edit

import { db, saveEvent, saveReizen } from './3_data.js';
import { showAlert } from './4_ui.js';

// ================= Public API =================
export function openReisPlannerModal() {
  _closeAllModals();

  const overlay = document.createElement('div');
  overlay.className = 'modal rp-modal';

  const shell = document.createElement('div');
  shell.className = 'rp-shell';
  overlay.appendChild(shell);

  const header = _buildHeader();
  shell.appendChild(header.bar);

  const cal = _buildCalendar(() => {
    header.planStock.disabled   = !(selStart && selEnd);
    header.planSuggest.disabled = !(selStart && selEnd);
    _updateTitle();
  });
  shell.appendChild(cal.wrap);

  // Header actions
  header.prev.onclick  = () => { _shiftMonth(-1); cal.renderMonth(currentYear, currentMonth); };
  header.next.onclick  = () => { _shiftMonth(+1); cal.renderMonth(currentYear, currentMonth); };
  header.today.onclick = () => { const d=new Date(); currentYear=d.getFullYear(); currentMonth=d.getMonth(); cal.renderMonth(currentYear,currentMonth); };
  header.close.onclick = _closeAllModals;

  header.planStock.onclick   = () => selStart && selEnd && _wizardVoorraad(selStart, selEnd);
  header.planSuggest.onclick = () => selStart && selEnd && _wizardSuggesties(selStart, selEnd);
  header.avail.onclick       = () => _wizardBeschikbaarheid();
  header.newEvt.onclick      = async () => {
    try { const { openEventScheduleModal } = await import('./15_eventSchedule.js'); openEventScheduleModal(true); }
    catch { showAlert('Kan nieuw evenement formulier niet openen.', 'error'); }
  };

  // Init kalender
  const now = new Date();
  currentYear  = now.getFullYear();
  currentMonth = now.getMonth();
  cal.renderMonth(currentYear, currentMonth);

  _injectPlannerCSS();
  document.body.appendChild(overlay);
}

// Exporteer wizards (optioneel bruikbaar buitenom)
export function openVoorraadPlanningForSelection(a,b){ return _wizardVoorraad(a,b); }
export function openSuggestiesForSelection(a,b){ return _wizardSuggesties(a,b); }
export function openBeschikbaarheidWizard(){ return _wizardBeschikbaarheid(); }

// ================= Module state =================
let currentYear = 0;
let currentMonth = 0;
let selStart = null;
let selEnd   = null;

// ================= Header & Kalender =================
function _buildHeader(){
  const bar = document.createElement('div');
  bar.className = 'rp-header';

  const left = document.createElement('div'); left.className = 'rp-h-left';
  const prev  = _btn('◀','amber');
  const today = _btn('Vandaag','blue');
  const next  = _btn('▶','amber');
  left.append(prev,today,next);

  const mid  = document.createElement('div'); mid.id='rp-title'; mid.className='rp-h-title';

  const right = document.createElement('div'); right.className='rp-h-right';
  const planStock   = _btn('📦 Voorraadplanning','green'); planStock.disabled = true;
  const planSuggest = _btn('💡 Suggesties','blue');        planSuggest.disabled = true;
  const avail       = _btn('🗓️ Beschikbaarheid','indigo');
  const newEvt      = _btn('➕ Nieuw evenement','amber');
  const close       = _btn('✕','red');
  right.append(planStock, planSuggest, avail, newEvt, close);

  bar.append(left, mid, right);
  return { bar, prev, today, next, planStock, planSuggest, avail, newEvt, close };
}

function _updateTitle(){
  const t = document.getElementById('rp-title');
  if(!t) return;
  t.textContent = `${_monthName(currentMonth)} ${currentYear}` + (selStart&&selEnd?` • ${selStart} → ${selEnd}`:'');
}

function _buildCalendar(onSelectionChange){
  const wrap = document.createElement('div'); wrap.className='rp-cal-wrap';

  const wd = document.createElement('div'); wd.className='rp-weekdays';
  ['M','T','W','T','F','S','S'].forEach(d=>{ const c=document.createElement('div'); c.textContent=d; wd.appendChild(c); });

  const grid = document.createElement('div'); grid.className='rp-grid';
  wrap.append(wd, grid);

  function renderMonth(y,m){
    selStart=null; selEnd=null; onSelectionChange?.();
    grid.innerHTML=''; _updateTitle();

    const first = new Date(y,m,1);
    const firstIdx = (first.getDay()+6)%7;
    const days = new Date(y,m+1,0).getDate();

    const cells=[];
    for(let i=0;i<42;i++){
      const dNum = i-firstIdx+1;
      const inMonth = dNum>=1 && dNum<=days;
      const cell = document.createElement('div');
      cell.className = `rp-cell${inMonth?'':' dim'}`;

      if(inMonth){
        const dateStr = _iso(y,m,dNum);
        cell.dataset.date = dateStr;

        const dn = document.createElement('div'); dn.className='rp-daynum'; dn.textContent=dNum;
        cell.appendChild(dn);

        cell.addEventListener('click', ()=>{
          if(!selStart || (selStart&&selEnd)){ selStart=dateStr; selEnd=null; }
          else{ selEnd=dateStr; if(selEnd<selStart)[selStart,selEnd]=[selEnd,selStart]; }
          cells.forEach(c=>{
            const d = c.dataset.date;
            c.classList.toggle('selected', selStart&&!selEnd && d===selStart);
            c.classList.toggle('inrange',  selStart&&selEnd  && d>=selStart && d<=selEnd);
          });
          onSelectionChange?.(); _updateTitle();
        });
      }

      grid.appendChild(cell); cells.push(cell);
    }

    _renderEventsInto(cells,y,m);
  }

  return { wrap, renderMonth };
}

function _renderEventsInto(cells,y,m){
  const monthStart = _iso(y,m,1);
  const monthEnd   = _iso(y,m,new Date(y,m+1,0).getDate());

  (db.evenementen||[]).forEach(evt=>{
    if(!evt.startdatum || !evt.einddatum) return;

    const start = _maxDate(evt.startdatum, monthStart);
    const eind  = _minDate(evt.einddatum,  monthEnd);
    if(start>eind) return;

    const locColor = _locColor(evt.locatie);
    const perColor = _personColor(evt.personen);

    for(let d=new Date(start); d<=new Date(eind); d.setDate(d.getDate()+1)){
      const key = _iso(d.getFullYear(), d.getMonth(), d.getDate());
      const cell = cells.find(c=>c.dataset.date===key);
      if(!cell) continue;
      const mark = document.createElement('div');
      mark.className='rp-fill';
      mark.style.setProperty('--loc', locColor);
      mark.style.setProperty('--per', perColor);
      cell.appendChild(mark);
    }

    const firstCell = cells.find(c=>c.dataset.date===start);
    if(firstCell){
      const tag = document.createElement('div');
      tag.className='rp-tag';
      tag.textContent = evt.naam||'';
      tag.style.background = locColor;
      tag.title = `${evt.naam||''}\n${evt.locatie||''}\n${evt.startdatum} → ${evt.einddatum}`;
      tag.onclick = ()=> _openQuickEdit(evt);
      firstCell.appendChild(tag);
    }
  });
}

// ================= Wizard 1: Periode → Voorraad =================
function _wizardVoorraad(aStart, aEnd){
  const events = (db.evenementen||[]).filter(e => _rangesOverlap(aStart,aEnd,e.startdatum,e.einddatum));

  _modal(()=>{
    const box = document.createElement('div');
    box.appendChild(_h2(`📦 Voorraadplanning (${_fmt(aStart)} → ${_fmt(aEnd)})`));

    if(!events.length){
      box.appendChild(_p('Geen evenementen in de gekozen periode.'));
      return box;
    }

    const busRow = document.createElement('div'); busRow.className='rp-line';
    const busLab = document.createElement('label'); busLab.className='rp-lab'; busLab.textContent='Bus';
    const busSel = document.createElement('select');
    Object.keys(db.voorraad||{}).forEach(b=> busSel.append(new Option(b,b)));
    busRow.append(busLab,busSel);
    box.append(busRow);

    const table = document.createElement('table'); table.className='rp-table';
    table.innerHTML = `
      <thead>
        <tr><th>Event</th><th>Locatie</th><th>Start</th><th>Einde</th><th style="text-align:right">$ Omzet</th></tr>
      </thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody');
    const inputs=[];

    events.forEach(evt=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${_esc(evt.naam||'-')}</td>
        <td>${_esc(evt.locatie||'-')}</td>
        <td>${_fmt(evt.startdatum)}</td>
        <td>${_fmt(evt.einddatum)}</td>
        <td style="text-align:right"></td>
      `;
      const inp=document.createElement('input');
      inp.type='number'; inp.step='1'; inp.style.cssText='width:120px;text-align:right';
      inp.value=String(_estimateUSD(evt));
      tr.children[4].appendChild(inp);
      inputs.push({evt,inp});
      tbody.appendChild(tr);
    });
    box.append(table);

    const total = document.createElement('div'); total.className='rp-total'; box.append(total);
    const updateTotal = ()=>{ const s=inputs.reduce((t,r)=>t+(parseFloat(r.inp.value)||0),0); total.textContent=`Totaal: $${s.toFixed(2)}`; };
    inputs.forEach(r=>r.inp.addEventListener('input', updateTotal)); updateTotal();

    box.append(_cta([
      ['❌ Sluiten','red', _closeAllModals],
      ['Bereken benodigdheden →','green', ()=>{
        const omzetData = inputs.map(r=>({
          eventId:r.evt.id, naam:r.evt.naam, locatie:r.evt.locatie, type:r.evt.type,
          bus: busSel.value || r.evt.bus || '',
          start:r.evt.startdatum, eind:r.evt.einddatum,
          bedrag: parseFloat(r.inp.value) || 0
        }));
        _closeAllModals();
        _wizardVoorraadStap2(aStart, aEnd, omzetData);
      }]
    ]));
    return box;
  });
}

function _wizardVoorraadStap2(aStart, aEnd, omzetData){
  const mix     = _weightsFromHistory();
  const budget  = omzetData.reduce((s,e)=>s+e.bedrag,0) * 1.1;
  const bus     = omzetData[0]?.bus || Object.keys(db.voorraad||{})[0] || '';
  const voorraad = db.voorraad?.[bus] || {};

  const suggest = (db.producten||[])
    .filter(p=>['BG','GEIT','ROOK'].includes(p.type))
    .map(p=>{
      const w = mix[p.naam] || 0;
      const usd = p.usd || 1;
      const stuks = Math.max(0, Math.round((budget*w)/usd));
      const cap = _capacity(p.naam);
      const tekort = Math.max(0, stuks - (voorraad[p.naam]||0));
      return { naam:p.naam, usd, cap, tekort, eenheden: Math.ceil(tekort/cap) };
    });

  _modal(()=>{
    const box=document.createElement('div');
    box.appendChild(_h2(`📦 Benodigdheden — Bus ${bus}`));
    box.appendChild(_p(`Totale omzet (incl. 10% buffer): $${budget.toFixed(2)}.`));

    const tbl=document.createElement('table'); tbl.className='rp-table';
    tbl.innerHTML=`
      <thead>
        <tr><th>Product</th><th style="text-align:center">Cap.</th><th style="text-align:right">Tekort (st)</th><th style="text-align:center">Kratten/Dozen</th></tr>
      </thead><tbody></tbody>`;
    const tb=tbl.querySelector('tbody');

    const rows=suggest.map(s=>{
      const tr=document.createElement('tr');
      tr.innerHTML=`
        <td>${_esc(s.naam)}</td>
        <td style="text-align:center">${s.cap}</td>
        <td style="text-align:right">${s.tekort}</td>
        <td style="text-align:center"></td>`;
      const minus=_btn('−','amber'), plus=_btn('+','amber');
      const q=document.createElement('span'); q.textContent=String(s.eenheden); q.style.cssText='display:inline-block;min-width:2ch;text-align:center';
      minus.onclick=()=>{ q.textContent=String(Math.max(0, parseInt(q.textContent)-1)); };
      plus.onclick =()=>{ q.textContent=String(parseInt(q.textContent)+1); };
      const ctrl=document.createElement('div'); ctrl.style.cssText='display:inline-flex;gap:.35rem;align-items:center';
      ctrl.append(minus,q,plus);
      tr.children[3].appendChild(ctrl);
      tb.appendChild(tr);
      return { s, getUnits:()=>parseInt(q.textContent) };
    });

    box.appendChild(tbl);

    box.append(_cta([
      ['← Terug','blue', ()=>{ _closeAllModals(); _wizardVoorraad(aStart, aEnd); }],
      ['✅ Bevestig voorstel','green', async ()=>{
        // Plaats voor echte opslag/paklijst; nu feedback + close
        _closeAllModals();
        showAlert('✅ Voorraadvoorstel bevestigd (simulatie).', 'success');
      }]
    ]));
    return box;
  });
}

// ================= Wizard 2: Beschikbaarheid (lege periodes) =================
function _wizardBeschikbaarheid(){
  // Bepaal bezette periodes per persoon
  const persons = ['Olga','Alberto'];
  const perPers = persons.map(p => ({
    naam: p,
    occupied: (db.evenementen||[])
      .filter(e => (e.personen||[]).includes(p))
      .map(e => ({ start:e.startdatum, eind:e.einddatum, loc:e.locatie, naam:e.naam }))
      .sort((a,b)=> new Date(a.start)-new Date(b.start))
  }));

  // Construeer vrije slots in de komende ~120 dagen
  const today = _fmt(new Date().toISOString().slice(0,10));
  const horizon = _fmt(_isoAddDays(today, 120));
  const free = perPers.map(pp => ({ naam:pp.naam, slots:_freeSlots(pp.occupied, today, horizon) }));

  _modal(()=>{
    const box=document.createElement('div');
    box.appendChild(_h2('🗓️ Beschikbaarheid & opties'));

    free.forEach(pp=>{
      const h = document.createElement('h3'); h.className='rp-sub'; h.textContent = pp.naam; box.appendChild(h);
      if(!pp.slots.length){ box.appendChild(_p('Geen vrije periodes in de komende 120 dagen.')); return; }

      pp.slots.forEach(slot=>{
        const card=document.createElement('div'); card.className='rp-card';
        const head=document.createElement('div'); head.className='rp-card-head';
        head.innerHTML = `<b>${slot.start} → ${slot.eind}</b> (${slot.days} dagen)`;
        card.appendChild(head);

        // Suggestietabel
        const rows=_rankedSuggestions(); // generiek (op basis van historie & NEX); je kunt dit nog filteren op regio
        const table=document.createElement('table'); table.className='rp-table rp-compact';
        table.innerHTML=`
          <thead><tr>
            <th>Locatie</th><th style="text-align:right">Voorsp. $</th>
            <th style="text-align:center">NEX OK</th><th style="text-align:right">Score</th>
            <th style="text-align:center">Plan</th>
          </tr></thead><tbody></tbody>`;
        const tb=table.querySelector('tbody');

        const planned=[];
        rows.slice(0,8).forEach(r=>{
          const tr=document.createElement('tr');
          tr.innerHTML=`
            <td>${_esc(r.loc)}</td>
            <td style="text-align:right">$${r.usd.toLocaleString()}</td>
            <td style="text-align:center">${r.nexOk?'✅':'⚠️'}</td>
            <td style="text-align:right">${r.score.toFixed(1)}</td>
            <td style="text-align:center"></td>`;
          const sIn=document.createElement('input'); sIn.type='date'; sIn.value=slot.start;
          const eIn=document.createElement('input'); eIn.type='date'; eIn.value=slot.eind;
          const add=_btn('➕','blue');
          add.onclick=()=>{
            if(new Date(sIn.value)>new Date(eIn.value)) return alert('Begin moet vóór einde liggen.');
            if(new Date(sIn.value)<new Date(slot.start) || new Date(eIn.value)>new Date(slot.eind))
              return alert('Kies datums binnen de vrije periode.');
            planned.push({ loc:r.loc, start:sIn.value, eind:eIn.value, person:pp.naam });
            add.disabled=true; add.textContent='Gekozen';
          };
          const wrap=document.createElement('div'); wrap.style.cssText='display:inline-flex;gap:.35rem;align-items:center';
          wrap.append(sIn,eIn,add);
          tr.children[4].appendChild(wrap);
          tb.appendChild(tr);
        });

        const planBtn=_btn('Plan selectie','green');
        planBtn.onclick=async ()=>{
          if(!planned.length) return showAlert('Geen selectie in deze periode.','warning');
          for(const it of planned){
            const id = crypto.randomUUID?.() || String(Date.now()+Math.random());
            db.evenementen.push({
              id,
              naam: `${it.loc} (voorstel)`,
              locatie: it.loc,
              type: 'Voorstel',
              personen: [it.person],
              bus: '',
              startdatum: it.start,
              einddatum: it.eind,
              state: 'tentative',
              pending_confirmation: true,
              sessions: [],
              kosten: {}
            });
            try { await saveEvent(id); } catch {}
          }
          showAlert('✅ Voorstellen ingepland als “tentative”.', 'success');
          _closeAllModals(); openReisPlannerModal();
        };

        card.append(table, planBtn);
        box.appendChild(card);
      });
    });

    box.append(_cta([['❌ Sluiten','red', _closeAllModals]]));
    return box;
  });
}

// ================= Quick‑edit =================
function _openQuickEdit(evt){
  _modal(()=>{
    const box=document.createElement('div');
    box.appendChild(_h2(`✏️ ${evt.naam||'Event'}`));

    const r1=_lineInput('Start','date',evt.startdatum||'');
    const r2=_lineInput('Einde','date',evt.einddatum||'');
    const r3=_lineSelect('Bus', Object.keys(db.voorraad||{}), evt.bus||'');
    const r4=_lineChecks('Personen',['Olga','Alberto'], evt.personen||[]);
    const r5=_lineInput('Type','text', evt.type||'');
    const r6=_lineInput('Locatie','text', evt.locatie||'');

    box.append(r1.wrap,r2.wrap,r3.wrap,r4.wrap,r5.wrap,r6.wrap);

    box.append(_cta([
      ['❌ Sluiten','red', _closeAllModals],
      ['💾 Opslaan','green', async ()=>{
        evt.startdatum=r1.input.value||evt.startdatum;
        evt.einddatum =r2.input.value||evt.einddatum;
        evt.bus       =r3.select.value||'';
        evt.personen  =r4.getValues();
        evt.type      =r5.input.value||evt.type;
        evt.locatie   =r6.input.value||evt.locatie;
        await saveEvent(evt.id);
        _closeAllModals(); showAlert('✅ Event bijgewerkt.','success'); openReisPlannerModal();
      }]
    ]));
    return box;
  });
}

// ================= Helpers: DOM / widgets =================
function _btn(label,color='green'){
  const b=document.createElement('button'); b.className=`rp-btn rp-${color}`; b.textContent=label; return b;
}
function _h2(t){ const h=document.createElement('h2'); h.className='rp-title'; h.textContent=t; return h;}
function _p(t){ const p=document.createElement('p'); p.className='rp-p'; p.textContent=t; return p;}
function _cta(items){ const row=document.createElement('div'); row.className='rp-cta'; items.forEach(([l,c,fn])=>{const b=_btn(l,c); b.onclick=fn; row.appendChild(b);}); return row;}
function _lineInput(label,type,val){ const wrap=document.createElement('div'); wrap.className='rp-line'; const lab=document.createElement('label'); lab.className='rp-lab'; lab.textContent=label; const input=document.createElement('input'); input.type=type; if(val) input.value=val; wrap.append(lab,input); return {wrap,input};}
function _lineSelect(label,options,val){ const wrap=document.createElement('div'); wrap.className='rp-line'; const lab=document.createElement('label'); lab.className='rp-lab'; lab.textContent=label; const sel=document.createElement('select'); (options||[]).forEach(o=>sel.append(new Option(o,o))); sel.value=val||''; wrap.append(lab,sel); return {wrap,select:sel};}
function _lineChecks(label,opts,vals){ const wrap=document.createElement('div'); wrap.className='rp-line'; const lab=document.createElement('label'); lab.className='rp-lab'; lab.textContent=label; const box=document.createElement('div'); box.style.cssText='display:flex;gap:.6rem;flex-wrap:wrap'; const inputs=(opts||[]).map(o=>{ const l=document.createElement('label'); l.className='pretty-checkbox'; const i=document.createElement('input'); i.type='checkbox'; i.value=o; if((vals||[]).includes(o)) i.checked=true; l.append(i, document.createTextNode(' '+o)); box.appendChild(l); return i; }); wrap.append(lab,box); return {wrap, getValues:()=>inputs.filter(i=>i.checked).map(i=>i.value)};}
function _modal(build){ _closeAllModals(); const ov=document.createElement('div'); ov.className='modal rp-modal'; const box=document.createElement('div'); box.className='rp-dialog'; const close=_btn('✕','red'); close.style.position='absolute'; close.style.right='10px'; close.style.top='10px'; close.onclick=_closeAllModals; box.append(close, build()); ov.appendChild(box); _injectPlannerCSS(); document.body.appendChild(ov); }
function _closeAllModals(){ try{ document.querySelectorAll('.modal').forEach(m=>m.remove()); }catch{} }

// ================= Utils =================
function _iso(y,m,d){ return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }
function _fmt(d){ if(!d) return ''; const t=new Date(d); return isNaN(t)?'':t.toISOString().slice(0,10); }
function _monthName(m){ return new Date(2000,m,1).toLocaleString('nl-NL',{month:'long'}); }
function _minDate(a,b){ return (new Date(a) < new Date(b)) ? a : b; }
function _maxDate(a,b){ return (new Date(a) > new Date(b)) ? a : b; }
function _rangesOverlap(aS,aE,bS,bE){ if(!aS||!aE||!bS||!bE) return false; const A1=new Date(aS),A2=new Date(aE),B1=new Date(bS),B2=new Date(bE); return A1<=B2 && B1<=A2; }
function _esc(s){ return String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'); }
function _estimateUSD(evt){
  const vergelijkbaar=(db.evenementen||[]).filter(e=>e.id!==evt.id && e.locatie===evt.locatie && e.type===evt.type && e.sessions?.length).slice(-5);
  const sum = vergelijkbaar.reduce((tot,e)=> tot + e.sessions.reduce((s,ss)=> s+(ss.omzet_usd||0),0),0);
  return vergelijkbaar.length ? Math.round(sum/vergelijkbaar.length) : 0;
}
function _capacity(name){ const n=name||''; if(n.startsWith('BG')||n.startsWith('GEIT truffel'))return 18; if(n.startsWith('GEIT'))return 15; if(n.startsWith('ROOK'))return 10; return 1; }
function _weightsFromHistory(){
  const out={}; let tot=0;
  (db.evenementen||[]).filter(e=>e.sessions?.some(s=>s.verkopen)).slice(-20)
    .forEach(ev=>ev.sessions.forEach(s=>(s.verkopen||[]).forEach(v=>{ const k=v.product; const val=v.prijs_usd||0; out[k]=(out[k]||0)+val; tot+=val; })));
  if(tot<=0) return {};
  Object.keys(out).forEach(k=> out[k]=out[k]/tot);
  return out;
}
function _locColor(loc){
  const map={'Ramstein':'#2E7D32','Wiesbaden':'#00796B','Chievres':'#2A62B9','Spangdahlem':'#FB8C00','Grafenwoehr':'#6D4C41','Aviano':'#8E24AA','Vicenza':'#3949AB','Napels':'#C62828','Rota':'#1565C0','Brunssum':'#455A64'};
  return map[loc] || '#2A9626';
}
function _personColor(pers){ const p=Array.isArray(pers)?pers.join(','):(pers||''); if(p.includes('Olga'))return'#7E57C2'; if(p.includes('Alberto'))return'#009688'; return'#2A9626'; }
function _isoAddDays(iso,days){ const d=new Date(iso); d.setDate(d.getDate()+days); return d.toISOString().slice(0,10); }
function _freeSlots(occupied,today,horizon){
  const slots=[]; let cursor=today;
  const occ=[...occupied].sort((a,b)=> new Date(a.start)-new Date(b.start));
  for(const o of occ){
    const s=o.start, e=o.eind;
    if(new Date(cursor)<new Date(s)){ slots.push({start:cursor, eind:_fmt(_isoAddDays(s,-1)), days: (new Date(s)-new Date(cursor))/(1000*60*60*24) }); }
    if(new Date(e)>=new Date(cursor)) cursor=_fmt(_isoAddDays(e,1));
  }
  if(new Date(cursor)<=new Date(horizon)){
    slots.push({start:cursor, eind:horizon, days: (new Date(horizon)-new Date(cursor))/(1000*60*60*24) });
  }
  return slots.filter(s=>s.days>=2); // minimale duur 2 dagen
}

// Suggestie ranking met NEX‑cooldown (60 d)
function _rankedSuggestions(){
  const locs = Array.from(new Set((db.evenementen||[]).map(e=>e.locatie).filter(Boolean)));
  const rows = locs.map(loc=>{
    const hist=(db.evenementen||[]).filter(e=>e.locatie===loc && e.sessions?.length);
    const usd = hist.reduce((t,e)=> t + e.sessions.reduce((s,ss)=> s+(ss.omzet_usd||0),0),0) / Math.max(1,hist.length);
    const lastEnd = hist.length ? new Date(hist.sort((a,b)=> new Date(b.einddatum)-new Date(a.einddatum))[0].einddatum) : null;
    const rec = lastEnd ? Math.round((Date.now()-lastEnd.getTime())/(1000*60*60*24)) : 365;
    const nex = ['Rota','Napels','Sicilie','Djibouti','Bahrein']; // uitbreiden in configurator
    const nexOk = rec >= 60 || !nex.includes(loc);
    const score = (usd/1000) + (rec/30) + (nexOk?3:-3);
    return { loc, usd:Math.max(0,Math.round(usd)), rec, nexOk, score };
  });
  rows.sort((a,b)=> b.score - a.score);
  return rows;
}

// ================= CSS inject =================
function _injectPlannerCSS(){
  if (document.getElementById('rp-css')) return;
  const css=document.createElement('style'); css.id='rp-css';
  css.textContent = `
  .rp-modal > .rp-shell{ width:min(96vw,1200px); max-width:min(96vw,1200px); max-height:92vh; overflow:hidden; border-radius:12px; background:#fff; display:flex; flex-direction:column; }
  .rp-modal > .rp-dialog{ width:min(96vw,1100px); max-height:90vh; overflow:auto; border-radius:12px; background:#fff; padding:1rem; position:relative; }

  .rp-header{ background:#2A9626; color:#fff; display:flex; justify-content:space-between; align-items:center; gap:.6rem; padding:.6rem .8rem; }
  .rp-h-left,.rp-h-right{ display:flex; gap:.4rem; align-items:center; flex-wrap:wrap; }
  .rp-h-title{ font-weight:900; }

  .rp-btn{ border:none; border-radius:.6rem; padding:.5rem .75rem; font-weight:900; color:#fff; cursor:pointer; }
  .rp-green{ background:#2E7D32; } .rp-blue{ background:#1976D2; } .rp-amber{ background:#FB8C00; } .rp-red{ background:#C62828; } .rp-indigo{ background:#5C6BC0; }
  .rp-btn:disabled{ opacity:.6; cursor:not-allowed; }

  .rp-cal-wrap{ padding:.7rem; }
  .rp-weekdays{ display:grid; grid-template-columns:repeat(7,1fr); gap:6px; padding:0 .2rem; color:#2A9626; font-weight:900; }
  .rp-weekdays>div{ text-align:center; }
  .rp-grid{ display:grid; grid-template-columns:repeat(7,1fr); grid-template-rows:repeat(6,1fr); gap:6px; height:calc(92vh - 120px); }
  .rp-cell{ background:#fff; border:1px solid #e8e8e8; border-radius:10px; position:relative; overflow:hidden; padding:2px 4px; }
  .rp-cell.dim{ background:#fafafa; }
  .rp-daynum{ position:absolute; top:6px; right:8px; font-weight:800; color:#444; }
  .rp-cell.selected{ outline:3px solid #1976D2; outline-offset:-3px; }
  .rp-cell.inrange { outline:3px solid rgba(25,118,210,.55); outline-offset:-3px; }

  .rp-fill{ position:absolute; inset:0; background:linear-gradient(to bottom, var(--loc) 0 50%, var(--per) 50% 100%); opacity:.18; }
  .rp-tag{ position:absolute; left:6px; bottom:6px; color:#fff; background:#2A9626; padding:.15rem .45rem; border-radius:.45rem; font-weight:900; max-width:calc(100% - 12px); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; box-shadow:0 2px 8px rgba(0,0,0,.25); }

  .rp-title{ color:#2A9626; margin:.2rem 0 .6rem; }
  .rp-sub{ color:#2A9626; margin:.8rem 0 .3rem; }
  .rp-p{ color:#444; margin:.3rem 0 .6rem; }
  .rp-line{ display:flex; align-items:center; gap:.6rem; margin:.45rem 0; }
  .rp-lab{ min-width:120px; font-weight:800; }
  .rp-cta{ display:flex; gap:.5rem; justify-content:flex-end; margin-top:1rem; }
  .rp-table{ width:100%; border-collapse:collapse; }
  .rp-table th,.rp-table td{ padding:8px; border-bottom:1px solid #eee; }
  .rp-table th{ text-align:left; color:#2A9626; }
  .rp-table.rp-compact th,.rp-table.rp-compact td{ padding:6px; }
  .rp-total{ margin-top:.6rem; font-weight:900; color:#2A9626; }

  .rp-card{ border:1px solid #eee; border-radius:10px; padding:.6rem; margin:.4rem 0; background:#fff; box-shadow:0 2px 8px rgba(0,0,0,.06); }
  .rp-card-head{ font-weight:900; color:#2A9626; margin-bottom:.4rem; }
  `;
  document.head.appendChild(css);
}