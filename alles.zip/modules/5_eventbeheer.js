// 📦 5_eventbeheer.js – Evenementenbeheer (lijst, zoeken, filteren, nieuw/bewerk, afronden)
// Scroll-fix: eigen overlay/dialoog classes (geen .modal), overlay & dialog beide scrollbaar
// Auto-activate: vandaag-geplande events worden bij openen van de modal actief gezet

import { db, saveEvent } from './3_data.js';
import { showAlert } from './4_ui.js';

// ===== Utilities =====
function lockBodyScroll(lock = true) {
  document.documentElement.style.overflow = lock ? 'hidden' : '';
  document.body.style.overflow = lock ? 'hidden' : '';
}
function parseNumberLocale(v, fallback = 0) {
  if (v == null) return fallback;
  const s = String(v).trim();
  if (!s) return fallback;
  const n = Number(s.replace(',', '.'));
  return Number.isFinite(n) ? n : fallback;
}
function onEsc(el, handler) {
  const fn = (e) => { if (e.key === 'Escape') handler(); };
  el._escHandler = fn; document.addEventListener('keydown', fn);
}
function offEsc(el) {
  if (el?._escHandler) document.removeEventListener('keydown', el._escHandler);
}
function escapeHtml(str) {
  if (typeof str !== 'string') return String(str ?? '');
  return str
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#39;');
}

// ===== Datum helpers (lokaal, geen import nodig) =====
function _parseDateLoose(v){
  if (!v) return null;
  try {
    if (typeof v === 'number') return new Date(v);
    if (typeof v === 'string') {
      const s = v.trim();
      // Voorkom UTC-shift: forceer local midnight
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return new Date(s + 'T00:00:00');
      return new Date(s);
    }
    if (v instanceof Date) return v;
  } catch(_) {}
  return null;
}
function _eventPlannedDate(ev){
  const candidates = [
    ev?.plannedDate, ev?.planDate, ev?.date, ev?.datum,
    ev?.startDate, ev?.startDatum, ev?.startdatum,
    ev?.planning?.date, ev?.planning?.startDate
  ];
  for (const c of candidates){
    const d = _parseDateLoose(c);
    if (d && !isNaN(d)) return d;
  }
  return null;
}
function _isSameDay(d1, d2){
  return d1.getFullYear() === d2.getFullYear()
      && d1.getMonth()    === d2.getMonth()
      && d1.getDate()     === d2.getDate();
}
function _isTodayPlanned(ev){
  const d = _eventPlannedDate(ev);
  if (!d) return false;
  const nu = new Date(); // local timezone
  return _isSameDay(d, nu);
}

// ===== Auto-activate (alleen binnen deze module gebruikt) =====
async function activateTodayPlannedEventsLocal() {
  const lijst = Array.isArray(db?.evenementen) ? db.evenementen : [];
  const toActivate = lijst.filter(e =>
    e && (String(e.state||'').toLowerCase() === 'planned' || String(e.state||'').toLowerCase() === 'gepland') &&
    _isTodayPlanned(e)
  );

  for (const ev of toActivate) {
    try {
      ev.state = 'active';
      ev.activatedAt = ev.activatedAt || new Date().toISOString();
      await saveEvent(ev.id);
      console.log('✅ Actief gezet (vandaag):', ev.naam);
    } catch (err) {
      console.warn('⚠️ Kon event niet activeren:', ev?.naam || ev?.id, err);
    }
  }
}

// ===== Public API =====
export async function toonEvenementenMenu() {
  injectStylesOnce();

  // Eerst: vandaag-geplande events actief zetten
  await activateTodayPlannedEventsLocal();

  // Sluit bestaande overlays van dit type
  document.querySelectorAll('.oc-overlay').forEach(m => { offEsc(m); m.remove(); });
  lockBodyScroll(true);

  const overlay = document.createElement('div');
  overlay.className = 'oc-overlay';
  overlay.id = 'eventsOverlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', 'Evenementen');

  overlay.innerHTML = `
    <div class="oc-dialog oc-dialog--wide">
      <div class="ev-header">
        <h2>📅 Evenementen</h2>
        <div class="ev-header-actions">
          <button class="btn-primary" id="evAddBtn">➕ Nieuw evenement</button>
          <button class="ev-close" aria-label="Sluiten">✕</button>
        </div>
      </div>

      <div class="ev-controls">
        <input id="evSearch" class="ev-search" type="search" placeholder="Zoek op naam of locatie…" aria-label="Zoeken">
        <div class="ev-filters" role="tablist" aria-label="Filter">
          <button data-filter="all"    class="chip active">Alle</button>
          <button data-filter="active" class="chip">Actief</button>
          <button data-filter="closed" class="chip">Afgerond</button>
        </div>
      </div>

      <div id="evList" class="ev-list" aria-live="polite"></div>

      <div class="ev-footer">
        <button class="btn-danger" id="evCloseBtn">Sluiten</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  onEsc(overlay, () => doClose());
  const doClose = () => { offEsc(overlay); overlay.remove(); lockBodyScroll(false); };

  const state = { filter: 'all', query: '' };
  const search = overlay.querySelector('#evSearch');
  const list   = overlay.querySelector('#evList');

  // Close handlers
  overlay.querySelector('.ev-close').onclick = doClose;
  overlay.querySelector('#evCloseBtn').onclick = doClose;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) doClose(); });

  // Nieuw evenement
  overlay.querySelector('#evAddBtn').onclick = () => openEventFormModal({ isNew: true });

  // Filters
  overlay.querySelectorAll('.ev-filters .chip').forEach(btn => {
    btn.onclick = () => {
      overlay.querySelectorAll('.ev-filters .chip').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.filter = btn.dataset.filter;
      renderList(list, state);
    };
  });

  // Search (debounced)
  let t = null;
  search.oninput = () => {
    clearTimeout(t);
    t = setTimeout(() => {
      state.query = search.value.trim().toLowerCase();
      renderList(list, state);
    }, 120);
  };

  // Initial render + focus
  renderList(list, state);
  setTimeout(() => { search.focus(); search.select?.(); }, 0);
}

// Export zodat andere modules kunnen afronden
export async function toonAfrondModal(eventId) {
  injectStylesOnce();

  const event = (db.evenementen || []).find(e => e.id === eventId);
  if (!event) return showAlert('❌ Evenement niet gevonden.', 'error');

  const lastOpen = Array.isArray(event.sessions) ? event.sessions.find(s => s.endTime === 'OPEN') : null;

  document.querySelectorAll('.oc-overlay').forEach(m => { /* laat list overlay evt. open */ });
  lockBodyScroll(true);

  const overlay = document.createElement('div');
  overlay.className = 'oc-overlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', `Afronden ${event.naam}`);

  overlay.innerHTML = `
    <div class="oc-dialog" style="max-width:560px">
      <div class="ev-header">
        <h2>🔒 Afronden: ${escapeHtml(event.naam)}</h2>
        <button class="ev-close" aria-label="Sluiten">✕</button>
      </div>

      <div class="ev-summary">
        <div><b>Locatie</b><br>${escapeHtml(event.locatie || '-')}</div>
        <div><b>Status</b><br>${escapeHtml(event.state || '-')}</div>
        <div><b>Open sessie</b><br>${lastOpen ? '🟢 Ja' : '—'}</div>
      </div>

      <div class="ev-input">
        <label><b>Optioneel eindsaldo (primaire valuta sessie)</b></label>
        <input id="evEndTotal" type="text" inputmode="decimal" placeholder="Bijv. 250,00" />
        <div class="ev-hint">Dit wordt opgeslagen op de laatste open sessie als referentie. Je kunt dit veld leeg laten.</div>
      </div>

      <div class="ev-footer">
        <button class="btn-secondary" id="cancelClose">Annuleren</button>
        <button class="btn-danger" id="confirmClose">✅ Afronden</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  onEsc(overlay, () => close());
  const close = () => { offEsc(overlay); overlay.remove(); lockBodyScroll(false); };

  overlay.querySelector('.ev-close').onclick = close;
  overlay.querySelector('#cancelClose').onclick = close;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

  overlay.querySelector('#confirmClose').onclick = async () => {
    try {
      const endTotalRaw = overlay.querySelector('#evEndTotal').value.trim();
      const parsed = endTotalRaw === '' ? null : parseNumberLocale(endTotalRaw, NaN);
      if (endTotalRaw !== '' && !Number.isFinite(parsed)) {
        showAlert('⚠️ Ongeldig bedrag.', 'warning');
        return;
      }

      if (lastOpen) {
        lastOpen.endTime = new Date().toISOString();
        if (!lastOpen.meta) lastOpen.meta = {};
        lastOpen.meta.endTotalPrimary  = parsed;
        lastOpen.meta.endTotalCurrency = String(lastOpen.valuta || 'USD').toUpperCase();
      }

      event.state = 'closed';
      await saveEvent(event.id);

      showAlert(`✅ Evenement "${event.naam}" afgerond.`, 'success');
      close();

      const list = document.querySelector('#evList');
      if (list) renderList(list, readStateFromUI());

    } catch (e) {
      console.error(e);
      showAlert('❌ Afronden mislukt. Probeer opnieuw.', 'error');
    }
  };
}

// ===== Nieuw/Bewerk evenement =====
export function openEventFormModal({ isNew = true, eventId = null } = {}) {
  injectStylesOnce();
  lockBodyScroll(true);

  const overlay = document.createElement('div');
  overlay.className = 'oc-overlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', isNew ? 'Nieuw evenement' : 'Evenement bewerken');

  const modal = document.createElement('div');
  modal.className = 'oc-dialog';
  modal.style.maxWidth = '720px';
  overlay.appendChild(modal);

  const eventData = isNew ? {} : (db.evenementen || []).find(e => e.id === eventId);
  if (!isNew && !eventData) {
    showAlert('❌ Evenement niet gevonden.', 'error');
    return;
  }

  modal.innerHTML = `
    <div class="ev-header">
      <h2>${isNew ? '➕ Nieuw evenement' : '✏️ Evenement bewerken'}</h2>
      <div class="ev-header-actions">
        <button class="ev-close" aria-label="Sluiten">✕</button>
      </div>
    </div>
  `;

  const form = document.createElement('form');
  form.id = 'scheduleForm';
  form.innerHTML = `
    <div class="form-grid">
      <div class="form-field">
        <label for="evtName">Naam evenement</label>
        <input type="text" id="evtName" ${isNew ? 'readonly' : ''} required>
      </div>

      <div class="form-field">
        <label for="evtType">Type evenement</label>
        <select id="evtType" required>
          <option value="">Kies type</option>
          <option value="BX">BX</option>
          <option value="Bazaar">Bazaar</option>
        </select>
      </div>

      <div class="form-field">
        <label for="evtLocation">Locatie</label>
        <select id="evtLocation" required>
          <option value="">Kies locatie</option>
          <option>Ramstein</option><option>Spangdahlem</option><option>Stuttgart</option>
          <option>Chievres</option><option>Wiesbaden</option><option>Grafenwoehr</option>
          <option>Vilseck</option><option>Hohenfels</option><option>Aviano</option>
          <option>Vicenza</option><option>Napels</option><option>Rota</option>
          <option>Brunssum</option>
        </select>
      </div>

      <div class="form-field">
        <label for="evtStart">Startdatum</label>
        <input type="date" id="evtStart" required>
      </div>

      <div class="form-field">
        <label for="evtEnd">Einddatum</label>
        <input type="date" id="evtEnd" required>
      </div>

      <div class="form-field">
        <label for="evtBus">Bus</label>
        <select id="evtBus">
          ${(Object.keys(db.voorraad || {})).map(b=>`<option value="${b}">${b}</option>`).join('')}
        </select>
      </div>

      <fieldset class="form-field">
        <legend>Verkopers</legend>
        <label class="pretty-checkbox">
          <input type="checkbox" name="personen" value="Olga"> Olga
        </label>
        <label class="pretty-checkbox">
          <input type="checkbox" name="personen" value="Alberto"> Alberto
        </label>
      </fieldset>

      <div class="form-field">
        <label for="evtCommission">Commissie %</label>
        <input type="text" id="evtCommission" inputmode="decimal" value="0">
      </div>

      <div class="form-field">
        <label for="evtStipend">Stageld (€)</label>
        <input type="text" id="evtStipend" inputmode="decimal" value="0">
      </div>
    </div>

    <div class="ev-footer">
      <button type="button" class="btn-danger" id="cancelForm">Annuleren</button>
      <button type="button" class="btn-primary" id="saveScheduleBtn">✅ Opslaan</button>
    </div>
  `;
  modal.appendChild(form);
  document.body.appendChild(overlay);
  onEsc(overlay, () => close());
  const close = () => { offEsc(overlay); overlay.remove(); lockBodyScroll(false); };

  // --- Autonaam bij nieuwe events ---
  const nameInput      = form.querySelector('#evtName');
  const typeSelect     = form.querySelector('#evtType');
  const locationSelect = form.querySelector('#evtLocation');
  const startInput     = form.querySelector('#evtStart');

  function generateName() {
    if (!isNew) return;
    const tp  = typeSelect.value;
    const loc = locationSelect.value;
    const sd  = startInput.value;
    if (tp && loc && sd) {
      const d = new Date(sd);
      const m = d.toLocaleString('nl-NL',{month:'long',year:'2-digit'});
      nameInput.value = `${loc} ${tp} ${m}`;
    }
  }
  [typeSelect, locationSelect, startInput].forEach(el =>
    el.addEventListener('change', generateName)
  );
  generateName();

  // Prefill bij bewerken
  if (!isNew) {
    nameInput.value               = eventData.naam || '';
    typeSelect.value              = eventData.type || '';
    locationSelect.value          = eventData.locatie || '';
    form.querySelector('#evtStart').value = eventData.startdatum || '';
    form.querySelector('#evtEnd').value   = eventData.einddatum || '';
    form.querySelector('#evtBus').value   = eventData.bus || '';
    (eventData.personen || []).forEach(p=>{
      const cb = form.querySelector(`input[name="personen"][value="${p}"]`);
      if(cb) cb.checked = true;
    });
    form.querySelector('#evtCommission').value = (eventData.commissie ?? 0).toString().replace('.', ',');
    form.querySelector('#evtStipend').value    = (eventData.stageld   ?? 0).toString().replace('.', ',');
  }

  // Sluiten
  modal.querySelector('.ev-close').onclick = close;
  form.querySelector('#cancelForm').onclick = close;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

  // Opslaan
  form.querySelector('#saveScheduleBtn').addEventListener('click', async ()=>{
    const naam      = nameInput.value.trim();
    const typeVal   = typeSelect.value;
    const locatie   = locationSelect.value;
    const startVal  = form.querySelector('#evtStart').value;
    const eindVal   = form.querySelector('#evtEnd').value;
    const bus       = form.querySelector('#evtBus').value;
    const personen  = Array.from(form.querySelectorAll('input[name="personen"]:checked')).map(cb=>cb.value);
    const commissie = parseNumberLocale(form.querySelector('#evtCommission').value, 0);
    const stageld   = parseNumberLocale(form.querySelector('#evtStipend').value, 0);

    if(!naam||!typeVal||!locatie||!startVal||!eindVal||personen.length===0){
      return showAlert('⚠️ Vul alle verplichte velden in.','warning');
    }

    try {
      let id;
      if (isNew) {
        id = crypto.randomUUID?.()||Date.now().toString();
        const newEvt = {
          id, naam, locatie, type: typeVal, personen,
          bus, commissie, stageld, state:'planned',
          startdatum:startVal, einddatum:eindVal,
          sessions:[], kosten:{}
        };
        (db.evenementen ||= []).push(newEvt);
      } else {
        id = eventData.id;
        const idx = (db.evenementen || []).findIndex(e=>e.id===id);
        if (idx >= 0) {
          db.evenementen[idx] = {
            ...db.evenementen[idx],
            naam, locatie, type:typeVal, personen,
            bus, commissie, stageld,
            startdatum:startVal, einddatum:eindVal
          };
        }
      }
      await saveEvent(id);
      showAlert(isNew ? '✅ Evenement opgeslagen!' : '✅ Evenement bijgewerkt!','success');
      close();

      // hertekenen als lijst open is
      const list = document.querySelector('#evList');
      if (list) {
        renderList(list, readStateFromUI());
      }
    } catch(err) {
      console.error(err);
      showAlert('⚠️ Opslaan mislukt.','error');
    }
  });
}

// ====== Intern: lijst renderen ======
function renderList(container, state) {
  const events = (db.evenementen || []).slice();

  // Filter
  let filtered = events;
  if (state.filter === 'active')  filtered = events.filter(e => (e.state || '').toLowerCase() === 'active');
  if (state.filter === 'closed')  filtered = events.filter(e => {
    const s = (e.state || '').toLowerCase();
    return s === 'closed' || s === 'completed';
  });

  // Zoeken
  const q = state.query;
  if (q) {
    filtered = filtered.filter(e => {
      const hay = `${e.naam || ''} ${e.locatie || ''}`.toLowerCase();
      return hay.includes(q);
    });
  }

  // Sort: actief eerst, dan startdatum desc, dan naam asc
  filtered.sort((a, b) => {
    const sa = (a.state || '').toLowerCase();
    const sb = (b.state || '').toLowerCase();
    if (sa !== sb) return sa === 'active' ? -1 : 1;
    const da = new Date(a.startdatum || 0).getTime();
    const dbt = new Date(b.startdatum || 0).getTime();
    if (da !== dbt) return dbt - da;
    return String(a.naam || '').localeCompare(String(b.naam || ''));
  });

  if (!filtered.length) {
    container.innerHTML = `<div class="ev-empty">Geen evenementen gevonden.</div>`;
    return;
  }

  container.innerHTML = '';
  filtered.forEach(ev => {
    const row = document.createElement('div');
    row.className = 'ev-row';

    const status = (ev.state || '').toLowerCase();
    const isActive = status === 'active';

    row.innerHTML = `
      <div class="ev-main">
        <div class="ev-title">
          <span class="dot ${isActive ? 'ok' : 'off'}"></span>
          <b>${escapeHtml(ev.naam)}</b>
        </div>
        <div class="ev-sub">
          ${escapeHtml(ev.locatie || '-')}${ev.type ? ` • ${escapeHtml(ev.type)}` : '' }
        </div>
      </div>
      <div class="ev-acts">
        <button class="btn-light" data-action="details">📄 Details</button>
        <button class="btn-primary" data-action="edit">✏️ Bewerken</button>
        ${isActive ? `<button class="btn-warn" data-action="afronden">🔒 Afronden</button>` : ''}
      </div>
    `;

    // Handlers
    row.querySelector('[data-action="details"]').onclick = async () => {
      try {
        const mod = await import('./9_eventdetails.js');
        await mod.openEventDetail(ev.id);
      } catch (e) {
        console.error(e);
        showAlert('❌ Kan detailvenster niet openen.', 'error');
      }
    };

    row.querySelector('[data-action="edit"]').onclick = () => {
      openEventFormModal({ isNew:false, eventId: ev.id });
    };

    const afr = row.querySelector('[data-action="afronden"]');
    if (afr) afr.onclick = () => toonAfrondModal(ev.id);

    container.appendChild(row);
  });
}

function readStateFromUI() {
  const wrap = document.getElementById('eventsOverlay');
  const activeChip = wrap?.querySelector('.ev-filters .chip.active');
  const filter = activeChip?.dataset?.filter || 'all';
  const query  = wrap?.querySelector('#evSearch')?.value?.trim().toLowerCase() || '';
  return { filter, query };
}

// ====== Styles (namespaced overlay + scroll fixes) ======
function injectStylesOnce() {
  if (document.getElementById('ev-styles-oc')) return;
  const css = document.createElement('style');
  css.id = 'ev-styles-oc';
  css.textContent = `
    /* Overlay: eigen namespace om conflict met .modal te voorkomen */
    .oc-overlay{
      position:fixed; inset:0;
      display:flex; align-items:flex-start; justify-content:center;
      background:rgba(0,0,0,.35); z-index:9999;
      overflow:auto; padding:2rem 1rem;
      overscroll-behavior:contain;
      -webkit-overflow-scrolling: touch;
    }
    /* Dialoog: eigen container met eigen scroll. Geen conflict met andermans CSS. */
    .oc-dialog{
      width:min(960px, 94vw);
      max-height:90dvh;
      overflow:auto;
      background:#fff; border-radius:14px;
      box-shadow:0 10px 30px rgba(0,0,0,.25); padding:1rem 1rem .8rem 1rem;
    }
    .oc-dialog--wide{ width:min(960px, 96vw); }

    .ev-header{ display:flex; align-items:center; justify-content:space-between; padding:0 .2rem .2rem .2rem; gap:.6rem; position:sticky; top:0; background:#fff; z-index:1; }
    .ev-header-actions{ display:flex; gap:.5rem; align-items:center; }
    .ev-close{ border:none; border-radius:10px; padding:.45rem .6rem; font-weight:800; cursor:pointer;
               background:#455A64; color:#fff; }

    .ev-controls{ display:flex; gap:.6rem; align-items:center; padding:.6rem .2rem; flex-wrap:wrap; position:sticky; top:3rem; background:#fff; z-index:1; }
    .ev-search{ flex:1; min-width:220px; padding:.6rem .8rem; border:1px solid #ddd; border-radius:10px; }
    .ev-filters{ display:inline-flex; gap:.35rem; }
    .chip{ padding:.45rem .8rem; border-radius:999px; border:1px solid #ddd; background:#f7f7f7; cursor:pointer; font-weight:800; }
    .chip.active{ background:#2A9626; border-color:#2A9626; color:#fff; }

    .ev-list{ display:flex; flex-direction:column; gap:.5rem; padding:.2rem 0 .8rem 0; }
    .ev-empty{ padding:1rem; text-align:center; color:#666; }
    .ev-row{ display:flex; align-items:center; justify-content:space-between; border:1px solid #eee; border-radius:12px; padding:.6rem .7rem; background:#fff; }
    .ev-main{ min-width:0; }
    .ev-title{ display:flex; align-items:center; gap:.45rem; font-size:1rem; }
    .dot{ width:10px; height:10px; border-radius:50%; display:inline-block; background:#ccc; }
    .dot.ok{ background:#34c759; }
    .dot.off{ background:#ff6b6b; }
    .ev-sub{ color:#777; font-size:.9rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .ev-acts{ display:flex; gap:.4rem; flex-wrap:wrap; }

    /* Buttons */
    .btn-primary{ background:#2A9626; color:#fff; border:none; border-radius:10px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .btn-danger{ background:#e74c3c; color:#fff; border:none; border-radius:10px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .btn-warn{ background:#FFC500; color:#1a1a1a; border:none; border-radius:10px; padding:.45rem .7rem; font-weight:900; cursor:pointer; }
    .btn-secondary{ background:#1976D2; color:#fff; border:none; border-radius:10px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .btn-light{ background:#7E57C2; color:#fff; border:none; border-radius:10px; padding:.45rem .7rem; font-weight:900; }

    .ev-footer{ display:flex; justify-content:flex-end; gap:.5rem; padding:.7rem .2rem .9rem .2rem; background:#fff; position:sticky; bottom:0; }

    .ev-summary{
      display:grid; grid-template-columns: repeat(3, 1fr); gap:.5rem;
      background:#F8FFF4; border:1px solid #DDEED2; border-radius:12px; padding:.6rem .7rem; margin:.4rem 0 .7rem 0;
    }
    .ev-input label{ display:block; margin:.25rem 0 .25rem 0; }
    .ev-input input{ width:100%; padding:.6rem .7rem; border:1px solid #ddd; border-radius:10px; }
    .ev-hint{ font-size:.85rem; color:#666; margin-top:.25rem; }

    .form-grid{ display:grid; grid-template-columns: repeat(2, minmax(220px,1fr)); gap:.6rem; }
    .form-field{ display:flex; flex-direction:column; gap:.25rem; }
    .pretty-checkbox{ display:inline-flex; align-items:center; gap:.4rem; margin-right:.8rem; }

    @media (max-width:680px){
      .form-grid{ grid-template-columns: 1fr; }
      .ev-summary{ grid-template-columns: 1fr; }
      .ev-controls{ top:2.6rem; }
    }
  `;
  document.head.appendChild(css);
}