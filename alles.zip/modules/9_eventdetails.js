// 📦 9_eventdetails.js — Eventdetails met API-load, kosten→winst, sessiecards, breakdowns & export (CSV/PDF)

import { db, saveEvent } from './3_data.js';
import { showAlert } from './4_ui.js';

// ===== Public API =====
export async function openEventDetail(eventId) {
  // Close existing
  document.querySelectorAll('.modal').forEach(m => m.remove());
  document.getElementById('eventDetailOverlay')?.remove();

  const event = getEventById(eventId);
  if (!event) { showAlert('❌ Evenement niet gevonden', 'error'); return; }
  window.actiefEventId = event.id;
  window.actiefEvent   = event;
  ensureKostenStruct(event);

  // ⛑️ Data laden: sessies uit evenementen.json + verkopen via /api/verkopen/*.json, fallback naar embedded
  const { sessions, verkopen } = await loadEventDataForDetails(event);

  const metrics = computeMetrics(event, sessions, verkopen);

  // Overlay + modal
  const overlay = document.createElement('div');
  overlay.id = 'eventDetailOverlay';
  Object.assign(overlay.style, {
    position:'fixed', inset:0, background:'rgba(0,0,0,.35)', backdropFilter:'blur(2px)', zIndex:9998
  });
  document.body.appendChild(overlay);

  const modal = document.createElement('div');
  modal.className = 'modal';
  Object.assign(modal.style, {
    position:'fixed', top:'5vh', left:'50%', transform:'translateX(-50%)',
    width:'min(1000px,95vw)', maxHeight:'90vh', overflowY:'auto',
    background:'#fff', borderRadius:'14px', padding:'1.1rem',
    boxShadow:'0 10px 28px rgba(0,0,0,.25)', zIndex:9999
  });

  const root = document.createElement('div');
  root.innerHTML = [
    renderHeader(event),
    renderToolbar(event),
    renderKpis(metrics),
    renderSessionsCard(metrics),       // kaart met aantal sessies + daggemiddelde
    renderCostCards(event),            // kostenkaarten (regels vullen we in wire)
    renderChartsArea()
  ].join('');
  modal.appendChild(root);
  document.body.appendChild(modal);

  injectStylesOnce();

  // Wire up interactions & initial totals/list
  await wireCosts(root, event);

  // Charts (best effort)
  tryRenderCharts(root, sessions, verkopen, metrics);

  // Close button
  root.querySelector('#evd-close')?.addEventListener('click', () => {
    document.getElementById('eventDetailOverlay')?.remove();
    modal.remove();
  });

  // KPI breakdown clicks
  wireKpiBreakdowns(root, event);

  // Sessions card click → breakdown
  root.querySelector('#cardSessions')?.addEventListener('click', async () => {
    const { sessions: s2, verkopen: v2 } = await loadEventDataForDetails(event);
    const m2 = computeMetrics(event, s2, v2);
    openSessionsBreakdownModal(event, s2, v2, m2);
  });

  // Export knoppen
  root.querySelector('#exportCsvBtn')?.addEventListener('click', async () => {
    const { sessions: s2, verkopen: v2 } = await loadEventDataForDetails(event);
    exportEventCsv(event, s2, v2);
  });
  root.querySelector('#exportPdfBtn')?.addEventListener('click', async () => {
    const { sessions: s2, verkopen: v2 } = await loadEventDataForDetails(event);
    const m2 = computeMetrics(event, s2, v2);
    exportEventPdf(event, s2, v2, m2);
  });
}

// ===== Robust dataload =====
function getEventById(id) {
  return (db.evenementen || []).find(e => e.id === id || e.id === window.actiefEventId);
}
function ensureKostenStruct(event) {
  event.kosten = event.kosten || {};
  event.kosten.extra = Array.isArray(event.kosten.extra) ? event.kosten.extra : [];
}
function keysForEvent(event){
  const byId = (db.evenementen || []).find(e => e.id === event.id);
  const naam = (event.naam || byId?.naam || '').trim();
  const slug = (event.slug || '').trim();
  const id   = String(event.id || '').trim();
  // Probeer in deze volgorde: id, slug, naam (meest uniek eerst)
  return [id, slug, naam].filter(Boolean);
}
async function fetchJson(url){
  try {
    const r = await fetch(url, { cache: 'no-store' });
    if (!r.ok) throw new Error(r.status);
    return await r.json();
  } catch { return null; }
}
function flattenVerkopenFromSessionsArray(sessions){
  const out = [];
  (Array.isArray(sessions) ? sessions : []).forEach(s => {
    (s?.verkopen || []).forEach(v => {
      out.push({ ...v, sessieId: v.sessieId || v.sessionId || v.sessie_id || v.sessie || s.id });
    });
  });
  return out;
}
/** Laad sessies uit evenementen.json + verkopen via /api/verkopen/{key}.json; fallback op embedded verkopen. */
async function loadEventDataForDetails(event){
  // 1) Sessies rechtstreeks uit evenementen.json (bron voor koersen/dagen)
  const sessions = Array.isArray(event.sessions) ? event.sessions : [];

  // 2) Verkopen via API met voorkeur voor id → slug → naam
  const candidates = keysForEvent(event).map(k => `/api/verkopen/${encodeURIComponent(k)}.json`);
  let verkopen = [];
  for (const url of candidates){
    const json = await fetchJson(url);
    if (Array.isArray(json) && json.length){
      // Normalize sessieId veld
      verkopen = json.map(v => ({ ...v, sessieId: v.sessieId || v.sessionId || v.sessie_id || v.sessie || null }));
      break;
    }
  }

  // 3) Fallback: embedded verkopen uit sessions (oude structuur)
  if (!verkopen.length) {
    verkopen = flattenVerkopenFromSessionsArray(sessions);
  }

  return { sessions, verkopen };
}

// ===== Utils (parse etc.) =====
function parseNumFlex(v) {
  if (typeof v === 'number') return v;
  const s = String(v ?? '').trim().replace(/\s/g,'').replace(',', '.');
  const n = Number(s);
  return Number.isFinite(n) ? n : NaN;
}
function rateForSess(sessions, sessieId){ return Number((sessions||[]).find(s=>s.id===sessieId)?.exchangeRate||0); }
function isCheese(name){ return name && /\bkaas|cheese|geit|goat|rook|smoked|bg|mosterd|mustard\b/i.test(String(name)); }
function lookupInkoop(name){
  const prod = (db.producten||[]).find(p => [p.naam, p.name].filter(Boolean).map(x=>String(x).toLowerCase()).includes(String(name).toLowerCase()));
  return Number(prod?.inkoop || 0);
}
function euro(n){ return `€${Number(n||0).toFixed(2)}`; }
function usd(n){ return `$${Number(n||0).toFixed(2)}`; }
function escapeHtml(str){
  if (typeof str !== 'string') return String(str ?? '');
  return str.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
}
function setText(sel, val, root=document){ const el = root.querySelector(sel); if (el) el.textContent = String(val); }
function resetCanvas(sel, root=document){
  const old = root.querySelector(sel);
  if (!old) return;
  const p = old.parentElement;
  const fresh = old.cloneNode(false);
  p.replaceChild(fresh, old);
}

// ===== Metrics =====
function computeMetrics(event, sessions, verkopen) {
  const verkoop = (verkopen || []).filter(v => v && (v.type === 'verkoop' || !v.type));
  const snij    = (verkopen || []).filter(v => v && v.type === 'snijkaas');

  const omzetUSD = verkoop.reduce((s,v) => s + (Number(v.prijs_usd)||0), 0);
  const omzetEUR = verkoop.reduce((s,v) => s + (Number(v.prijs_usd)||0) * (rateForSess(sessions, v.sessieId) || 0), 0);

  const kaasEUR = verkoop.reduce((s,v) => s + (isCheese(v.product) ? (Number(v.prijs_usd)||0) * (rateForSess(sessions, v.sessieId) || 0) : 0), 0);
  const souvenirEUR = Math.max(0, omzetEUR - kaasEUR);

  const kaasInkoopVerkoop = verkoop.reduce((s,v) => s + (isCheese(v.product) ? (lookupInkoop(v.product) || 0) : 0), 0);
  const snijInkoop = snij.reduce((s,v) => s + (Number(v.inkoop)||0), 0);
  const kaasKosten = kaasInkoopVerkoop + snijInkoop;

  const commissiePct = Number(event.commissie || event.commissiePercent || 0);
  const commissie = (commissiePct / 100) * omzetEUR;
  const stageld   = Number(event.stageld || 0);
  const souvenirkosten = 0.25 * souvenirEUR;

  const extraTotal = (event.kosten.extra || []).reduce((s,k) => s + (Number(k.bedrag)||0), 0);
  const totaleKosten = kaasKosten + souvenirkosten + commissie + stageld + extraTotal;
  const winst = omzetEUR - totaleKosten;
  const winstPct = omzetEUR > 0 ? (winst/omzetEUR)*100 : 0;

  // Sessies & daggemiddelde
  const sessieCount = (sessions || []).length;
  const uniekeDagen = new Set(
    (sessions || []).map(s => {
      const d = new Date(s.startTime || Date.now());
      return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
    })
  ).size || 1;
  const avgPerDag = omzetEUR / uniekeDagen;

  return {
    omzetUSD, omzetEUR,
    kaasEUR, souvenirEUR,
    kaasKosten, souvenirkosten, commissiePct, commissie, stageld,
    extraTotal, totaleKosten, winst, winstPct,
    sessieCount, avgPerDag, uniekeDagen
  };
}

// ===== Render =====
function renderHeader(event){
  const status = (event.state||'').toLowerCase();
  const dot = status==='active'?'🟢':(status==='closed'||status==='completed')?'🔴':'⚪';
  return `
    <div class="evd-head">
      <div>
        <h2>${dot} ${escapeHtml(event.naam)}</h2>
        <div class="evd-sub">${escapeHtml(event.locatie || '-')} ${event.type ? '• '+escapeHtml(event.type) : ''}</div>
      </div>
      <button type="button" class="btn-light" id="evd-close">❌ Sluiten</button>
    </div>
    <hr class="evd-sep">
  `;
}

function renderToolbar(event){
  return `
    <div class="evd-toolbar">
      <button id="exportCsvBtn" class="btn-light">⬇️ Export CSV</button>
      <button id="exportPdfBtn" class="btn-light">🧾 Export PDF</button>
    </div>
  `;
}

function renderKpis(m){
  return `
    <div class="kpi-grid" id="kpiGrid">
      <div class="kpi clickable" data-k="omzetEUR"><div class="kpi-h">Omzet EUR</div><div class="kpi-v" id="k_omzetEUR">${euro(m.omzetEUR)}</div></div>
      <div class="kpi"><div class="kpi-h">Omzet USD</div><div class="kpi-v" id="k_omzetUSD">${usd(m.omzetUSD)}</div></div>
      <div class="kpi"><div class="kpi-h">Kaas omzet</div><div class="kpi-v" id="k_kaasEUR">${euro(m.kaasEUR)}</div></div>
      <div class="kpi"><div class="kpi-h">Souvenir omzet</div><div class="kpi-v" id="k_souvEUR">${euro(m.souvenirEUR)}</div></div>

      <div class="kpi"><div class="kpi-h">Kaaskosten</div><div class="kpi-v" id="k_kaasKosten">${euro(m.kaasKosten)}</div></div>
      <div class="kpi"><div class="kpi-h">Souvenirkosten (25%)</div><div class="kpi-v" id="k_souvKosten">${euro(m.souvenirkosten)}</div></div>
      <div class="kpi"><div class="kpi-h">Commissie (${m.commissiePct||0}%)</div><div class="kpi-v" id="k_commissie">${euro(m.commissie)}</div></div>
      <div class="kpi"><div class="kpi-h">Stageld</div><div class="kpi-v" id="k_stageld">${euro(m.stageld)}</div></div>
      <div class="kpi"><div class="kpi-h">Extra kosten</div><div class="kpi-v" id="k_extra">${euro(m.extraTotal)}</div></div>

      <div class="kpi big"><div class="kpi-h">Winst</div><div class="kpi-v" id="k_winst" style="color:${m.winst>=0?'#2A9626':'#D32F2F'}">${euro(m.winst)}</div><div class="kpi-s" id="k_winstPct">${m.winstPct.toFixed(1)}%</div></div>
    </div>
  `;
}

function renderSessionsCard(m){
  return `
    <div class="cards-row">
      <div class="card clickable" id="cardSessions" title="Klik voor sessie-breakdown">
        <div class="card-h">Sessies</div>
        <div class="card-v">${m.sessieCount}</div>
        <div class="card-s">Gem. per dag: <b>${euro(m.avgPerDag)}</b> (${m.uniekeDagen} dag(en))</div>
      </div>
    </div>
  `;
}

function renderCostCards(){
  const groups = ['Diesel','Eten','Overnachten','Anders'];
  return `
    <h3 class="blk-title">Kosten</h3>
    <div class="cost-grid">
      ${groups.map(g => cardTemplate(g)).join('')}
    </div>
  `;
}
function cardTemplate(soort){
  const id = `cg-${soort.toLowerCase()}`;
  return `
    <section class="cost-card" data-soort="${soort}">
      <div class="card-top">
        <div class="card-title"><b>${soort}</b> — <span class="card-total" id="${id}-total">€0.00</span></div>
        <div class="card-inputs">
          <input type="text" inputmode="decimal" class="in-amt" placeholder="€" aria-label="Bedrag">
          <input type="text" class="in-cmt" placeholder="Comment" aria-label="Commentaar">
          <button type="button" class="btn-green add-btn">✔ Voeg toe</button>
          <button type="button" class="btn-mini toggle-btn" title="Uitklappen">▶</button>
        </div>
      </div>
      <div class="card-body hidden" id="${id}-body"></div>
    </section>
  `;
}

function renderChartsArea(){
  return `
    <h3 class="blk-title" style="margin-top:1rem;">Grafieken</h3>
    <div class="charts">
      <canvas id="chartKosten" height="160"></canvas>
      <canvas id="chartOmzet"  height="160"></canvas>
    </div>
  `;
}

// ===== Wire UI =====
async function wireCosts(root, event){
  refreshCards(root, event);

  // Toggle bodies
  root.querySelectorAll('.cost-card').forEach(card => {
    const body = card.querySelector('.card-body');
    const toggle = card.querySelector('.toggle-btn');
    card.querySelector('.card-top')?.addEventListener('click', (e) => {
      if (e.target.closest('.add-btn')) return;
      if (e.target.closest('.in-amt') || e.target.closest('.in-cmt')) return;
      body.classList.toggle('hidden');
      toggle.textContent = body.classList.contains('hidden') ? '▶' : '▼';
    });
  });

  // Add cost
  root.querySelectorAll('.cost-card .add-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const card = e.currentTarget.closest('.cost-card');
      const soort = card.dataset.soort;
      const amtInput = card.querySelector('.in-amt');
      const cmtInput = card.querySelector('.in-cmt');
      const bedrag = parseNumFlex(amtInput.value);
      if (!Number.isFinite(bedrag) || bedrag <= 0) {
        showAlert('⚠️ Ongeldig bedrag.', 'warning');
        amtInput.focus(); return;
      }
      await addCost(event, { soort, bedrag, comment: cmtInput.value || '' });
      amtInput.value = ''; cmtInput.value = '';
      showAlert('✅ Kost toegevoegd', 'success');
      await recomputeAndRefresh(root, event);
    });
  });
}

function refreshCards(root, event){
  ensureKostenStruct(event);
  const groups = { Diesel:[], Eten:[], Overnachten:[], Anders:[] };
  (event.kosten.extra || []).forEach(k => {
    const s = ['Diesel','Eten','Overnachten'].includes(k.soort) ? k.soort : 'Anders';
    groups[s].push(k);
  });

  Object.entries(groups).forEach(([soort, lijst]) => {
    const id = `cg-${soort.toLowerCase()}`;
    const total = lijst.reduce((s,k) => s + (Number(k.bedrag)||0), 0);
    const totalEl = root.querySelector(`#${id}-total`);
    if (totalEl) totalEl.textContent = `€${total.toFixed(2)}`;

    const body = root.querySelector(`#${id}-body`);
    if (body) {
      body.innerHTML = lijst.length ? lijst.map((k,i)=>rowHtml(soort, i, k)).join('') : `<div class="empty">Nog geen kosten.</div>`;
      body.querySelectorAll('.row-del').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const idx = Number(e.currentTarget.getAttribute('data-index'));
          await removeCost(event, soort, idx);
          showAlert('🗑️ Kost verwijderd', 'success');
          await recomputeAndRefresh(root, event);
        });
      });
    }
  });
}

function rowHtml(soort, index, k){
  return `
    <div class="row">
      <div class="row-text">− €${Number(k.bedrag||0).toFixed(2)}${k.comment ? ` (${escapeHtml(k.comment)})` : ''}</div>
      <button type="button" class="row-del" data-index="${index}" title="Verwijderen">❌</button>
    </div>
  `;
}

// Recompute + update KPIs + charts + cards
async function recomputeAndRefresh(root, event){
  const { sessions, verkopen } = await loadEventDataForDetails(event);
  const m = computeMetrics(event, sessions, verkopen);

  setText('#k_omzetEUR', euro(m.omzetEUR), root);
  setText('#k_omzetUSD', usd(m.omzetUSD), root);
  setText('#k_kaasEUR', euro(m.kaasEUR), root);
  setText('#k_souvEUR', euro(m.souvenirEUR), root);
  setText('#k_kaasKosten', euro(m.kaasKosten), root);
  setText('#k_souvKosten', euro(m.souvenirkosten), root);
  setText('#k_commissie', euro(m.commissie), root);
  setText('#k_stageld', euro(m.stageld), root);
  setText('#k_extra', euro(m.extraTotal), root);

  const winstEl = root.querySelector('#k_winst');
  if (winstEl) {
    winstEl.textContent = euro(m.winst);
    winstEl.style.color = m.winst >= 0 ? '#2A9626' : '#D32F2F';
  }
  setText('#k_winstPct', `${m.winstPct.toFixed(1)}%`, root);

  // Cards totals/lists
  refreshCards(root, event);

  // Charts: rebuild simple (clear + redraw)
  resetCanvas('#chartKosten', root);
  resetCanvas('#chartOmzet', root);
  tryRenderCharts(root, sessions, verkopen, m);
}

// ===== Persist helpers =====
async function addCost(event, kost){
  ensureKostenStruct(event);
  event.kosten.extra.push({ soort: kost.soort, bedrag: Number(kost.bedrag), comment: kost.comment || '' });
  await persist(event);
}
async function removeCost(event, soort, indexInSoort){
  ensureKostenStruct(event);
  let seen = 0;
  event.kosten.extra = event.kosten.extra.filter(k => {
    const match = (['Diesel','Eten','Overnachten'].includes(k.soort) ? k.soort : 'Anders') === soort;
    if (!match) return true;
    if (seen === indexInSoort) { seen++; return false; }
    seen++; return true;
  });
  await persist(event);
}
async function persist(event){
  // Bewaar kostenstructuur via gewone saveEvent; je back-end route kan dit meenemen
  await saveEvent(event.id);
}

// ===== KPI Breakdowns =====
function wireKpiBreakdowns(root, event) {
  const grid = root.querySelector('#kpiGrid');
  if (!grid) return;
  grid.querySelectorAll('.clickable').forEach(card => {
    card.addEventListener('click', async () => {
      const key = card.getAttribute('data-k');
      const { sessions, verkopen } = await loadEventDataForDetails(event);
      const m = computeMetrics(event, sessions, verkopen);
      if (key === 'omzetEUR') {
        // Voor nu zelfde breakdown als sessies; kan later per product toegevoegd worden
        openSessionsBreakdownModal(event, sessions, verkopen, m);
      }
    });
  });
}

function openSessionsBreakdownModal(event, sessions, verkopen, m) {
  const overlay = document.createElement('div');
  overlay.className = 'modal';
  const wrap = document.createElement('div');
  Object.assign(wrap.style, {
    background:'#fff', borderRadius:'12px', padding:'1rem',
    width:'min(800px, 95vw)', maxHeight:'85vh', overflowY:'auto',
    position:'fixed', left:'50%', top:'7vh', transform:'translateX(-50%)',
    boxShadow:'0 10px 28px rgba(0,0,0,.25)', zIndex: 10000
  });

  const rows = (sessions || []).map(s => {
    const d = new Date(s.startTime || Date.now());
    const lbl = d.toLocaleString('nl-NL');
    const vs = (verkopen||[]).filter(v => v.sessieId===s.id && (v.type==='verkoop' || !v.type));
    const usdTot = vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0),0);
    const eurTot = vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0)*(Number(s.exchangeRate)||0),0);
    return `<tr>
      <td>${escapeHtml(lbl)}</td>
      <td style="text-align:right">$ ${usdTot.toFixed(2)}</td>
      <td style="text-align:right">€ ${eurTot.toFixed(2)}</td>
      <td style="text-align:right">${(s.exchangeRate||0).toFixed(2)}</td>
      <td style="text-align:center">${s.endTime==='OPEN'?'🟢 OPEN':'🔒'}</td>
    </tr>`;
  }).join('') || `<tr><td colspan="5" style="text-align:center;color:#777">Geen sessies</td></tr>`;

  wrap.innerHTML = `
    <h3 style="margin:.2rem 0 .6rem 0; color:#2A9626;">Sessies — ${escapeHtml(event.naam)}</h3>
    <table style="width:100%; border-collapse:collapse;">
      <thead>
        <tr>
          <th style="text-align:left; border-bottom:1px solid #eee; padding:.3rem 0;">Start</th>
          <th style="text-align:right; border-bottom:1px solid #eee; padding:.3rem 0;">Omzet USD</th>
          <th style="text-align:right; border-bottom:1px solid #eee; padding:.3rem 0;">Omzet EUR</th>
          <th style="text-align:right; border-bottom:1px solid #eee; padding:.3rem 0;">Koers</th>
          <th style="text-align:center; border-bottom:1px solid #eee; padding:.3rem 0;">Status</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr>
          <td style="border-top:1px solid #eee; padding:.3rem 0;"><b>Totaal (${m.sessieCount} sessies, ${m.uniekeDagen} dag(en))</b></td>
          <td style="text-align:right; border-top:1px solid #eee;">$ ${m.omzetUSD.toFixed(2)}</td>
          <td style="text-align:right; border-top:1px solid #eee;">€ ${m.omzetEUR.toFixed(2)}</td>
          <td></td><td></td>
        </tr>
        <tr>
          <td style="padding:.3rem 0;"><b>Gemiddelde per dag</b></td>
          <td></td>
          <td style="text-align:right;">€ ${m.avgPerDag.toFixed(2)}</td>
          <td></td><td></td>
        </tr>
      </tfoot>
    </table>
    <div style="text-align:right; margin-top:.8rem;">
      <button class="btn-light" id="sessiesClose">Sluiten</button>
    </div>
  `;
  overlay.appendChild(wrap);
  document.body.appendChild(overlay);
  document.body.classList.add('modal-open');
  wrap.querySelector('#sessiesClose')?.addEventListener('click', () => {
    overlay.remove();
    document.body.classList.remove('modal-open');
  });
}

// ===== Charts (best effort) =====
function tryRenderCharts(root, sessions, verkopen, m){
  if (typeof Chart === 'undefined') return;
  const c1 = root.querySelector('#chartKosten');
  const c2 = root.querySelector('#chartOmzet');
  if (!c1 || !c2) return;

  new Chart(c1.getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: ['🧀 Kaas', '🎁 Souvenirs 25%', '💼 Commissie', '🏕️ Stageld', '➕ Extra'],
      datasets: [{ data: [m.kaasKosten, m.souvenirkosten, m.commissie, m.stageld, m.extraTotal] }]
    },
    options: { plugins:{ legend:{ position:'right' } } }
  });

  const labels=[], usdArr=[], eurArr=[];
  (sessions||[]).forEach(s=>{
    labels.push(new Date(s.startTime||Date.now()).toLocaleDateString('nl-NL'));
    const vs = (verkopen||[]).filter(v=>v.sessieId===s.id && (v.type==='verkoop' || !v.type));
    usdArr.push(vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0),0));
    eurArr.push(vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0)*(Number(s.exchangeRate)||0),0));
  });
  new Chart(c2.getContext('2d'), {
    type:'bar',
    data:{ labels, datasets:[{label:'USD',data:usdArr},{label:'EUR',data:eurArr}] },
    options:{ scales:{ y:{ beginAtZero:true } } }
  });
}

// ===== Export (CSV & PDF) =====
function exportEventCsv(event, sessions, verkopen){
  // CSV: Sessies + verkopen samengevat per sessie
  const header = ['start','end','status','koers','omzet_usd','omzet_eur'];
  const lines = [header.join(',')];

  (sessions||[]).forEach(s=>{
    const vs = (verkopen||[]).filter(v=>v.sessieId===s.id && (v.type==='verkoop' || !v.type));
    const usd = vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0),0);
    const eur = vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0)*(Number(s.exchangeRate)||0),0);
    const start = new Date(s.startTime||'').toISOString();
    const end   = s.endTime && s.endTime!=='OPEN' ? new Date(s.endTime).toISOString() : '';
    const status = s.endTime==='OPEN' ? 'OPEN' : 'CLOSED';
    lines.push([start,end,status,(s.exchangeRate||0).toFixed(2),usd.toFixed(2),eur.toFixed(2)].join(','));
  });

  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const safeName = (event.naam||`event_${event.id}`).replace(/[^a-z0-9_\-]+/gi,'_');
  a.download = `${safeName}_sessies.csv`;
  document.body.appendChild(a);
  a.click();
  setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); }, 500);
}

function exportEventPdf(event, sessions, verkopen, m){
  // Simpel: open printbare view in nieuw venster → gebruiker kan "Opslaan als PDF"
  const w = window.open('', '_blank', 'noopener,noreferrer');
  if (!w) { showAlert('Kan printvenster niet openen (popup geblokkeerd).', 'warning'); return; }

  const rows = (sessions||[]).map(s=>{
    const vs = (verkopen||[]).filter(v=>v.sessieId===s.id && (v.type==='verkoop' || !v.type));
    const usd = vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0),0);
    const eur = vs.reduce((sum,v)=>sum+(Number(v.prijs_usd)||0)*(Number(s.exchangeRate)||0),0);
    return `<tr>
      <td>${escapeHtml(new Date(s.startTime||Date.now()).toLocaleString('nl-NL'))}</td>
      <td style="text-align:right">$ ${usd.toFixed(2)}</td>
      <td style="text-align:right">€ ${eur.toFixed(2)}</td>
      <td style="text-align:right">${(s.exchangeRate||0).toFixed(2)}</td>
      <td style="text-align:center">${s.endTime==='OPEN'?'🟢 OPEN':'🔒'}</td>
    </tr>`;
  }).join('') || `<tr><td colspan="5" style="text-align:center;color:#777">Geen sessies</td></tr>`;

  const css = `
    <style>
      body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif; padding:16px; color:#222}
      h1{margin:0 0 8px 0; color:#2A9626}
      .sub{color:#555; margin-bottom:12px}
      .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0}
      .kpi{border:1px solid #e3ede3;border-radius:10px;padding:8px;background:#f8faf8}
      .kpi h3{margin:0 0 4px 0;font-size:12px;color:#2A9626}
      .kpi .v{font-weight:800}
      table{width:100%;border-collapse:collapse;margin-top:10px}
      th,td{padding:6px;border-bottom:1px solid #eee}
      th{text-align:left}
      tfoot td{font-weight:700}
      .small{font-size:12px;color:#666}
      @media print {.no-print{display:none}}
    </style>
  `;

  const html = `
    <!doctype html><html><head><meta charset="utf-8">${css}<title>Eventrapport</title></head><body>
    <div class="no-print" style="text-align:right;margin-bottom:8px">
      <button onclick="window.print()">🧾 Print / PDF</button>
    </div>
    <h1>${escapeHtml(event.naam||'-')}</h1>
    <div class="sub">${escapeHtml(event.locatie||'-')} ${event.type? '• '+escapeHtml(event.type): ''}</div>

    <div class="grid">
      <div class="kpi"><h3>Omzet EUR</h3><div class="v">${euro(m.omzetEUR)}</div></div>
      <div class="kpi"><h3>Omzet USD</h3><div class="v">${usd(m.omzetUSD)}</div></div>
      <div class="kpi"><h3>Winst</h3><div class="v" style="color:${m.winst>=0?'#2A9626':'#D32F2F'}">${euro(m.winst)} <span class="small">(${m.winstPct.toFixed(1)}%)</span></div></div>
      <div class="kpi"><h3>Kaaskosten</h3><div class="v">${euro(m.kaasKosten)}</div></div>
      <div class="kpi"><h3>Souvenirkosten</h3><div class="v">${euro(m.souvenirkosten)}</div></div>
      <div class="kpi"><h3>Commissie</h3><div class="v">${euro(m.commissie)}</div></div>
      <div class="kpi"><h3>Stageld</h3><div class="v">${euro(m.stageld)}</div></div>
      <div class="kpi"><h3>Extra kosten</h3><div class="v">${euro(m.extraTotal)}</div></div>
      <div class="kpi"><h3>Sessies / dagen</h3><div class="v">${m.sessieCount} / ${m.uniekeDagen}</div></div>
      <div class="kpi"><h3>Gem. per dag</h3><div class="v">${euro(m.avgPerDag)}</div></div>
    </div>

    <h2 style="margin:8px 0 4px 0">Sessies</h2>
    <table>
      <thead>
        <tr>
          <th>Start</th>
          <th style="text-align:right">Omzet USD</th>
          <th style="text-align:right">Omzet EUR</th>
          <th style="text-align:right">Koers</th>
          <th style="text-align:center">Status</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr>
          <td>Totaal</td>
          <td style="text-align:right">$ ${m.omzetUSD.toFixed(2)}</td>
          <td style="text-align:right">€ ${m.omzetEUR.toFixed(2)}</td>
          <td></td><td></td>
        </tr>
      </tfoot>
    </table>
    </body></html>
  `;

  w.document.open();
  w.document.write(html);
  w.document.close();
}

// ===== Styles =====
function injectStylesOnce(){
  if (document.getElementById('evd2-styles')) return;
  const css = document.createElement('style');
  css.id = 'evd2-styles';
  css.textContent = `
    .evd-head{display:flex;justify-content:space-between;align-items:center;gap:.6rem}
    .evd-head h2{margin:.1rem 0;color:#2A9626}
    .evd-sub{color:#555}
    .evd-sep{border:none;border-top:1px solid #eee;margin:.5rem 0 1rem 0}

    .evd-toolbar{display:flex;gap:.5rem;justify-content:flex-end;margin:-.25rem 0 .5rem 0}
    .btn-light{background:#f2f2f2;color:#222;border:1px solid #e6e6e6;border-radius:10px;padding:.45rem .7rem;font-weight:800;cursor:pointer}

    .kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:.6rem;margin:.2rem 0 1rem}
    .kpi{background:#F8FAF8;border:1px solid #E3EDE3;border-radius:12px;padding:.6rem .7rem;cursor:default;user-select:none}
    .kpi.clickable{cursor:pointer;transition:transform .08s ease, box-shadow .08s ease}
    .kpi.clickable:hover{transform:translateY(-1px);box-shadow:0 2px 10px rgba(0,0,0,.06)}
    .kpi.big{grid-column:span 2}
    .kpi-h{font-weight:700;color:#2A9626}
    .kpi-v{font-size:1.12rem;font-weight:900}
    .kpi-s{font-size:.85rem;color:#777}

    .cards-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:.6rem;margin:.2rem 0 1rem}
    .card{background:#FCFFFA;border:1px solid #eaeaea;border-radius:12px;padding:.6rem .7rem;transition:transform .08s ease, box-shadow .08s ease}
    .card:hover{transform:translateY(-1px);box-shadow:0 2px 10px rgba(0,0,0,.06)}
    .card-h{font-weight:700;color:#2A9626}
    .card-v{font-size:1.2rem;font-weight:900}
    .card-s{font-size:.9rem;color:#666}

    .blk-title{margin:1rem 0 .5rem 0;color:#2A9626}
    .cost-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:.7rem}

    .cost-card{border:1px solid #eaeaea;border-radius:12px;background:#FCFFFA}
    .card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:.6rem;padding:.55rem .7rem;border-bottom:1px solid #eef6ea}
    .card-title{font-weight:700}

    /* ✅ Desktop/mobiel: add-knop valt niet onder volgend veld */
    .card-inputs{
      display:flex; flex-wrap:wrap; align-items:flex-start; gap:.35rem;
      max-width: 100%;
    }
    .card-inputs .in-amt{width:100px; text-align:right; flex:0 0 auto}
    .card-inputs .in-cmt{min-width:180px; flex:1 1 180px}
    .card-inputs .add-btn{flex:0 0 auto}
    .card-inputs .toggle-btn{flex:0 0 auto; min-width:40px}

    .in-amt,.in-cmt{padding:.45rem .55rem;border:1px solid #ddd;border-radius:10px}
    .btn-green{background:#2A9626;color:#fff;border:none;border-radius:10px;padding:.45rem .7rem;font-weight:900;cursor:pointer}
    .btn-mini{background:#fff;color:#222;border:1px solid #ddd;border-radius:10px;padding:.35rem .55rem;font-weight:800;cursor:pointer}

    .card-body{padding:.45rem .7rem}
    .card-body.hidden{display:none}
    .row{display:flex;justify-content:space-between;align-items:center;border:1px solid #f0f0f0;border-radius:8px;padding:.35rem .5rem;margin:.3rem 0;background:#fff}
    .row-del{background:#ffebee;color:#c62828;border:none;border-radius:8px;padding:.2rem .45rem;font-weight:800;cursor:pointer}
    .empty{color:#888;font-style:italic}

    .charts{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:.6rem;margin-top:.6rem}
  `;
  document.head.appendChild(css);
}