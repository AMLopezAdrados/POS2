// 📦 4_ui.js — Hoofd-UI module

// Importeren van state-getters om globale afhankelijkheden te vermijden
import { getActieveSessieRef } from './1_sessiebeheer.js';
import { db } from './3_data.js';

// ============ Globale UI Helpers ============

/** Sluit alle geopende modals veilig. */
export function closeAllModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.remove());
    document.body.classList.remove('modal-open');
}

/** Toont een laad-indicator. */
export function showLoading(msg = 'Laden…') {
    let overlay = document.getElementById('loadingOverlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.innerHTML = `<div class="loading-spinner"></div><p>${msg}</p>`;
        document.body.append(overlay);
    }
    overlay.querySelector('p').textContent = msg;
    overlay.style.display = 'flex';
}

/** Verbergt de laad-indicator. */
export function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) overlay.style.display = 'none';
}

/** Toont een tijdelijke notificatie (toast). */
export function showAlert(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.append(toast);
    setTimeout(() => toast.remove(), 2500);
}

// ============ Hoofd-UI Rendering ============

/** Bouwt en toont de volledige hoofdinterface van de applicatie. */
export async function showMainMenu() {
    const app = document.getElementById('app');
    if (!app) return;

    // Verwijder oude content en injecteer de basisstructuur & styles
    app.innerHTML = `
        <header id="appTopbar"></header>
        <main id="mainContent">
            <div id="omzetMount"></div>
            <div id="salesMount"></div>
        </main>
    `;
    injectCoreStylesOnce();

    // Bouw de dynamische onderdelen
    renderTopbar();
    ensureSidebar(); // Bouwt de sidebar als deze nog niet bestaat
    await renderOmzetCard();

    // Als er een actieve sessie is, toon direct het verkoopscherm
    const actieveSessie = getActieveSessieRef()?.sessie;
    if (actieveSessie?.endTime === 'OPEN') {
        const { toonVerkoopKnoppen } = await import('./8_verkoopscherm.js');
        await toonVerkoopKnoppen();
    }
}

// ============ Topbar ============

function renderTopbar() {
    const topbarMount = document.getElementById('appTopbar');
    if (!topbarMount) return;

    const actieveSessieRef = getActieveSessieRef();
    const title = getActiveTitle(actieveSessieRef);

    topbarMount.className = 'app-topbar';
    topbarMount.innerHTML = `
        <div class="tb-left">
            <button id="burgerBtn" class="tb-btn" aria-label="Open menu">☰</button>
            <div class="tb-title">${title}</div>
        </div>
        <div class="tb-right">
            <span id="netBadge" title="Netwerkstatus"></span>
            <button id="sessionOverviewBtn" class="tb-btn" title="Sessieoverzicht">📊</button>
        </div>
    `;

    // Koppel event listeners
    document.getElementById('burgerBtn').onclick = () => toggleSidebar(true);
    document.getElementById('sessionOverviewBtn').onclick = async () => {
        const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
        const ref = getActieveSessieRef();
        openSessionOverviewModal(ref?.eventId, ref?.sessieId, ref?.event?.naam);
    };

    updateNetworkStatus(); // Zet de initiële status
}

function getActiveTitle(actieveSessieRef) {
    if (actieveSessieRef?.event && actieveSessieRef.sessie?.endTime === 'OPEN') {
        return `${actieveSessieRef.event.naam} • ${actieveSessieRef.event.locatie || ''}`.trim();
    }
    const actieveEvents = (db.evenementen || []).filter(e => e.state === 'active');
    return actieveEvents.length ? `${actieveEvents[0].naam} • ${actieveEvents[0].locatie || ''}` : "Olga's Cheese POS";
}

// Netwerkstatus listener (wordt maar 1x gekoppeld)
let networkListenersAttached = false;
function updateNetworkStatus() {
    const badge = document.getElementById('netBadge');
    if (!badge) return;
    const isOnline = navigator.onLine;
    badge.className = isOnline ? 'net ok' : 'net off';
    badge.title = isOnline ? 'Online' : 'Offline';

    if (!networkListenersAttached) {
        window.addEventListener('online', updateNetworkStatus);
        window.addEventListener('offline', updateNetworkStatus);
        networkListenersAttached = true;
    }
}

// ============ Sidebar (de enige, samengevoegde versie) ============

const toggleSidebar = (open) => {
    const sidebar = document.getElementById('app-sidebar');
    if (sidebar) sidebar.classList.toggle('open', open);
};

// Actie-handler voor de sidebar om codeherhaling te vermijden
const sidebarActionHandler = async (action) => {
    toggleSidebar(false); // Sluit altijd de sidebar na een klik
    try {
        const ref = getActieveSessieRef();
        switch (action) {
            case 'start':
                (await import('./1_sessiebeheer.js')).startSession();
                break;
            case 'close':
                if (!ref?.sessie) return showAlert('Geen actieve sessie om te sluiten.', 'warning');
                (await import('./1_sessiebeheer.js')).sluitDagAf();
                break;
            case 'overview':
                (await import('./12_sessieDetails.js')).openSessionOverviewModal(ref?.eventId, ref?.sessieId, ref?.event?.naam);
                break;
            case 'meta':
                (await import('./4_ui.js')).openSessionMetaModal();
                break;
            case 'voorraad':
                (await import('./6_beheerVoorraad.js')).toonVoorraadModal();
                break;
            case 'events':
                (await import('./5_eventbeheer.js')).toonEvenementenMenu();
                break;
            case 'reis':
                (await import('./14_reisPlanning.js')).openReisPlannerModal();
                break;
            case 'gebruikers':
                (await import('./11_gebruikersbeheer.js')).beheerGebruikers();
                break;
            case 'inzichten':
                (await import('./17_inzichten.js')).openInzichtenModal();
                break;
        }
    } catch (err) {
        console.error(`Sidebar actie '${action}' mislukt:`, err);
        showAlert('Actie kon niet worden uitgevoerd.', 'error');
    }
};

function ensureSidebar() {
    if (document.getElementById('app-sidebar')) return;

    const user = JSON.parse(localStorage.getItem('gebruiker') || '{}');
    const isAdmin = user?.role === 'admin';

    const sidebar = document.createElement('aside');
    sidebar.id = 'app-sidebar';
    sidebar.innerHTML = `
        <div class="sidebar-overlay"></div>
        <nav class="sidebar-panel">
            <div class="sidebar-head">
                <div class="brand">Olga’s Cheese POS</div>
                <button class="sidebar-close" aria-label="Sluiten">✕</button>
            </div>
            <div class="sidebar-content">
                <section>
                    <div class="sidebar-title">Sessie</div>
                    <button data-action="start">📅 Dagstart / Hervatten</button>
                    <button data-action="close">🔒 Dagafsluiting</button>
                    <button data-action="overview">📊 Sessieoverzicht</button>
                    <button data-action="meta">ℹ️ Sessie-gegevens</button>
                </section>
                <section>
                    <div class="sidebar-title">Beheer</div>
                    <button data-action="voorraad">📦 Voorraad</button>
                    <button data-action="events">🎪 Evenementen</button>
                    <button data-action="reis">✈️ Reisplanner</button>
                    ${isAdmin ? `<button data-action="gebruikers">👤 Gebruikers</button>` : ''}
                </section>
                <section>
                    <div class="sidebar-title">Inzichten</div>
                    <button data-action="inzichten">📈 Inzichten</button>
                </section>
            </div>
        </nav>
    `;
    document.body.append(sidebar);

    // Koppel events
    sidebar.querySelector('.sidebar-overlay').onclick = () => toggleSidebar(false);
    sidebar.querySelector('.sidebar-close').onclick = () => toggleSidebar(false);
    sidebar.querySelectorAll('[data-action]').forEach(btn => {
        btn.onclick = () => sidebarActionHandler(btn.dataset.action);
    });
}


// ============ Omzetkaart ============

export async function renderOmzetCard() {
    const mount = document.getElementById('omzetMount');
    if (!mount) return;

    let title = 'Omzet vandaag (alle sessies)';
    let totalUSD = 0, totalEUR = 0, klanten = 0;
    const ref = getActieveSessieRef();

    try {
        if (ref?.eventId && ref?.sessieId) {
            const { getSessionOverview } = await import('./12_sessieDetails.js');
            const overview = await getSessionOverview(ref.eventId, ref.sessieId);
            totalUSD = Number(overview?.totalUSD || 0);
            totalEUR = Number(overview?.totalEUR || 0);
            klanten = overview?.verkopen?.length || 0;
            title = `${ref.event?.naam || 'Huidige Sessie'} — omzet`;
        }
    } catch (err) {
        console.warn("Kon omzetdata niet laden:", err);
    }

    mount.innerHTML = `
        <div id="omzetCard" class="omzet-card" role="button" tabindex="0">
            <div class="omzet-title">💰 ${title}</div>
            <div class="omzet-values">$ ${totalUSD.toFixed(2)} &nbsp; • &nbsp; € ${totalEUR.toFixed(2)}</div>
            <div class="omzet-sub">${klanten} klanten • Tik voor details</div>
        </div>
    `;

    mount.querySelector('#omzetCard').onclick = async () => {
        const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
        openSessionOverviewModal(ref?.eventId, ref?.sessieId, ref?.event?.naam);
    };
}


// ============ Sessie Meta Modal ============

export function openSessionMetaModal() {
    const ref = getActieveSessieRef();
    if (!ref?.event || !ref?.sessie) {
        return showAlert('Geen actieve sessie gevonden.', 'warning');
    }

    closeAllModals(); // Sluit eerst andere modals

    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    const s = ref.sessie, e = ref.event;
    
    // Functie om rijen te genereren
    const createRow = (label, value) => `<strong>${label}</strong><div>${value || '-'}</div>`;

    modal.innerHTML = `
        <div class="modal-box">
            <button class="modal-close">✕</button>
            <h2>Sessiegegevens</h2>
            <div class="modal-grid">
                ${createRow('Event', e.naam)}
                ${createRow('Locatie', e.locatie)}
                ${createRow('Sessie-ID', s.id)}
                ${createRow('Gestart', new Date(s.startTime).toLocaleString('nl-NL'))}
                ${createRow('Status', s.endTime === 'OPEN' ? '🟢 OPEN' : '🔴 GESLOTEN')}
                ${createRow('Valuta', (s.valuta || 'USD').toUpperCase())}
            </div>
            <div class="modal-actions">
                <button id="modalOverviewBtn">📊 Sessieoverzicht</button>
            </div>
        </div>
    `;
    document.body.append(modal);
    document.body.classList.add('modal-open');

    // Events koppelen
    modal.querySelector('.modal-close').onclick = () => modal.remove();
    modal.querySelector('#modalOverviewBtn').onclick = async () => {
        modal.remove();
        const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
        openSessionOverviewModal(e.id, s.id, e.naam);
    };
}


// ============ Styles (eenmalig injecteren) ============

function injectCoreStylesOnce() {
    if (document.getElementById('core-ui-styles')) return;
    document.head.insertAdjacentHTML('beforeend', `
        <style id="core-ui-styles">
            /* Globals */
            body { margin: 0; background: #f4f5f7; font-family: sans-serif; }
            #app { display: flex; flex-direction: column; min-height: 100vh; }
            main { flex-grow: 1; padding: .6rem; display: flex; flex-direction: column; gap: .7rem; }

            /* Topbar */
            .app-topbar {
                position: sticky; top: 0; z-index: 50; display: flex; align-items: center; justify-content: space-between;
                background: #2A9626; color: #fff; padding: .6rem .8rem; box-shadow: 0 2px 8px rgba(0,0,0,.15);
            }
            .tb-left, .tb-right { display: flex; align-items: center; gap: .5rem; }
            .tb-btn { background: rgba(255,255,255,.18); border: 1px solid rgba(255,255,255,.3); color: #fff; padding: .4rem .6rem; border-radius: .6rem; font-weight: 800; cursor: pointer; }
            .tb-title { font-weight: 900; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
            .net { width: 12px; height: 12px; border-radius: 50%; }
            .net.ok { background: #9AE66E; } .net.off { background: #FF7043; }

            /* Sidebar */
            #app-sidebar { position: fixed; inset: 0; z-index: 100; pointer-events: none; }
            #app-sidebar.open { pointer-events: auto; }
            .sidebar-overlay { position: absolute; inset: 0; background: rgba(0,0,0,.4); opacity: 0; transition: opacity .2s; }
            #app-sidebar.open .sidebar-overlay { opacity: 1; }
            .sidebar-panel {
                position: absolute; top: 0; left: 0; bottom: 0; width: min(360px, 88vw);
                background: #fff; transform: translateX(-100%); transition: transform .25s ease;
                box-shadow: 2px 0 16px rgba(0,0,0,.25); display: flex; flex-direction: column;
            }
            #app-sidebar.open .sidebar-panel { transform: translateX(0); }
            .sidebar-head { display: flex; justify-content: space-between; align-items: center; padding: .8rem 1rem; background: #1F6D1C; color: #fff; }
            .sidebar-head .brand { font-weight: 900; }
            .sidebar-close { background: #fff; color: #1F6D1C; border: none; border-radius: .5rem; padding: .3rem .6rem; font-weight: 900; cursor: pointer; }
            .sidebar-content { padding: .6rem; overflow-y: auto; }
            .sidebar-content section { margin-bottom: 1rem; }
            .sidebar-title { font-weight: 900; color: #2A9626; margin: .4rem 0 .6rem; }
            .sidebar-content button {
                display: block; width: 100%; text-align: left; border: none; border-radius: .6rem;
                padding: .7rem .9rem; margin: .3rem 0; font-weight: 800; cursor: pointer;
                background: #ffc500; color: #1F6D1C;
            }

            /* Omzet Card */
            .omzet-card { background: #2A9626; color: #fff; border-radius: .9rem; padding: 1rem; box-shadow: 0 4px 12px rgba(0,0,0,.1); text-align: center; cursor: pointer; }
            .omzet-title { font-weight: 900; }
            .omzet-values { font-weight: 900; font-size: 1.6rem; margin: .2rem 0; }
            .omzet-sub { opacity: .9; font-size: 0.9rem; }

            /* Modals */
            .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 200; }
            .modal-box { position: relative; background: #fff; padding: 1.5rem; border-radius: 12px; width: min(92vw, 560px); max-height: 85vh; overflow-y: auto; }
            .modal-close { position: absolute; top: 8px; right: 8px; background: #eee; border: none; border-radius: 50%; width: 32px; height: 32px; font-weight: bold; cursor: pointer; }
            .modal-grid { display: grid; grid-template-columns: auto 1fr; gap: .5rem 1rem; margin-top: 1rem; }
            .modal-actions { display: flex; gap: .5rem; margin-top: 1.2rem; }
            .modal-actions button { background: #2A9626; color: #fff; border: none; border-radius: 8px; padding: .6rem 1rem; font-weight: 800; cursor: pointer; }
            
            /* Toasts & Loading */
            .toast { position: fixed; left: 50%; bottom: 20px; transform: translateX(-50%); color: #fff; padding: .7rem 1rem; border-radius: .7rem; font-weight: 800; box-shadow: 0 4px 12px rgba(0,0,0,.2); z-index: 1000; }
            .toast-info { background: #2A9626; } .toast-success { background: #2E7D32; } .toast-warning { background: #FB8C00; } .toast-error { background: #C62828; }
            #loadingOverlay { position: fixed; inset: 0; background: rgba(255,255,255,.9); display: none; align-items: center; justify-content: center; flex-direction: column; z-index: 9999; font-size: 1.5rem; font-weight: 800; color: #2A9626; }
        </style>
    `);
}