// 📦 12_sessieDetails.js – Sessie-overzicht (memory + verkoopManager-first)

import { db, saveVoorraad } from './3_data.js';
import { verkoopManager } from './16_VerkoopManager.js';

// (placeholder om consistent te blijven met eerdere exports)
export async function initSessionDetails() {}

/* ===========================
 * Open sessies uit db.evenementen
 * =========================== */
export function getOpenSessions() {
  const events = Array.isArray(db?.evenementen) ? db.evenementen : [];
  const keuze = [];
  for (const evt of events) {
    if (evt?.state !== 'active') continue;
    const sessions = Array.isArray(evt.sessions) ? evt.sessions : Object.values(evt.sessions || {});
    for (const s of sessions) {
      if (s?.endTime === 'OPEN') {
        const label = `${evt.naam} – ${new Date(s.startTime).toLocaleString('nl-NL')}`;
        keuze.push({ eventId: evt.id, sessionId: s.id, label, eventNaam: evt.naam });
      }
    }
  }
  return keuze;
}

/* ===========================
 * Overzicht per sessie
 * - ALTIJD verkoopManager gebruiken
 * - Bazaar: alleen opgehaalde tassen meetellen
 * =========================== */
export async function getSessionOverview(eventId, sessionId, eventNaamOpt) {
  const evt = (db?.evenementen || []).find(e => e.id === eventId);
  if (!evt) throw new Error(`Event ${eventId} niet gevonden`);
  const eventNaam = eventNaamOpt || evt.naam;

  // 1) Sessies uit verkoopManager (await!):
  const vmSessions = await verkoopManager.getSessions(eventNaam);
  const sess = (Array.isArray(vmSessions) ? vmSessions : []).find(s => s?.id === sessionId);

  // 2) Fallback: sessie uit evt.sessions
  const evtSessionsArr = Array.isArray(evt.sessions) ? evt.sessions : Object.values(evt.sessions || {});
  const fallbackSess = evtSessionsArr.find(s => s?.id === sessionId);

  // 3) Verkopen bepalen
  let verkopen = Array.isArray(sess?.verkopen) ? sess.verkopen
               : Array.isArray(fallbackSess?.verkopen) ? fallbackSess.verkopen
               : [];
  if (!Array.isArray(verkopen)) verkopen = [];

  // 4) Bazaar: alleen opbrengst tellen van opgehaalde tassen of losse items (zonder tasNr)
  const gefilterd = (evt.type === 'Bazaar')
    ? verkopen.filter(v => !v.tasNr || v.status === 'opgehaald')
    : verkopen;

  // 5) Totals per product (met valuta-fallbacks op sessiekoers)
  const exchangeRate = Number((sess?.exchangeRate ?? fallbackSess?.exchangeRate) || 0); // USD→EUR
  const summaryMap = {};
  let totalQuantity = 0, totalEUR = 0, totalUSD = 0;

  for (const sale of gefilterd) {
    const product = sale?.product;
    if (!product) continue;

    // Prijs in USD/EUR robuust berekenen
    const usd = (typeof sale.prijs_usd === 'number')
      ? sale.prijs_usd
      : (typeof sale.prijs_eur === 'number' && exchangeRate ? sale.prijs_eur / exchangeRate : 0);

    const eur = (typeof sale.prijs_eur === 'number')
      ? sale.prijs_eur
      : (typeof sale.prijs_usd === 'number' && exchangeRate ? sale.prijs_usd * exchangeRate : 0);

    if (!summaryMap[product]) summaryMap[product] = { product, quantity: 0, subtotalEUR: 0, subtotalUSD: 0 };
    summaryMap[product].quantity += 1;
    summaryMap[product].subtotalEUR += eur || 0;
    summaryMap[product].subtotalUSD += usd || 0;

    totalQuantity += 1;
    totalEUR += eur || 0;
    totalUSD += usd || 0;
  }

  return {
    eventName: evt.naam,
    startTime: sess?.startTime || fallbackSess?.startTime || null,
    items: Object.values(summaryMap),
    totalQuantity,
    totalEUR,
    totalUSD,
    verkopen,
    sessie: sess || fallbackSess || null,
    event: evt
  };
}

/* ===========================
 * Groepeer verkopen per tijdstip
 * =========================== */
export function getVerkoopMomenten(verkopen) {
  const map = {};
  (verkopen || []).forEach((v, i) => {
    const tijdSec = new Date(v.tijd).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (!map[tijdSec]) map[tijdSec] = [];
    map[tijdSec].push({ ...v, _index: i });
  });
  return Object.entries(map).map(([tijd, lijst]) => {
    const totaalUSD = lijst.reduce((s, v) => s + (v.prijs_usd || 0), 0);
    const totaalEUR = lijst.reduce((s, v) => s + (v.prijs_eur || 0), 0);
    return { tijd, producten: lijst, totaalUSD, totaalEUR };
  });
}

/* ===========================
 * Modal met tabs: samenvatting / individueel / tassen
 * =========================== */
export async function openSessionOverviewModal(eventId, sessionId, eventNaam) {
  const overzicht = await getSessionOverview(eventId, sessionId, eventNaam);
  if (!overzicht) {
    alert('Geen data voor deze sessie.');
    return;
  }
  const momenten = getVerkoopMomenten(overzicht.verkopen);

  const overlay = document.createElement('div');
  overlay.className = 'modal';
  document.body.appendChild(overlay);

  const modal = document.createElement('div');
  Object.assign(modal.style, {
    background: '#fff',
    padding: '1rem',
    borderRadius: '12px',
    width: '90%',
    maxWidth: '700px',
    maxHeight: '90vh',
    overflowY: 'auto',
    boxShadow: '0 0 12px rgba(0,0,0,0.2)',
    position: 'relative'
  });
  overlay.appendChild(modal);

  const sluit = document.createElement('button');
  sluit.textContent = '✕';
  Object.assign(sluit.style, {
    position: 'absolute',
    top: '8px',
    right: '12px',
    fontSize: '20px',
    background: '#FFC500',
    border: 'none',
    cursor: 'pointer'
  });
  sluit.onclick = () => overlay.remove();
  modal.appendChild(sluit);

  const titel = document.createElement('h2');
  titel.textContent = 'Sessieoverzicht';
  titel.style.color = '#2A9626';
  modal.appendChild(titel);

  // tabs
  const tabs = document.createElement('div');
  Object.assign(tabs.style, { display: 'flex', gap: '1rem', marginBottom: '1rem' });

  const tab1 = document.createElement('button'); tab1.textContent = '📦 Per product';
  const tab2 = document.createElement('button'); tab2.textContent = '🕒 Individueel';
  const tab3 = document.createElement('button'); tab3.textContent = '🧺 Tassen';

  for (const t of [tab1, tab2, tab3]) {
    Object.assign(t.style, { padding: '0.5rem 1rem', borderRadius: '8px', border: 'none', cursor: 'pointer', background: '#eee' });
  }
  tab1.style.background = '#2A9626'; tab1.style.color = '#fff';

  tabs.append(tab1, tab2, tab3);
  modal.appendChild(tabs);

  const content = document.createElement('div');
  modal.appendChild(content);

  const renderSamenvatting = () => {
    content.innerHTML = '';
    content.appendChild(renderSessionOverviewTable(overzicht));
  };

  const renderMomenten = () => {
    content.innerHTML = '';
    momenten.forEach(m => {
      const wrapper = document.createElement('div');
      Object.assign(wrapper.style, { marginBottom: '1rem', border: '1px solid #ddd', borderRadius: '8px', padding: '0.5rem' });

      const header = document.createElement('div');
      header.innerHTML = `<b>${m.tijd}</b> – 💶 €${m.totaalEUR.toFixed(2)} / 💵 $${m.totaalUSD.toFixed(2)}`;
      header.style.cursor = 'pointer';
      header.style.marginBottom = '0.3rem';
      wrapper.appendChild(header);

      const lijst = document.createElement('ul');
      Object.assign(lijst.style, { listStyle: 'none', margin: 0, paddingLeft: '1rem', display: 'none' });

      m.producten.forEach((v) => {
        const li = document.createElement('li');
        li.innerHTML = `• ${v.product} <button style="margin-left:8px;" data-index="${v._index}">❌</button>`;
        lijst.appendChild(li);
      });

      header.onclick = () => {
        lijst.style.display = (lijst.style.display === 'none' ? 'block' : 'none');
      };

      wrapper.appendChild(lijst);
      content.appendChild(wrapper);
    });

    // verwijderen van individuele verkoopregel
    content.querySelectorAll('button[data-index]').forEach(btn => {
      btn.onclick = async () => {
        const idx = parseInt(btn.dataset.index);
        if (Number.isNaN(idx)) return;

        // 1) voorraad terugzetten
        const verkoop = overzicht.sessie?.verkopen?.[idx];
        const productNaam = verkoop?.product;
        const bus = overzicht.event?.bus || 'Rene';
        if (productNaam) {
          db.voorraad = db.voorraad || {};
          db.voorraad[bus] = db.voorraad[bus] || {};
          db.voorraad[bus][productNaam] = (db.voorraad[bus][productNaam] || 0) + 1;
        }

        // 2) verkoopregel verwijderen via VerkoopManager
        await verkoopManager.removeVerkoop(overzicht.eventName, overzicht.sessie.id, idx);
        await saveVoorraad();

        // 3) modal heropbouwen
        overlay.remove();
        // Optioneel kaartje verversen als aanwezig
        window.updateOmzetCard?.();
        openSessionOverviewModal(eventId, sessionId, eventNaam);
      };
    });
  };

  const renderTassen = () => {
    content.innerHTML = '';
    const tassen = (overzicht.verkopen || []).filter(v => v.tasNr).reduce((map, v) => {
      if (!map[v.tasNr]) map[v.tasNr] = [];
      map[v.tasNr].push(v);
      return map;
    }, {});

    if (Object.keys(tassen).length === 0) {
      content.innerHTML = '<p style="color:#666;">Geen tassen gevonden.</p>';
      return;
    }

    Object.entries(tassen).forEach(([tasNr, lijst]) => {
      const totaal = lijst.reduce((s, v) => s + (v.prijs_eur || 0), 0);
      const status = lijst.some(v => v.status === 'opgehaald') ? '✅ Opgehaald' : '🟢 Open';

      const wrapper = document.createElement('div');
      Object.assign(wrapper.style, { marginBottom: '1rem', border: '1px solid #ccc', borderRadius: '8px', padding: '0.7rem' });

      wrapper.innerHTML = `
        <div><b>Tas ${tasNr}</b> – €${totaal.toFixed(2)} – ${status}</div>
        <ul style="margin:0.5rem 0 0 1rem; padding:0;">${lijst.map(v => `<li>• ${v.product}</li>`).join('')}</ul>
      `;

      content.appendChild(wrapper);
    });
  };

  // tab handlers
  tab1.onclick = () => {
    tab1.style.background = '#2A9626'; tab1.style.color = '#fff';
    tab2.style.background = '#eee'; tab2.style.color = 'black';
    tab3.style.background = '#eee'; tab3.style.color = 'black';
    renderSamenvatting();
  };

  tab2.onclick = () => {
    tab2.style.background = '#2A9626'; tab2.style.color = '#fff';
    tab1.style.background = '#eee'; tab1.style.color = 'black';
    tab3.style.background = '#eee'; tab3.style.color = 'black';
    renderMomenten();
  };

  tab3.onclick = () => {
    tab3.style.background = '#2A9626'; tab3.style.color = '#fff';
    tab1.style.background = '#eee'; tab1.style.color = 'black';
    tab2.style.background = '#eee'; tab2.style.color = 'black';
    renderTassen();
  };

  renderSamenvatting();
}

/* ===========================
 * Tabelweergave samenvatting
 * =========================== */
export function renderSessionOverviewTable(overview) {
  const table = document.createElement('table');
  table.style.cssText = 'width:100%; border-collapse: collapse; font-size:15px;';

  const thStyle = 'text-align:left; padding:6px 8px; border-bottom:1px solid #ccc;';
  const tdStyle = 'padding:6px 8px; border-bottom:1px solid #eee;';

  table.innerHTML = `
    <thead>
      <tr>
        <th style="${thStyle}">Product</th>
        <th style="${thStyle}">Aantal</th>
        <th style="${thStyle}">Subtotaal EUR</th>
        <th style="${thStyle}">Subtotaal USD</th>
      </tr>
    </thead>
    <tbody>
      ${overview.items.map(item => `
        <tr>
          <td style="${tdStyle}">${item.product}</td>
          <td style="${tdStyle}">${item.quantity}</td>
          <td style="${tdStyle}">€ ${item.subtotalEUR.toFixed(2)}</td>
          <td style="${tdStyle}">$ ${item.subtotalUSD.toFixed(2)}</td>
        </tr>
      `).join('')}
      <tr>
        <td style="padding:8px; font-weight:bold;">TOTAAL</td>
        <td style="padding:8px; font-weight:bold;">${overview.totalQuantity}</td>
        <td style="padding:8px; font-weight:bold;">€ ${overview.totalEUR.toFixed(2)}</td>
        <td style="padding:8px; font-weight:bold;">$ ${overview.totalUSD.toFixed(2)}</td>
      </tr>
    </tbody>
  `;
  return table;
}
