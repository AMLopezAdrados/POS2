// 📦 3_data.js – Centrale datahandling Olga’s Cheese POS met verkoopManager (SHELL-compatible)

import { showLoading, hideLoading, showAlert } from './4_ui.js';
import { openSnijkaasModal, sluitSnijkaasModal } from './10_snijkaas.js';
import { toonVoorraadModal } from './6_beheerVoorraad.js';
import { upgradeGebruikersData } from './11_gebruikersbeheer.js';
import { verkoopManager } from './16_VerkoopManager.js';

export const db = {
  producten: [],
  voorraad: {},
  evenementen: [],
  wisselkoersen: [],
  gebruikers: [],
  kosten: [],
  reizen: []
};

async function fetchWithRetry(url, retries = 1, delay = 30000) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (err) {
    console.warn("🔁 Retry attempt due to fetch error:", err);
    if (retries > 0) {
      await new Promise(res => setTimeout(res, delay));
      return fetchWithRetry(url, retries - 1, delay);
    }
    throw err;
  }
}

// --------- Centrale loadData ---------
export async function loadData(retries = 3, delayMs = 5000) {
  const nocache = '?t=' + Date.now();
  try {
    // 1) Basisdata ophalen
    const [
      productenData,
      voorraadData,
      evenementenData,
      koersenData,
      gebruikersData,
      reizenData
    ] = await Promise.all([
      fetchWithRetry('/api/products.json' + nocache),
      fetchWithRetry('/api/voorraad.json' + nocache),
      fetchWithRetry('/api/evenementen.json' + nocache),
      fetchWithRetry('/api/wisselkoersen.json' + nocache),
      fetchWithRetry('/api/gebruikers.json' + nocache),
      fetchWithRetry('/api/reizen.json' + nocache)
    ]);

    db.producten     = Array.isArray(productenData) ? productenData : [];
    db.voorraad      = typeof voorraadData === 'object' && voorraadData ? voorraadData : {};
    db.evenementen   = Array.isArray(evenementenData) ? evenementenData : [];
    db.wisselkoersen = Array.isArray(koersenData) ? koersenData : [];
    db.gebruikers    = Array.isArray(gebruikersData) ? gebruikersData : [];
    db.reizen        = Array.isArray(reizenData?.reizen) ? reizenData.reizen : (Array.isArray(reizenData) ? reizenData : []);

    // 1b) Event normalisatie (defensief)
    db.evenementen.forEach(evt => {
      if (!Array.isArray(evt.sessions)) evt.sessions = [];    // sessions nooit undefined
      if (evt.persoon && !evt.personen) {                    // oude -> nieuwe structuur
        evt.personen = [evt.persoon];
        delete evt.persoon;
      }
    });

    // 1c) Optionele migratie van gebruikersdata (best effort)
    try { upgradeGebruikersData?.(db.gebruikers); } catch {}

    // 2) SESSIES ALTIJD via verkoopManager laden en koppelen
    await Promise.all(db.evenementen.map(async (event) => {
      try {
        await verkoopManager.load(event.naam);
        let sessions = await verkoopManager.getSessions(event.naam);
        if (!Array.isArray(sessions)) sessions = [];

        // weekdag-tag toevoegen (zo/ma/di/wo/do/vr/za)
        for (const sessie of sessions) {
          try {
            if (sessie?.startTime) {
              const d = new Date(sessie.startTime);
              const idx = isNaN(d.getDay()) ? 0 : d.getDay();
              sessie.weekdag = ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'][idx];
            }
          } catch {}
        }

        event.sessions = sessions;
      } catch (err) {
        console.warn(`⚠️ Geen sessie-data via verkoopManager voor event "${event?.naam}":`, err);
        event.sessions = [];
      }
    }));

    // 3) Actieve sessie ref herstellen (met éénmalige retry als sessions leeg waren)
    restoreActieveSessieRef(/* allowRetry */ true);

    console.log("✅ Alle data geladen:", db);
  } catch (err) {
    console.error("❌ Fout bij laden:", err);
    if (retries > 0) {
      await new Promise(resolve => setTimeout(resolve, delayMs));
      return loadData(retries - 1, delayMs);
    }
  }
}

// --------- Actieve sessie ref herstellen ---------
/**
 * Herstelt window.actieveSessieRef vanuit localStorage als event + sessie nog bestaan.
 * Doet optioneel éénmalig een retry (1.2s) wanneer sessions nog leeg zijn.
 */
export function restoreActieveSessieRef(allowRetry = false) {
  let ref = null;
  try {
    ref = JSON.parse(localStorage.getItem("actieveSessieRef"));
  } catch { ref = null; }

  if (!ref?.eventId || !ref?.sessieId) {
    window.actieveSessieRef = null;
    window.refreshAppShell?.();
    return;
  }

  const event = db.evenementen.find(e => e.id === ref.eventId);

  // Als event bekend is maar de sessions nog niet binnen waren, éénmalig retry
  if (allowRetry && event && Array.isArray(event.sessions) && event.sessions.length === 0) {
    setTimeout(() => restoreActieveSessieRef(false), 1200);
    return;
  }

  const sessie = (event && Array.isArray(event.sessions))
    ? event.sessions.find(s => s.id === ref.sessieId)
    : null;

  if (event && sessie && sessie.endTime === "OPEN") {
    window.actieveSessieRef = { eventId: event.id, sessieId: sessie.id, event, sessie };
    try { sessie._parentEvent = event; } catch {}
    localStorage.setItem("actieveSessieRef", JSON.stringify({ eventId: event.id, sessieId: sessie.id }));
    console.log("✅ Actieve sessie hersteld uit data:", window.actieveSessieRef);
    // Shell laten hertekenen
    window.refreshAppShell?.();
  } else {
    window.actieveSessieRef = null;
    localStorage.removeItem("actieveSessieRef");
    try { showAlert?.("Vorige sessie niet meer gevonden of afgesloten.", "info"); } catch {}
    window.refreshAppShell?.();
  }
}

// --------- Standaard save functies ---------
export async function saveVoorraad() {
  try {
    showLoading?.();
    const response = await fetch('/api/save_voorraad.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(db.voorraad)
    });
    hideLoading?.();
    if (!response.ok) throw new Error(await response.text());
    console.log("✅ Voorraad opgeslagen.");
  } catch (err) {
    hideLoading?.();
    console.error("❌ Voorraad opslaan mislukt:", err);
  }
}

export async function saveEvent(eventId) {
  try {
    const event = db.evenementen.find(e => e.id === eventId);
    if (!event) {
      console.error(`❌ Event niet gevonden: ${eventId}`);
      return;
    }

    // Sla event op ZONDER sessions!
    const { sessions, ...eventZonderSessions } = event;

    // JSON-safe clone (verwijder evt. _parentEvent refs)
    const cleanEvent = JSON.parse(JSON.stringify(eventZonderSessions, (key, value) => {
      if (key === "_parentEvent") return undefined;
      return value;
    }));

    showLoading?.();
    const res = await fetch('/api/save_evenement.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cleanEvent)
    });
    hideLoading?.();
    if (!res.ok) throw new Error(await res.text());
    console.log(`✅ Event opgeslagen: ${event.naam}`);
  } catch (err) {
    hideLoading?.();
    console.error("❌ Fout bij saveEvent():", err);
    try { alert("⚠️ Opslaan van evenement mislukt."); } catch {}
  }
}

export async function saveProducten() {
  try {
    showLoading?.();
    const response = await fetch('/api/save_producten.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(db.producten)
    });
    hideLoading?.();
    if (!response.ok) throw new Error(await response.text());
    console.log("✅ Producten opgeslagen.");
  } catch (err) {
    hideLoading?.();
    console.error("❌ Fout bij saveProducten():", err);
  }
}

export async function saveGebruiker(gebruikersArray) {
  try {
    showLoading?.();
    const response = await fetch('/api/save_users.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(gebruikersArray)
    });
    hideLoading?.();
    if (!response.ok) throw new Error(await response.text());
    console.log("✅ Gebruikers opgeslagen.");
  } catch (err) {
    hideLoading?.();
    console.error("❌ Fout bij saveGebruiker():", err);
  }
}

// --------- Voorraad/producten/evenementen herladen ---------
export async function reloadVoorraad() {
  try {
    const response = await fetch('/api/voorraad.json?t=' + Date.now());
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    db.voorraad = await response.json();
    console.log("🔄 Voorraad herladen.");
    refreshAlleVoorraadWeergaves();
  } catch (err) {
    console.error("❌ Voorraad herladen mislukt:", err);
  }
}

export async function reloadProducten() {
  try {
    const response = await fetch('/api/products.json?t=' + Date.now());
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    db.producten = await response.json();
    console.log("🔄 Producten herladen.");
    // Shell laten hertekenen (knoppen/productgrid kan zich aanpassen)
    window.refreshAppShell?.();
  } catch (err) {
    console.error("❌ Producten herladen mislukt:", err);
  }
}

export async function reloadEvenementen() {
  try {
    const response = await fetch('/api/evenementen.json?t=' + Date.now());
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    db.evenementen = await response.json();

    // Normaliseer
    db.evenementen.forEach(evt => {
      if (!Array.isArray(evt.sessions)) evt.sessions = [];
    });

    console.log("🔄 Evenementen herladen.");

    // Sessies via verkoopManager ophalen (consistentie)
    await Promise.all(db.evenementen.map(async (event) => {
      try {
        await verkoopManager.load(event.naam);
        let sessions = await verkoopManager.getSessions(event.naam);
        if (!Array.isArray(sessions)) sessions = [];
        sessions.forEach(sessie => {
          try {
            if (sessie?.startTime) {
              const d = new Date(sessie.startTime);
              const idx = isNaN(d.getDay()) ? 0 : d.getDay();
              sessie.weekdag = ['zo','ma','di','wo','do','vr','za'][idx];
            }
          } catch {}
        });
        event.sessions = sessions;
      } catch {
        event.sessions = [];
      }
    }));

    // Actieve sessie ref checken na herladen
    restoreActieveSessieRef(false);
  } catch (err) {
    console.error("❌ Evenementen herladen mislukt:", err);
  }
}

// --------- Helper functies ---------
export function refreshAlleVoorraadWeergaves() {
  // Laat de shell hertekenen i.p.v. oude UI aan te roepen
  window.refreshAppShell?.();
}

export function showClickBlocker() {
  if (document.getElementById("click-blocker")) return;
  const blocker = document.createElement("div");
  blocker.id = "click-blocker";
  blocker.style.cssText = `
    position: fixed;
    inset: 0;
    background: rgba(255,255,255,0.7);
    backdrop-filter: blur(2px);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5em;
    font-weight: bold;
    z-index: 9999;
  `;
  blocker.innerHTML = "⏳ Verwerken...";
  document.body.appendChild(blocker);
}

export function hideClickBlocker() {
  document.getElementById("click-blocker")?.remove();
}

// --------- Event-data (en verkoop) auto-herladen ---------
export async function autoReloadEventData(eventId) {
  try {
    // kleine debounce zodat backend klaar is
    await new Promise(res => setTimeout(res, 1200));

    const response = await fetch('/api/evenementen.json?t=' + Date.now());
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const evenementen = await response.json();

    const bijgewerkt = evenementen.find(e => e.id === eventId);
    if (!bijgewerkt) return;

    // Sessies opnieuw via verkoopManager
    try {
      await verkoopManager.load(bijgewerkt.naam);
      let sessions = await verkoopManager.getSessions(bijgewerkt.naam);
      if (!Array.isArray(sessions)) sessions = [];
      sessions.forEach(sessie => {
        try {
          if (sessie?.startTime) {
            const d = new Date(sessie.startTime);
            const idx = isNaN(d.getDay()) ? 0 : d.getDay();
            sessie.weekdag = ['zo','ma','di','wo','do','vr','za'][idx];
          }
        } catch {}
      });
      bijgewerkt.sessions = sessions;
    } catch {
      bijgewerkt.sessions = [];
    }

    if (!Array.isArray(bijgewerkt.sessions)) bijgewerkt.sessions = [];

    // In-memory db updaten
    const idx = db.evenementen.findIndex(e => e.id === eventId);
    if (idx !== -1) db.evenementen[idx] = bijgewerkt;

    // Actieve sessie opnieuw linken + UI
    restoreActieveSessieRef(false);

    console.log("✅ Event bijgewerkt na auto-reload (met verkoopManager sessions).");
  } catch (err) {
    console.error("❌ Fout bij autoReloadEventData():", err);
  }
}

// --------- Reizen opslaan ---------
export async function saveReizen() {
  try {
    showLoading?.();
    console.log("🧪 Wat zit er in db.reizen:", db.reizen);
    const response = await fetch('/api/save_reizen.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reizen: db.reizen })
    });
    hideLoading?.();
    if (!response.ok) {
      const errorText = await response.text();
      console.error("❌ Serverfout bij opslaan reizen:", errorText);
      showAlert?.("❌ Opslaan van reizen mislukt.", "error");
      return;
    }
    const result = await response.json();
    if (result.success) {
      console.log("✅ Reizen succesvol opgeslagen.");
      showAlert?.("✅ Reizen opgeslagen!", "success");
    } else {
      console.error("⚠️ Opslaan mislukt:", result.error);
      showAlert?.("⚠️ Opslaan mislukt: " + result.error, "warning");
    }
  } catch (err) {
    hideLoading?.();
    console.error("❌ Netwerkfout bij saveReizen():", err);
    showAlert?.("❌ Fout bij opslaan van reizen.", "error");
  }
}

// Globaal + named export (voor zekerheid in alle importstijlen)
window.db = db;