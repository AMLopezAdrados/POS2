// 📦 7_beheerProducten.js – Productbeheer Olga's Cheese POS

import { db, saveProducten } from './3_data.js';
import { toonVerkoopKnoppen } from './8_verkoopscherm.js';
import { toonVoorraadModal } from './6_beheerVoorraad.js';

export function openProductModal() {
  const gebruiker = JSON.parse(localStorage.getItem("gebruiker"));
  if (!gebruiker || gebruiker.role !== 'admin') {
    alert("❌ Alleen admins mogen producten beheren.");
    return;
  }

  document.querySelectorAll('.modal').forEach(m => m.remove());

  const modal = document.createElement("div");
  modal.className = "modal";

  const content = document.createElement("div");
  Object.assign(content.style, {
    background: "#fff",
    padding: "2rem",
    borderRadius: "12px",
    maxWidth: "800px",
    maxHeight: "80vh",
    overflowY: "auto",
    boxShadow: "0 0 10px rgba(0,0,0,0.3)",
    width: "95vw"
  });

  content.innerHTML = `
    <h2>📦 Productbeheer</h2>
    <table style="width:100%; border-collapse: collapse;" id="productTable">
      <thead>
        <tr><th>Naam</th><th>USD</th><th>EUR</th><th>Inkoop</th><th>Type</th><th></th></tr>
      </thead>
      <tbody id="productList">
        ${db.producten.map((p, i) => `
          <tr data-index="${i}">
            <td><input value="${p.naam}" style="width:100px"></td>
            <td><input type="number" step="0.01" value="${p.usd ?? ''}" style="width:70px"></td>
            <td><input type="number" step="0.01" value="${p.eur ?? ''}" style="width:70px"></td>
            <td><input type="number" step="0.01" value="${p.inkoop ?? ''}" style="width:70px"></td>
            <td>
              <select style="width:100px">
                <option value="BG" ${p.type === 'BG' ? 'selected' : ''}>BG</option>
                <option value="ROOK" ${p.type === 'ROOK' ? 'selected' : ''}>ROOK</option>
                <option value="GEIT" ${p.type === 'GEIT' ? 'selected' : ''}>GEIT</option>
                <option value="SOUV" ${p.type === 'SOUV' ? 'selected' : ''}>SOUV</option>
                <option value="KOEK" ${p.type === 'KOEK' ? 'selected' : ''}>KOEK</option>
                <option value="MOSTERD" ${p.type === 'MOSTERD' ? 'selected' : ''}>MOSTERD</option>
                <option value="OUD" ${p.type === 'OUD' ? 'selected' : ''}>OUD</option>
              </select>
            </td>
            <td><button onclick="window.verwijderProduct(${i})">🗑️</button></td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <hr><h3>➕ Nieuw product</h3>
    <div style="display: flex; flex-wrap: wrap; gap: 10px;">
      <input id="newNaam" placeholder="Naam" />
      <input id="newUSD" type="number" step="0.01" placeholder="USD" />
      <input id="newEUR" type="number" step="0.01" placeholder="EUR" />
      <input id="newInkoop" type="number" step="0.01" placeholder="Inkoop (EUR)" />
      <select id="newType">
        <option value="">-- Kies type --</option>
        <option value="BG">BG</option>
        <option value="ROOK">ROOK</option>
        <option value="GEIT">GEIT</option>
        <option value="SOUV">SOUV</option>
        <option value="KOEK">KOEK</option>
        <option value="MOSTERD">MOSTERD</option>
        <option value="OUD">OUD</option>
      </select>
      <button id="toevoegKnop">➕ Toevoegen</button>
    </div>

    <div style="margin-top: 1rem;">
      <button id="opslaanProducten">💾 Opslaan</button>
      <button id="sluitProductModalBtn">❌ Sluiten</button>
    </div>
  `;

  modal.appendChild(content);
  document.body.appendChild(modal);

  document.getElementById("toevoegKnop").onclick = () => {
    const naam = document.getElementById("newNaam").value.trim();
    const usd = parseFloat(document.getElementById("newUSD").value);
    const eur = parseFloat(document.getElementById("newEUR").value);
    const inkoop = parseFloat(document.getElementById("newInkoop").value);
    const type = document.getElementById("newType").value.trim().toUpperCase();

    if (!naam || isNaN(usd) || isNaN(eur) || isNaN(inkoop) || !type) {
      alert("⚠️ Vul alle velden correct in.");
      return;
    }

    db.producten.push({ naam, usd, eur, inkoop, type });
    openProductModal();
  };

  document.getElementById("opslaanProducten").onclick = async () => {
    const rows = document.querySelectorAll("#productList tr");
    if (rows.length === 0) {
      alert("❌ Geen rijen gevonden in productList");
      return;
    }

    db.producten = Array.from(rows).map(row => {
      const inputs = row.querySelectorAll("input");
      const select = row.querySelector("select");
      return {
        naam: inputs[0]?.value.trim() || "",
        usd: parseFloat(inputs[1]?.value) || 0,
        eur: parseFloat(inputs[2]?.value) || 0,
        inkoop: parseFloat(inputs[3]?.value) || 0,
        type: select?.value || ""
      };
    });

    try {
      await saveProducten();
      // Gebruik je eigen showAlert (indien gewenst), of alert:
      // showAlert("✅ Producten opgeslagen.", "success");
      alert("✅ Producten opgeslagen.");
    } catch (err) {
      alert("⚠️ Opslaan mislukt.");
    }

    document.querySelector(".modal")?.remove();
    toonVoorraadModal();
    toonVerkoopKnoppen();
  };

  document.getElementById("sluitProductModalBtn").onclick = () => {
    document.querySelector(".modal")?.remove();
    toonVoorraadModal();
    toonVerkoopKnoppen();
  };
}

// Window exposen voor inline button events
function verwijderProduct(index) {
  db.producten.splice(index, 1);
  openProductModal();
}

window.verwijderProduct = verwijderProduct;
window.openProductModal = openProductModal;
