// 📦 2_sessieherstel.js – Open-sessies banner + chooser (UI-shell compatible, no ignore/close)

import { db } from './3_data.js';
import { setActieveSessieRef } from './1_sessiebeheer.js';
import { verkoopManager } from './16_VerkoopManager.js';

// Public: call at startup and whenever you want to re-check
export async function checkOpenstaandeSessieBijStart() {
  await ensureStyles();
  // Als er al een actieve sessie is: zorg dat banner weg is
  if (window.actieveSessieRef?.sessie?.endTime === 'OPEN') {
    removeOpenSessiesBanner();
    return;
  }

  const openSessies = await findOpenSessies();
  if (openSessies.length === 0) {
    removeOpenSessiesBanner();
    return;
  }

  renderOpenSessiesBanner(openSessies);
}

// ---------- Helpers ----------
async function findOpenSessies() {
  const lijst = [];
  for (const event of (db.evenementen || [])) {
    if (event.state !== 'active') continue;
    try {
      await verkoopManager.load(event.naam);
      const sessies = await verkoopManager.getSessions(event.naam);
      if (!Array.isArray(sessies)) continue;
      const open = sessies.filter(s => s.endTime === 'OPEN');
      open.forEach(s => lijst.push({
        event,
        sessie: s,
        label: `${event.naam} – ${event.locatie || ''} – ${new Date(s.startTime).toLocaleString()}`
      }));
    } catch {}
  }
  return lijst;
}

function renderOpenSessiesBanner(openSessies) {
  // Verwijder eventuele oude
  removeOpenSessiesBanner();

  const mountAfter = document.querySelector('#sessionStripMount') || document.querySelector('.app-topbar');
  if (!mountAfter) return;

  const bar = document.createElement('div');
  bar.id = 'openSessiesBanner';
  bar.className = 'open-sessies-banner';
  bar.innerHTML = `
    <div class="osb-left">🔄 Open sessie${openSessies.length>1?'s':''} gevonden</div>
    <button class="osb-action">Kies sessie</button>
  `;
  const container = document.createElement('div');
  container.style.padding = '.5rem .6rem 0 .6rem';
  container.appendChild(bar);

  // Insert onder de sessie-strip (of onder topbar)
  const parent = mountAfter.parentElement || document.getElementById('app');
  parent.insertBefore(container, mountAfter.nextSibling);

  bar.querySelector('.osb-action').onclick = () => openChooserModal(openSessies);
  // Hele balk klikbaar
  bar.onclick = (e) => {
    if (e.target.closest('.osb-action')) return;
    openChooserModal(openSessies);
  };
}

function removeOpenSessiesBanner() {
  const el = document.getElementById('openSessiesBanner');
  if (el) {
    const wrapper = el.parentElement;
    wrapper?.parentElement?.removeChild(wrapper);
  }
}

function openChooserModal(openSessies) {
  // Modal
  const overlay = document.createElement('div');
  overlay.className = 'modal';
  overlay.style.zIndex = '10001';

  const box = document.createElement('div');
  box.className = 'osb-modal';
  box.innerHTML = `
    <h2 class="osb-title">Kies een open sessie</h2>
    <select id="osbSelect" class="osb-select"></select>
    <div class="osb-actions">
      <button class="btn-secondary" id="osbCancel">Annuleren</button>
      <button class="btn-primary" id="osbContinue">✅ Voortzetten</button>
    </div>
  `;
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  const select = box.querySelector('#osbSelect');
  openSessies.forEach((row, i) => {
    const opt = document.createElement('option');
    opt.value = i;
    opt.textContent = row.label;
    select.appendChild(opt);
  });

  box.querySelector('#osbCancel').onclick = () => overlay.remove();
  box.querySelector('#osbContinue').onclick = () => {
    const idx = parseInt(select.value);
    if (isNaN(idx)) return;
    const { event, sessie } = openSessies[idx];
    setActieveSessieRef(event.id, sessie.id);
    overlay.remove();
    removeOpenSessiesBanner();
    // Shell hertekent zichzelf via setActieveSessieRef → window.refreshAppShell?.()
  };
}

// ---------- Styles ----------
let stylesInjected = false;
async function ensureStyles() {
  if (stylesInjected) return;
  const css = document.createElement('style');
  css.id = 'openSessiesStyles';
  css.textContent = `
    .open-sessies-banner{
      display:flex; align-items:center; justify-content:space-between;
      padding:.55rem .8rem; border-radius:.75rem;
      background:#FFF3CD; color:#5C4B00; border:1px solid #FFEC9A;
      cursor:pointer; box-shadow: 0 1px 4px rgba(0,0,0,.06);
    }
    .open-sessies-banner .osb-left{ font-weight:800; }
    .open-sessies-banner .osb-action{
      border:none; border-radius:.6rem; padding:.45rem .7rem; font-weight:800;
      background:#2A9626; color:#fff;
    }

    .osb-modal{
      background:#fff; border-radius:12px; padding:1rem; width:min(520px, 92vw);
      box-shadow:0 6px 24px rgba(0,0,0,.2);
    }
    .osb-title{ margin:.25rem 0 .6rem 0; color:#2A9626; }
    .osb-select{
      width:100%; padding:.6rem .7rem; border:1px solid #ddd; border-radius:.6rem; margin-bottom:.8rem;
      font-size:1rem;
    }
    .osb-actions{ display:flex; justify-content:flex-end; gap:.5rem; }
    .btn-primary{ padding:.6rem .9rem; border:none; border-radius:.7rem; background:#2A9626; color:#fff; font-weight:800; }
    .btn-secondary{ padding:.6rem .9rem; border:1px solid #ddd; border-radius:.7rem; background:#fff; font-weight:800; }
  `;
  document.head.appendChild(css);
  stylesInjected = true;
}