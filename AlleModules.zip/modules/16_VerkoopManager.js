// modules/16_VerkoopManager.js

const BASE = 'https://olgascheese.net/api/verkopen';
const LS_KEY = 'vm_local_sessions_v1';

// ---------- utils ----------
function encodeSeg(seg) {
  return encodeURIComponent(String(seg == null ? '' : seg).replace(/\/+/g, '').trim());
}
function makePaths(eventKey) {
  var k = encodeSeg(eventKey);
  var root = BASE + '/' + k;
  return {
    root: root,
    manifest: root + '/manifest.json',
    sessionsIndex: root + '/sessions/index.json',
    sessionFile: function(id){ return root + '/sessions/' + encodeSeg(id) + '.json'; }
  };
}
function httpGet(url) {
  return fetch(url, { cache: 'no-cache' }).then(function(res){
    if (!res.ok) {
      var err = new Error('HTTP ' + res.status + ' for ' + url);
      err.status = res.status;
      throw err;
    }
    return res;
  });
}
function tryGet(url) {
  return fetch(url, { cache: 'no-cache' }).then(function(res){
    if (res.status === 404) return null;
    if (!res.ok) {
      var err = new Error('HTTP ' + res.status + ' for ' + url);
      err.status = res.status;
      throw err;
    }
    return res;
  });
}
function tryJson(url) {
  return tryGet(url).then(function(res){
    if (res === null) return null;
    return res.json();
  });
}

// ---------- simple in-memory cache ----------
var _manifestCache = {};
var _sessionsIndexCache = {};
var _sessionCache = {};

// ---------- localStorage helpers ----------
function readLS() {
  try {
    var raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch(e) { return {}; }
}
function writeLS(obj) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(obj || {})); } catch(e) {}
}
function lsGet(eventKey, id) {
  var all = readLS();
  var ev = all[eventKey] || {};
  return ev[id] || null;
}
function lsSet(eventKey, sessionObj) {
  var all = readLS();
  if (!all[eventKey]) all[eventKey] = {};
  all[eventKey][sessionObj.id] = sessionObj;
  writeLS(all);
}
function lsClose(eventKey, id) {
  var all = readLS();
  if (all[eventKey] && all[eventKey][id]) {
    all[eventKey][id].endTime = new Date().toISOString();
    writeLS(all);
  }
}

// ---------- API: manifests ----------
function getManifest(eventKey) {
  var key = String(eventKey);
  if (_manifestCache[key]) return _manifestCache[key];

  var paths = makePaths(key);
  _manifestCache[key] = tryJson(paths.manifest).then(function(json){
    // fallback manifest als file ontbreekt
    if (json) return json;
    return {
      id: key,
      naam: key,
      versie: 1,
      createdAt: new Date().toISOString()
    };
  }).catch(function(){
    // bij fetch error -> ook fallback
    return {
      id: key,
      naam: key,
      versie: 1,
      createdAt: new Date().toISOString()
    };
  });
  return _manifestCache[key];
}

// ---------- API: sessions ----------
function getSessionsIndex(eventKey) {
  var key = String(eventKey);
  if (_sessionsIndexCache[key]) return _sessionsIndexCache[key];

  var idxUrl = makePaths(key).sessionsIndex;
  _sessionsIndexCache[key] = tryJson(idxUrl).then(function(json){
    if (!json) return [];
    if (Array.isArray(json)) return json;
    if (json && Array.isArray(json.sessions)) return json.sessions;
    return [];
  }).catch(function(){ return []; });
  return _sessionsIndexCache[key];
}

function getSession(eventKey, sessieId) {
  var key = String(eventKey);
  var id  = String(sessieId);

  // 1) local cache
  var cacheKey = key + '::' + id;
  if (_sessionCache[cacheKey]) return Promise.resolve(_sessionCache[cacheKey]);

  // 2) localStorage (offline)
  var ls = lsGet(key, id);
  if (ls) {
    _sessionCache[cacheKey] = ls;
    return Promise.resolve(ls);
  }

  // 3) network file
  var url = makePaths(key).sessionFile(id);
  return httpGet(url).then(function(res){ return res.json(); }).then(function(js){
    _sessionCache[cacheKey] = js;
    return js;
  });
}

// Convenience: laad daadwerkelijke sessie-objecten, niet alleen ids
function getSessions(eventKey) {
  var key = String(eventKey);
  return getSessionsIndex(key).then(function(ids){
    if (!ids.length) return [];
    var urlOf = makePaths(key).sessionFile;
    var reqs = ids.map(function(id){
      return tryJson(urlOf(id)).then(function(js){
        if (js) return js;
        // als file mist: kijk of er lokaal wat is
        var ls = lsGet(key, id);
        return ls || null;
      }).catch(function(){ return null; });
    });
    return Promise.all(reqs).then(function(list){
      return list.filter(function(x){ return !!x; });
    });
  });
}

// ---------- API: mutations (local-only fallback) ----------
function createSession(eventKey, meta) {
  var key = String(eventKey);
  var now = new Date();
  var id  = now.toISOString().replace(/[:.]/g, '-');
  var sessie = {
    id: id,
    eventKey: key,
    startTime: now.toISOString(),
    endTime: 'OPEN',
    meta: meta || {},
    verkopen: []
  };
  lsSet(key, sessie);
  // in-memory cache
  _sessionCache[key + '::' + id] = sessie;
  return Promise.resolve(sessie);
}

function closeSession(eventKey, sessieId) {
  var key = String(eventKey);
  var id  = String(sessieId);
  lsClose(key, id);
  // sync cache
  var ck = key + '::' + id;
  if (_sessionCache[ck]) _sessionCache[ck].endTime = new Date().toISOString();
  return Promise.resolve(true);
}

// ---------- bundel loader ----------
function load(eventKey, withSessions) {
  var key = String(eventKey);
  return Promise.all([
    getManifest(key),
    withSessions ? getSessions(key) : Promise.resolve([])
  ]).then(function(parts){
    return { manifest: parts[0], sessions: parts[1] || [] };
  });
}

// ---------- legacy shims (no-ops zodat andere modules rustig blijven) ----------
function rootHas(/*eventKey*/) { return Promise.resolve(true); }
function fetchRootOnce() { return Promise.resolve(true); }

// ---------- public ----------
export const verkoopManager = {
  // manifests
  getManifest: getManifest,

  // sessions
  getSessionsIndex: getSessionsIndex,
  getSessions: getSessions,
  getSession: getSession,
  createSession: createSession,
  closeSession: closeSession,

  // combos
  load: function(eventKey){ return load(eventKey, true); },

  // legacy shims
  rootHas: rootHas,
  fetchRootOnce: fetchRootOnce
};