// 17_inzichten.js — Inzichten & Vooruitzicht (Charts + Forecast)
// Vereist: Chart.js (window.Chart), html2canvas, jsPDF (UMD)
// Exporteert: openInzichtenModal()

import { db } from './3_data.js';
import { showAlert } from './4_ui.js';
import { verkoopManager } from './16_VerkoopManager.js';

export function openInzichtenModal() {
  injectStylesOnce();
  closeAllModals();

  const overlay = document.createElement('div');
  overlay.className = 'modal';
  const box = document.createElement('div');
  box.className = 'inz-modal';
  overlay.appendChild(box);

  box.innerHTML = `
    <div class="inz-head">
      <h2>📈 Inzichten</h2>
      <div class="inz-head-actions">
        <button class="btn-amber" id="btnExportCSV">📁 CSV</button>
        <button class="btn-blue"  id="btnExportPDF">📄 PDF</button>
        <button class="btn-red"   id="btnClose">✕</button>
      </div>
    </div>

    <div class="inz-filters">
      <div class="row">
        <label>Event</label>
        <select id="fEvent">
          <option value="__ALL__">Alle events</option>
          ${(db.evenementen||[]).map(e=>`<option value="${e.id}">${esc(e.naam)} ${e.locatie?`— ${esc(e.locatie)}`:''}</option>`).join('')}
        </select>
      </div>
      <div class="row">
        <label>Periode</label>
        <select id="fRange">
          <option value="7">Laatste 7 dagen</option>
          <option value="30" selected>Laatste 30 dagen</option>
          <option value="90">Laatste 90 dagen</option>
          <option value="365">Laatste 365 dagen</option>
          <option value="__ALL__">Alles</option>
        </select>
      </div>
      <div class="row">
        <label>Valuta‑weergave</label>
        <select id="fCurr">
          <option value="EUR" selected>EUR</option>
          <option value="USD">USD</option>
        </select>
      </div>
    </div>

    <div class="inz-tabs">
      <button class="tab active" data-tab="overzicht">Overzicht</button>
      <button class="tab" data-tab="producten">Producten</button>
      <button class="tab" data-tab="tijd">Tijd</button>
      <button class="tab" data-tab="vooruitzicht">Vooruitzicht</button>
    </div>

    <div class="inz-content">
      <section id="tab-overzicht" class="tab-pane active">
        <div class="kpi-grid" id="kpiGrid"></div>
        <div class="panel">
          <canvas id="chartOmzetTrend"></canvas>
        </div>
      </section>

      <section id="tab-producten" class="tab-pane">
        <div class="panel">
          <canvas id="chartOmzetVsKosten"></canvas>
        </div>
        <div class="panel">
          <div class="table-wrap">
            <table id="tblProducts">
              <thead>
                <tr>
                  <th>Product</th><th>Omzet (EUR)</th><th>Kosten (EUR)</th><th>Marge €</th><th>Marge %</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="tab-tijd" class="tab-pane">
        <div class="panel">
          <canvas id="chartPerUur"></canvas>
        </div>
        <div class="panel">
          <canvas id="chartPerDag"></canvas>
        </div>
      </section>

      <section id="tab-vooruitzicht" class="tab-pane">
        <div class="panel">
          <div class="table-wrap">
            <table id="tblForecast">
              <thead>
                <tr>
                  <th>Event</th><th>Locatie</th><th>Type</th>
                  <th>Begroot omzet (EUR)</th><th>Begrote kosten (EUR)</th><th>Begrote winst (EUR)</th>
                </tr>
              </thead>
              <tbody></tbody>
              <tfoot>
                <tr>
                  <th colspan="3" style="text-align:right">TOTAAL</th>
                  <th id="fcOmzet">€0.00</th><th id="fcKosten">€0.00</th><th id="fcWinst">€0.00</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        <div class="panel">
          <canvas id="chartForecastStack"></canvas>
        </div>
      </section>
    </div>
  `;

  document.body.appendChild(overlay);

  // events
  box.querySelector('#btnClose').onclick = () => overlay.remove();
  box.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  const selEvent = box.querySelector('#fEvent');
  const selRange = box.querySelector('#fRange');
  const selCurr  = box.querySelector('#fCurr');

  // tabs
  box.querySelectorAll('.inz-tabs .tab').forEach(b=>{
    b.onclick = () => {
      box.querySelectorAll('.inz-tabs .tab').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
      const id = b.dataset.tab;
      box.querySelectorAll('.tab-pane').forEach(p=>p.classList.remove('active'));
      box.querySelector(`#tab-${id}`).classList.add('active');
      // (her)teken wat nodig is
      renderAll();
    };
  });

  // filters
  [selEvent, selRange, selCurr].forEach(el => el.onchange = renderAll);

  // export
  box.querySelector('#btnExportCSV').onclick = () => exportCSVCurrent(selEvent.value, selRange.value);
  box.querySelector('#btnExportPDF').onclick = () => exportPDF(box);

  // state
  let charts = {};

  // main render
  renderAll();

  async function renderAll() {
    const filter = {
      eventId: selEvent.value,
      days:    selRange.value,
      curr:    selCurr.value
    };
    const verkoopsData = await loadSales(filter);               // verkopen + context
    renderKPIs(verkoopsData, filter, box.querySelector('#kpiGrid'));
    charts = drawOrUpdateCharts(charts, verkoopsData, filter);
    renderProductsTable(verkoopsData, filter, box.querySelector('#tblProducts tbody'));
    renderForecast(verkoopsData, filter, box);
  }
}

/* =========================
   Data & Aggregaties
   ========================= */

function daysToMs(days) {
  if (days === '__ALL__') return 0;
  const n = Number(days);
  return Number.isFinite(n) ? n*24*60*60*1000 : 0;
}

async function loadSales(filter) {
  const now = Date.now();
  const since = daysToMs(filter.days) ? (now - daysToMs(filter.days)) : 0;

  const events = (db.evenementen || []);
  const scopeEvents = filter.eventId === '__ALL__'
    ? events
    : events.filter(e => e.id === filter.eventId);

  const verkopenAll = [];
  const sessionsByEvent = {};

  for (const ev of scopeEvents) {
    try {
      const sessions = await verkoopManager.getSessions(ev.naam);
      sessionsByEvent[ev.id] = sessions || [];
      const verkopen = await verkoopManager.getVerkopenForEvent(ev.naam);
      for (const v of verkopen || []) {
        const t = v.tijd ? new Date(v.tijd).getTime() : 0;
        if (!since || t >= since) {
          // normaliseer prijzen
          const rate = Number(v.exchangeRate || 1);
          const usd  = Number(v.prijs_usd || 0);
          const eur  = Number(v.prijs_eur || (usd * rate));
          verkopenAll.push({ ...v, prijs_usd: usd, prijs_eur: eur, _eventId: ev.id, _eventNaam: ev.naam, _loc: ev.locatie, _type: ev.type });
        }
      }
    } catch (e) {
      console.warn('Verkopen laden faalde voor', ev.naam, e);
    }
  }

  return {
    events: scopeEvents,
    verkopen: verkopenAll,
    sessionsByEvent
  };
}

function sum(arr) { return arr.reduce((s,n)=>s+(Number(n)||0),0); }
function by(obj, key, fn) {
  const m = {};
  for (const it of obj) {
    const k = key(it);
    if (!m[k]) m[k] = [];
    m[k].push(it);
  }
  const out = {};
  for (const k of Object.keys(m)) out[k] = fn(m[k], k);
  return out;
}

function euro(n){ return `€${Number(n||0).toFixed(2)}`; }

/* =========================
   KPI & Charts
   ========================= */

function renderKPIs(data, filter, mount) {
  const v = data.verkopen;
  const eur = sum(v.map(x => x.prijs_eur));
  const usd = sum(v.map(x => x.prijs_usd));
  const txs = v.length;
  const avg = txs ? eur/txs : 0;

  // kaas vs souvenir (heuristiek): als product in db.producten zit → kaas; anders souvenir
  const prodSet = new Set((db.producten||[]).map(p => p.naam));
  const kaasOmzet = sum(v.filter(x => prodSet.has(x.product)).map(x=>x.prijs_eur));
  const souvenirOmzet = Math.max(0, eur - kaasOmzet);

  // beste dag/uur
  const perDag = by(v, x => new Date(x.tijd||Date.now()).getDay(), list => sum(list.map(i=>i.prijs_eur)));
  const bestDayIdx = Object.entries(perDag).sort((a,b)=>b[1]-a[1])[0]?.[0];
  const dagNaam = ['zo','ma','di','wo','do','vr','za'][bestDayIdx ?? 0];

  const perUur = by(v, x => new Date(x.tijd||Date.now()).getHours(), list => sum(list.map(i=>i.prijs_eur)));
  const bestUur = Object.entries(perUur).sort((a,b)=>b[1]-a[1])[0]?.[0];

  mount.innerHTML = `
    <div class="kpi">
      <div class="kpi-title">Omzet (EUR)</div>
      <div class="kpi-value">${euro(eur)}</div>
    </div>
    <div class="kpi">
      <div class="kpi-title">Omzet (USD)</div>
      <div class="kpi-value">$${usd.toFixed(2)}</div>
    </div>
    <div class="kpi">
      <div class="kpi-title">Transacties</div>
      <div class="kpi-value">${txs}</div>
    </div>
    <div class="kpi">
      <div class="kpi-title">Gemiddeld ticket</div>
      <div class="kpi-value">${euro(avg)}</div>
    </div>
    <div class="kpi small">
      <div class="kpi-title">Kaas</div>
      <div class="kpi-value">${euro(kaasOmzet)}</div>
    </div>
    <div class="kpi small">
      <div class="kpi-title">Souvenir</div>
      <div class="kpi-value">${euro(souvenirOmzet)}</div>
    </div>
    <div class="kpi small badge">Beste dag: ${dagNaam}</div>
    <div class="kpi small badge">Beste uur: ${bestUur ?? '—'}u</div>
  `;

  // Trend chart data (per dag)
  setTimeout(()=>{
    const days = {};
    v.forEach(x=>{
      const d = new Date(x.tijd||Date.now());
      const key = d.toISOString().slice(0,10);
      days[key] = (days[key]||0) + (x.prijs_eur||0);
    });
    const labels = Object.keys(days).sort();
    const values = labels.map(k=>days[k]);
    const ctx = document.getElementById('chartOmzetTrend');
    if (ctx) {
      const old = ctx._chart;
      if (old) old.destroy?.();
      ctx._chart = new Chart(ctx, {
        type:'line',
        data:{ labels, datasets:[{ label:'Omzet (EUR)', data: values }] },
        options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } } }
      });
    }
  }, 0);
}

function resolveCostPerUnit(productName) {
  const p = (db.producten || []).find(x => x.naam === productName);
  // Voorkeur: expliciete inkoop op product; anders 0
  return Number(p?.inkoop || 0);
}
function resolveUnitCountForSale(v) {
  // Als een verkoop entry zelf units bevat (aantal), neem die; anders 1
  return Number(v.aantal || 1);
}

function drawOrUpdateCharts(charts, data, filter) {
  const verkopen = data.verkopen;

  // --------- Omzet vs Kosten per product ---------
  const perProd = by(verkopen, x => x.product || '—', list => {
    const omzet = sum(list.map(i => i.prijs_eur));
    const costUnit = resolveCostPerUnit(list[0]?.product || '');
    const units = sum(list.map(resolveUnitCountForSale));
    const kosten = costUnit * units;
    return { omzet, kosten };
  });

  const prodLabels = Object.keys(perProd);
  const omzetData  = prodLabels.map(k => perProd[k].omzet);
  const kostData   = prodLabels.map(k => perProd[k].kosten);

  const ctx1 = document.getElementById('chartOmzetVsKosten');
  if (ctx1) {
    charts.prod && charts.prod.destroy?.();
    charts.prod = new Chart(ctx1, {
      type:'bar',
      data:{ labels: prodLabels, datasets:[
        { label:'Omzet (EUR)', data: omzetData },
        { label:'Kosten (EUR)', data: kostData }
      ]},
      options:{
        responsive:true, maintainAspectRatio:false,
        scales:{ x:{ ticks:{ autoSkip:true, maxRotation:0, minRotation:0 } }, y:{ beginAtZero:true } }
      }
    });
  }

  // --------- Per uur histogram ---------
  const perHour = Array.from({length:24}, (_,h)=>({
    h, omzet:0, count:0
  }));
  verkopen.forEach(v => {
    const d = new Date(v.tijd||Date.now());
    const h = d.getHours();
    perHour[h].omzet += v.prijs_eur||0;
    perHour[h].count += 1;
  });
  const ctx2 = document.getElementById('chartPerUur');
  if (ctx2) {
    charts.hour && charts.hour.destroy?.();
    charts.hour = new Chart(ctx2, {
      type:'bar',
      data:{ labels: perHour.map(x=>`${x.h}:00`), datasets:[
        { label:'Omzet (EUR)', data: perHour.map(x=>x.omzet) }
      ]},
      options:{ responsive:true, maintainAspectRatio:false, scales:{ y:{ beginAtZero:true } } }
    });
  }

  // --------- Per dag histogram ---------
  const days = ['Zo','Ma','Di','Wo','Do','Vr','Za'];
  const perD = Array.from({length:7},(_,i)=>({i, omzet:0}));
  verkopen.forEach(v=>{
    const d = new Date(v.tijd||Date.now());
    perD[d.getDay()].omzet += v.prijs_eur||0;
  });
  const ctx3 = document.getElementById('chartPerDag');
  if (ctx3) {
    charts.day && charts.day.destroy?.();
    charts.day = new Chart(ctx3, {
      type:'bar',
      data:{ labels: perD.map(x=>days[x.i]), datasets:[{ label:'Omzet (EUR)', data: perD.map(x=>x.omzet) }]},
      options:{ responsive:true, maintainAspectRatio:false, scales:{ y:{ beginAtZero:true } } }
    });
  }

  return charts;
}

function renderProductsTable(data, filter, tbody) {
  const verkopen = data.verkopen;
  const grouped = by(verkopen, x => x.product || '—', list => {
    const omzet = sum(list.map(i=>i.prijs_eur));
    const units = sum(list.map(resolveUnitCountForSale));
    const costUnit = resolveCostPerUnit(list[0]?.product || '');
    const kosten = costUnit * units;
    const marge  = omzet - kosten;
    const margePct = omzet ? (marge/omzet)*100 : 0;
    return { omzet, kosten, marge, margePct };
  });

  const rows = Object.entries(grouped)
    .sort((a,b)=>b[1].omzet - a[1].omzet)
    .map(([name, d]) => `
      <tr>
        <td>${esc(name)}</td>
        <td>${euro(d.omzet)}</td>
        <td>${euro(d.kosten)}</td>
        <td>${euro(d.marge)}</td>
        <td style="color:${d.marge>=0?'#2E7D32':'#C62828'}">${d.margePct.toFixed(1)}%</td>
      </tr>
    `).join('');

  tbody.innerHTML = rows || `<tr><td colspan="5" style="text-align:center;color:#666">Geen data</td></tr>`;
}

/* =========================
   Vooruitzicht (Forecast)
   ========================= */

function historicalAverages() {
  const completed = (db.evenementen||[]).filter(e => (e.state||'').toLowerCase() === 'closed' || (e.state||'').toLowerCase() === 'completed' || (e.state||'').toLowerCase() === 'active'); // ook actieve meenemen voor sample
  const perKey = {};

  // Build omzet/kosten per event uit verkopen en eenvoudige kostenbenadering
  const prodSet = new Set((db.producten||[]).map(p=>p.naam));
  const cache = {};

  const ensureEventMetrics = async (ev) => {
    const key = ev.id;
    if (cache[key]) return cache[key];

    let omzetEUR = 0, kaasOmzet = 0, kostenKaas = 0;
    try {
      const verkopen = await verkoopManager.getVerkopenForEvent(ev.naam);
      omzetEUR = sum(verkopen.map(v => (v.prijs_eur || (v.prijs_usd||0) * (v.exchangeRate||1))));
      // kaasomzet/kosten
      for (const v of verkopen) {
        const isKaas = prodSet.has(v.product);
        if (isKaas) {
          const eur = (v.prijs_eur || (v.prijs_usd||0) * (v.exchangeRate||1));
          kaasOmzet += eur;
          const units = Number(v.aantal || 1);
          const costUnit = resolveCostPerUnit(v.product);
          kostenKaas += units * costUnit;
        }
      }
    } catch {}

    const souvenirs = Math.max(0, omzetEUR - kaasOmzet);
    const souvenirKosten = souvenirs * 0.25;
    const commissie = (Number(ev.commissie||0)/100) * omzetEUR;
    const stageld   = Number(ev.stageld||0);
    const extra     = sum(((ev.kosten?.extra)||[]).map(k=>Number(k.bedrag||0)));

    const kostenTotaal = kostenKaas + souvenirKosten + commissie + stageld + extra;
    const winst = omzetEUR - kostenTotaal;

    cache[key] = { omzetEUR, kostenTotaal, winst };
    return cache[key];
  };

  // NB: sync helper (we call async in caller as needed)
  return { completed, ensureEventMetrics };
}

async function renderForecast(data, filter, root) {
  const tbody = root.querySelector('#tblForecast tbody');
  if (!tbody) return;

  const planned = (db.evenementen||[]).filter(e => (e.state||'').toLowerCase() === 'planned');
  if (!planned.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#666">Geen geplande evenementen.</td></tr>`;
    const ctx = root.querySelector('#chartForecastStack');
    if (ctx && ctx._chart) { ctx._chart.destroy(); ctx._chart = null; }
    root.querySelector('#fcOmzet').textContent = '€0.00';
    root.querySelector('#fcKosten').textContent = '€0.00';
    root.querySelector('#fcWinst').textContent  = '€0.00';
    return;
  }

  const { completed, ensureEventMetrics } = historicalAverages();

  // Voor elk planned event: kies referentiegemiddelde
  const rows = [];
  let totO=0, totK=0, totW=0;

  for (const ev of planned) {
    // set 1: zelfde locatie
    const locSet = completed.filter(e => e.locatie === ev.locatie);
    const typeSet = completed.filter(e => e.type === ev.type);

    const pickSet = locSet.length ? locSet : (typeSet.length ? typeSet : completed);

    let sumO=0, sumK=0, sumW=0, n=0;
    for (const e of pickSet) {
      const m = await ensureEventMetrics(e);
      sumO += m.omzetEUR; sumK += m.kostenTotaal; sumW += m.winst; n++;
    }
    const avgO = n? sumO/n : 0;
    const avgK = n? sumK/n : 0;
    const avgW = n? sumW/n : 0;

    totO += avgO; totK += avgK; totW += avgW;

    rows.push(`
      <tr>
        <td>${esc(ev.naam)}</td>
        <td>${esc(ev.locatie||'-')}</td>
        <td>${esc(ev.type||'-')}</td>
        <td>${euro(avgO)}</td>
        <td>${euro(avgK)}</td>
        <td style="color:${avgW>=0?'#2E7D32':'#C62828'}">${euro(avgW)}</td>
      </tr>
    `);
  }

  tbody.innerHTML = rows.join('');

  root.querySelector('#fcOmzet').textContent  = euro(totO);
  root.querySelector('#fcKosten').textContent = euro(totK);
  root.querySelector('#fcWinst').textContent  = euro(totW);

  // Chart: stacked omzet/kosten/winst per event
  const labels = planned.map(e=>e.naam);
  const ctx = root.querySelector('#chartForecastStack');
  if (ctx) {
    ctx._chart && ctx._chart.destroy?.();
    const omzet = [], kosten = [], winst = [];
    // loop nogmaals in dezelfde volgorde
    for (const ev of planned) {
      const locSet = (db.evenementen||[]).filter(e => (e.state||'').toLowerCase() !== 'planned' && e.locatie === ev.locatie);
      const typeSet= (db.evenementen||[]).filter(e => (e.state||'').toLowerCase() !== 'planned' && e.type === ev.type);
      const pickSet = locSet.length ? locSet : (typeSet.length ? typeSet : (db.evenementen||[]).filter(e => (e.state||'').toLowerCase() !== 'planned'));

      let sumO=0, sumK=0, sumW=0, n=0;
      for (const e of pickSet) {
        const m = await (async () => {
          // hergebruik logic:
          const hv = historicalAverages();
          return hv.ensureEventMetrics ? hv.ensureEventMetrics(e) : { omzetEUR:0, kostenTotaal:0, winst:0 };
        })();
        const mm = await m;
        sumO += mm.omzetEUR; sumK += mm.kostenTotaal; sumW += mm.winst; n++;
      }
      const avgO = n? sumO/n : 0;
      const avgK = n? sumK/n : 0;
      const avgW = n? sumW/n : 0;
      omzet.push(avgO); kosten.push(avgK); winst.push(avgW);
    }

    ctx._chart = new Chart(ctx, {
      type:'bar',
      data:{ labels, datasets:[
        { label:'Omzet', data:omzet, stack:'s' },
        { label:'Kosten', data:kosten, stack:'s' },
        { label:'Winst', data:winst, stack:'s' }
      ]},
      options:{ responsive:true, maintainAspectRatio:false, scales:{ x:{ stacked:true }, y:{ stacked:true, beginAtZero:true } } }
    });
  }
}

/* =========================
   Exports: CSV / PDF
   ========================= */

function exportCSVCurrent(eventId, days) {
  try {
    // simpele CSV van producttabel + KPI’s zou prima zijn;
    // hier exporteren we alleen productregels die in DOM staan
    const rows = [];
    const tbl = document.querySelector('#tblProducts');
    if (tbl) {
      const heads = Array.from(tbl.querySelectorAll('thead th')).map(th=>th.textContent.trim());
      rows.push(heads.join(','));
      tbl.querySelectorAll('tbody tr').forEach(tr=>{
        const cells = Array.from(tr.children).map(td => `"${td.textContent.replaceAll('"','""')}"`);
        rows.push(cells.join(','));
      });
    }
    const blob = new Blob([rows.join('\n')], { type:'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `inzichten_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  } catch (e) {
    console.error(e);
    showAlert('CSV export mislukte.', 'error');
  }
}

async function exportPDF(container) {
  try {
    const node = container.closest('.modal') || container;
    const canvas = await window.html2canvas(node, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new window.jspdf.jsPDF('p', 'pt', 'a4');
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    const imgW = pageW - 40;
    const imgH = canvas.height * (imgW / canvas.width);
    pdf.addImage(imgData, 'PNG', 20, 20, imgW, imgH);
    pdf.save(`inzichten_${Date.now()}.pdf`);
  } catch (e) {
    console.error(e);
    showAlert('PDF export mislukte.', 'error');
  }
}

/* =========================
   Utils & Styles
   ========================= */

function esc(s){ return String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'); }

function closeAllModals(){ try{ document.querySelectorAll('.modal').forEach(m=>m.remove()); }catch{} }

function injectStylesOnce(){
  if (document.getElementById('inz-css')) return;
  const css = document.createElement('style');
  css.id = 'inz-css';
  css.textContent = `
    .modal{ position:fixed; inset:0; display:flex; align-items:center; justify-content:center;
      background:rgba(0,0,0,.35); z-index:9999; }
    .inz-modal{ width:min(1100px, 96vw); max-height:92vh; overflow:auto; background:#fff; border-radius:14px; box-shadow:0 10px 30px rgba(0,0,0,.25); padding:1rem; }
    .inz-head{ display:flex; justify-content:space-between; align-items:center; gap:.5rem; border-bottom:1px solid #eee; padding-bottom:.5rem; }
    .inz-head-actions{ display:flex; gap:.4rem; }
    .btn-green{ background:#2E7D32; color:#fff; border:none; border-radius:8px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .btn-blue{ background:#1976D2; color:#fff; border:none; border-radius:8px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .btn-amber{ background:#FB8C00; color:#1b1b1b; border:none; border-radius:8px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .btn-red{ background:#C62828; color:#fff; border:none; border-radius:8px; padding:.5rem .8rem; font-weight:900; cursor:pointer; }
    .inz-filters{ display:flex; gap:1rem; flex-wrap:wrap; margin:.6rem 0 .4rem 0; }
    .inz-filters .row{ display:flex; flex-direction:column; gap:.25rem; }
    .inz-filters select{ padding:.45rem .6rem; border:1px solid #ddd; border-radius:8px; }

    .inz-tabs{ display:flex; gap:.4rem; border-bottom:1px solid #eee; margin-top:.2rem; }
    .inz-tabs .tab{ background:#1976D2; color:#fff; border:none; border-radius:8px 8px 0 0; padding:.45rem .8rem; font-weight:900; cursor:pointer; opacity:.7; }
    .inz-tabs .tab.active{ opacity:1; }

    .inz-content{ padding:.6rem .2rem; }
    .tab-pane{ display:none; }
    .tab-pane.active{ display:block; }

    .kpi-grid{ display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:.6rem; margin:.4rem 0; }
    .kpi{ background:#F3FFF1; border:1px solid #D7F2D0; border-radius:10px; padding:.6rem .7rem; }
    .kpi.small{ padding:.45rem .6rem; }
    .kpi.badge{ background:#E8F4FF; border:1px solid #CFE6FF; }
    .kpi-title{ font-weight:800; color:#2A9626; }
    .kpi-value{ font-weight:900; font-size:1.25rem; }

    .panel{ background:#fff; border:1px solid #eee; border-radius:12px; padding:.6rem; margin:.4rem 0; min-height:220px; }
    .table-wrap{ overflow:auto; max-height:45vh; }
    table{ width:100%; border-collapse:collapse; }
    th,td{ padding:.45rem .5rem; border-bottom:1px solid #eee; text-align:left; }
    thead th{ position:sticky; top:0; background:#f8f8f8; }
    canvas{ width:100%; max-height:300px; }
  `;
  document.head.appendChild(css);
}