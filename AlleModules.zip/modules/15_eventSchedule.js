// modules/15_eventSchedule.js
import { db, saveEvent } from './3_data.js';
import { showAlert } from './4_ui.js';


export function openEventEditModal(eventId) {
  const event = db.evenementen.find(e => e.id === eventId);
  if (!event) {
    return showAlert('❌ Evenement niet gevonden', 'error');
  }

  // overlay bovenop de bestaande modals
  const overlay = document.createElement('div');
  overlay.className = 'modal';
  Object.assign(overlay.style, {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.4)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 4000
  });
  document.body.appendChild(overlay);

  // modal container
  const modal = document.createElement('div');
  Object.assign(modal.style, {
    background: '#fff', padding: '1.5rem',
    borderRadius: '10px', width: '90%', maxWidth: '480px',
    maxHeight: '85vh', overflowY: 'auto', position: 'relative'
  });
  overlay.appendChild(modal);

  // ✕ sluit-knop
  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.textContent = '✕';
  Object.assign(closeBtn.style, {
    position: 'absolute', top: '8px', right: '8px',
    background: '#2A9626', border: 'none', fontSize: '1.2rem', cursor: 'pointer'
  });
  closeBtn.onclick = () => overlay.remove();
  modal.appendChild(closeBtn);

  // Titel
  const h2 = document.createElement('h3');
  h2.textContent = `✏️ Bewerk Evenement: ${event.naam}`;
  h2.style.marginTop = '0';
  modal.appendChild(h2);

  // Basisgegevens
  const info = document.createElement('div');
  info.innerHTML = `
    <p><strong>Type:</strong> ${event.type}</p>
    <p><strong>Locatie:</strong> ${event.locatie}</p>
    <p><strong>Periode:</strong> ${event.startdatum} – ${event.einddatum}</p>
    <p><strong>Bus:</strong> ${event.bus}</p>
    <p><strong>Verkopers:</strong> ${event.personen.join(', ')}</p>
    <p><strong>Commissie:</strong> ${event.commissie}%</p>
    <p><strong>Stageld:</strong> €${event.stageld}</p>
    <hr>
  `;
  modal.appendChild(info);

  // Extra kosten lijst
  const kostenSectie = document.createElement('div');
  kostenSectie.style.marginBottom = '1rem';
  kostenSectie.innerHTML = `<h4>➕ Extra Kosten</h4>`;
  const kostenList = document.createElement('ul');
  kostenList.style.padding = '0';
  kostenList.style.listStyle = 'none';
  kostenSectie.appendChild(kostenList);

  function renderKosten() {
    kostenList.innerHTML = '';
    const extra = event.kosten?.extra || [];
    if (extra.length === 0) {
      kostenList.innerHTML = '<li>Geen extra kosten.</li>';
    } else {
      extra.forEach((k, i) => {
        const li = document.createElement('li');
        li.style.display = 'flex';
        li.style.justifyContent = 'space-between';
        li.style.marginBottom = '0.4rem';
        li.innerHTML = `
          <span>${k.soort}: €${k.bedrag.toFixed(2)}${k.comment ? ' – ' + k.comment : ''}</span>
          <button type="button" style="background:#c00;color:#fff;border:none;border-radius:4px;padding:2px 6px;cursor:pointer">×</button>
        `;
        li.querySelector('button').onclick = async () => {
          // verwijder deze kost
          event.kosten.extra.splice(i,1);
          await saveEvent(event.id);
          renderKosten();
          showAlert('✅ Kost verwijderd', 'success');
        };
        kostenList.appendChild(li);
      });
    }
  }
  renderKosten();
  modal.appendChild(kostenSectie);

  // Form voor nieuwe extra kost
  const kostForm = document.createElement('div');
  kostForm.style.display = 'flex';
  kostForm.style.flexDirection = 'column';
  kostForm.style.gap = '0.5rem';
  kostForm.style.marginBottom = '1rem';
  kostForm.innerHTML = `
    <select id="newCostType">
    <option value="Diesel">Diesel</option>
    <option value="Overnachten">Overnachten</option>
    <option value="Eten">Eten</option>
    <option value="Anders">Anders</option>
  </select>
  <input type="number" placeholder="Bedrag" id="newCostAmt">
  <input type="text" placeholder="Commentaar (optioneel)" id="newCostComment" style="display:none;">
  <button type="button">Voeg toe</button>
  `;
  modal.appendChild(kostForm);
  
  const selectType   = kostForm.querySelector('#newCostType');
const commentField = kostForm.querySelector('#newCostComment');
selectType.addEventListener('change', () => {
  commentField.style.display = selectType.value === 'Anders' ? 'block' : 'none';
});

  kostForm.querySelector('button').onclick = async () => {
    const soort = kostForm.querySelector('#newCostType').value.trim();
    const bedrag = parseFloat(kostForm.querySelector('#newCostAmt').value);
    const comment = kostForm.querySelector('#newCostComment').value.trim();
    if (!soort || isNaN(bedrag)) {
      return showAlert('⚠️ Vul soort en bedrag correct in.', 'warning');
    }
    event.kosten = event.kosten || {};
    event.kosten.extra = event.kosten.extra || [];
    event.kosten.extra.push({ soort, bedrag, comment });
    await saveEvent(event.id);
    renderKosten();
    showAlert('✅ Extra kost toegevoegd', 'success');
    kostForm.querySelector('#newCostType').value = '';
    kostForm.querySelector('#newCostAmt').value = '';
    kostForm.querySelector('#newCostComment').value = '';
  };

  // Bewerk-knop: sluit deze modal en opent de schedule-modal met eventData
  const editBtn = document.createElement('button');
  editBtn.type = 'button';
  editBtn.textContent = '✏️ Bewerk in formulier';
  Object.assign(editBtn.style, {
    background: '#2A9626', color: '#fff',
    border: 'none', padding: '0.6rem 1rem',
    borderRadius: '6px', cursor: 'pointer'
  });
  editBtn.onclick = () => {
    overlay.remove();
    openEventScheduleModal(event);
  };
  modal.appendChild(editBtn);
}

export function openPlannedEventsModal() {
  // overlay bovenop de bestaande modal
  const overlay2 = document.createElement('div');
  overlay2.className = 'modal';
  Object.assign(overlay2.style, {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.4)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 3000
  });

  // container
  const modal2 = document.createElement('div');
  Object.assign(modal2.style, {
    background: '#fff', padding: '1rem',
    borderRadius: '10px', width: '90%', maxWidth: '400px',
    maxHeight: '80vh', overflowY: 'auto', position: 'relative'
  });

  // sluit-knop
  const close2 = document.createElement('button');
  close2.type = 'button';
  close2.textContent = '✕';
  Object.assign(close2.style, {
    position: 'absolute', top: '8px', right: '8px',
    background: 'transparent', border: 'none',
    fontSize: '1.2rem', cursor: 'pointer'
  });
  close2.onclick = () => overlay2.remove();
  modal2.appendChild(close2);

  // header
  const h2 = document.createElement('h3');
  h2.textContent = '📋 Geplande Evenementen';
  modal2.appendChild(h2);

  // filter op state==='planned'
  const planned = db.evenementen.filter(e => e.state === 'planned');
  if (planned.length === 0) {
    const p = document.createElement('p');
    p.textContent = 'Geen geplande evenementen.';
    modal2.appendChild(p);
  } else {
    const ul = document.createElement('ul');
    ul.style.listStyle = 'none';
    ul.style.padding = '0';
    planned.forEach(evt => {
      const li = document.createElement('li');
      li.style.marginBottom = '0.75rem';

      const span = document.createElement('span');
      span.textContent = `${evt.naam} (${evt.startdatum} – ${evt.einddatum})`;

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Bewerken';
      btn.style.marginLeft = '0.5rem';
      btn.onclick = () => {
        overlay2.remove();
        // heropen de schedule-modal in bewerk-modus
        openEventEditModal(evt.id);
      };

      li.append(span, btn);
      ul.appendChild(li);
    });
    modal2.appendChild(ul);
  }

  overlay2.appendChild(modal2);
  document.body.appendChild(overlay2);
}

export function openEventScheduleModal(eventData = null) {
  const isNew = !eventData || !eventData.id;

  // --- CSS injectie (eerder toegevoegd) blijft ongewijzigd ---
  // (zie vorige versie)

  // --- Sluit oude modals ---
  document.querySelectorAll('.modal').forEach(m => m.remove());

  // --- Overlay & modal container ---
  const overlay = document.createElement('div');
  overlay.className = 'modal';
  Object.assign(overlay.style, {
    position:'fixed', inset:0,
    background:'rgba(0,0,0,0.4)',
    display:'flex', alignItems:'center', justifyContent:'center',
    zIndex:2000
  });
  const modal = document.createElement('div');
  modal.id = 'scheduleModal';
  Object.assign(modal.style, {
    background:'#fff', padding:'1.5rem',
    borderRadius:'12px', width:'90%', maxWidth:'500px',
    maxHeight:'90vh', overflowY:'auto',
    boxShadow:'0 8px 24px rgba(0,0,0,0.25)'
  });

  // --- Header ---
  const header = document.createElement('div');
  header.className = 'modal-header';
  const title = document.createElement('h2');
  title.textContent = isNew ? '📅 Nieuw Evenement Plannen' : '✏️ Bewerk Evenement';
  title.style.color = '#2A9626';
  header.appendChild(title);
  const actions = document.createElement('div');
  actions.className = 'modal-actions';
  const listBtn = document.createElement('button');
  listBtn.type = 'button';
  listBtn.className = 'save-btn';
  listBtn.textContent = 'Evenementenlijst';
  listBtn.style.width = 'auto';
  listBtn.addEventListener('click', e => {
   e.preventDefault();
  openPlannedEventsModal();
 });
  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'cancel-btn';
  closeBtn.textContent = '✕';
  closeBtn.addEventListener('click', () => overlay.remove());
  actions.append(listBtn, closeBtn);
  header.appendChild(actions);
  modal.appendChild(header);

  // --- Formulier ---
  const form = document.createElement('form');
  form.id = 'scheduleForm';
  form.innerHTML = `
    <div class="form-field">
      <label for="evtName">Naam evenement</label>
      <input type="text" id="evtName" readonly required>
    </div>
    <div class="form-field">
      <label for="evtType">Type evenement</label>
      <select id="evtType">
        <option value="">Kies type</option>
        <option value="BX">BX</option>
        <option value="Bazaar">Bazaar</option>
      </select>
    </div>
    <div class="form-field">
      <label for="evtLocation">Locatie</label>
      <select id="evtLocation">
        <option value="">Kies locatie</option>
        <option>Ramstein</option><option>Spangdahlem</option><option>Stuttgart</option>
        <option>Chievres</option><option>Wiesbaden</option><option>Grafenwoehr</option>
        <option>Vilseck</option><option>Hohenfels</option><option>Aviano</option>
        <option>Vicenza</option><option>Napels</option><option>Rota</option>
        <option>Brunssum</option>
      </select>
    </div>
    <div class="form-field">
      <label for="evtStart">Startdatum</label>
      <input type="date" id="evtStart">
    </div>
    <div class="form-field">
      <label for="evtEnd">Einddatum</label>
      <input type="date" id="evtEnd">
    </div>
    <div class="form-field">
      <label for="evtBus">Bus</label>
      <select id="evtBus">
        ${Object.keys(db.voorraad).map(b=>`<option value="${b}">${b}</option>`).join('')}
      </select>
    </div>
    <fieldset class="form-field">
      <legend>Verkopers</legend>
      <label class="pretty-checkbox">
        <input type="checkbox" name="personen" value="Olga"> Olga
      </label>
      <label class="pretty-checkbox">
        <input type="checkbox" name="personen" value="Alberto"> Alberto
      </label>
    </fieldset>
    <div class="form-field">
      <label for="evtCommission">Commissie %</label>
      <input type="number" id="evtCommission" step="0.1" value="0">
    </div>
    <div class="form-field">
      <label for="evtStipend">Stageld (€)</label>
      <input type="number" id="evtStipend" step="1" value="0">
    </div>
    <button type="button" class="save-btn" id="saveScheduleBtn">✅ Opslaan</button>
  `;
  modal.appendChild(form);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  // --- References & automatische naam ---
  const nameInput      = form.querySelector('#evtName');
  const typeSelect     = form.querySelector('#evtType');
  const locationSelect = form.querySelector('#evtLocation');
  const startInput     = form.querySelector('#evtStart');

  function generateName() {
    if (!isNew) return;
    const tp  = typeSelect.value;
    const loc = locationSelect.value;
    const sd  = startInput.value;
    if (tp && loc && sd) {
      const m = new Date(sd).toLocaleString('nl-NL',{month:'long',year:'2-digit'});
      nameInput.value = `${loc} ${tp} ${m}`;
    }
  }
  [typeSelect, locationSelect, startInput].forEach(el=>
    el.addEventListener('change', generateName)
  );
  generateName();

  // --- Pre-fill bij bewerken ---
  if (!isNew) {
    nameInput.value      = eventData.naam;
    typeSelect.value     = eventData.type;
    locationSelect.value = eventData.locatie;
    form.querySelector('#evtStart').value = eventData.startdatum;
    form.querySelector('#evtEnd').value   = eventData.einddatum;
    form.querySelector('#evtBus').value   = eventData.bus;
    (eventData.personen||[]).forEach(p=>{
      const cb = form.querySelector(`input[name="personen"][value="${p}"]`);
      if(cb) cb.checked = true;
    });
    form.querySelector('#evtCommission').value = eventData.commissie||0;
    form.querySelector('#evtStipend').value    = eventData.stageld  ||0;
  }

  // --- Opslaan: exact zoals in module 5 :contentReference[oaicite:0]{index=0}&#8203;:contentReference[oaicite:1]{index=1} ---
  form.querySelector('#saveScheduleBtn').addEventListener('click', async ()=>{
    const naam      = nameInput.value.trim();
    const typeVal   = typeSelect.value;
    const locatie   = locationSelect.value;
    const startVal  = form.querySelector('#evtStart').value;
    const eindVal   = form.querySelector('#evtEnd').value;
    const bus       = form.querySelector('#evtBus').value;
    const personen  = Array.from(
                       form.querySelectorAll('input[name="personen"]:checked')
                     ).map(cb=>cb.value);
    const commissie = parseFloat(form.querySelector('#evtCommission').value)||0;
    const stageld   = parseFloat(form.querySelector('#evtStipend').value)||0;

    if(!naam||!typeVal||!locatie||!startVal||!eindVal||personen.length===0){
      return showAlert('⚠️ Vul alle verplichte velden in.','warning');
    }

    try {
      let id;
      if (isNew) {
        id = crypto.randomUUID?.()||Date.now().toString();
        const newEvt = {
          id, naam, locatie, type: typeVal, personen,
          bus, commissie, stageld, state:'planned',
          startdatum:startVal, einddatum:eindVal,
          sessions:[], kosten:{}
        };
        db.evenementen.push(newEvt);
      } else {
        id = eventData.id;
        const idx = db.evenementen.findIndex(e=>e.id===id);
        db.evenementen[idx] = {
          ...db.evenementen[idx],
          naam, locatie, type:typeVal, personen,
          bus, commissie, stageld, state:'planned',
          startdatum:startVal, einddatum:eindVal
        };
      }
      await saveEvent(id);
      showAlert(isNew ? '✅ Evenement opgeslagen!' : '✅ Evenement bijgewerkt!','success');
      overlay.remove();
    } catch(err) {
      console.error(err);
      showAlert('⚠️ Opslaan mislukt.','error');
    }
  });
}