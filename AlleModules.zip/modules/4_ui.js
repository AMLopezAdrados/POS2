// 📦 4_ui.js — Hoofd-UI (simpel): topbar + drawer + omzet/no-session + salesMount
// Exporteert: showMainMenu, showLoading, hideLoading, showAlert, openSessionMetaModal,
//             renderOmzetCard, openSessionOverviewModal (lazy wrapper)

import { db } from './3_data.js';

// We importeren GEEN andere modules hier bovenaan om cirkels te voorkomen.
// Waar nodig doen we een dynamic import (inside de functie).

// Globale modal-closer die veilig alle open modals sluit
export function closeAllModals() {
  try {
    document.querySelectorAll('.modal').forEach(m => m.remove());
    document.body.classList.remove('modal-open');
  } catch {}
}

// ============ Kleine helpers (globaal gebruikt) ============
export function showLoading(msg = 'Laden…') {
  let ov = document.getElementById('loadingOverlay');
  if (!ov) {
    ov = document.createElement('div');
    ov.id = 'loadingOverlay';
    ov.style.cssText = `
      position:fixed; inset:0; background:rgba(255,255,255,.85);
      display:flex; align-items:center; justify-content:center;
      z-index:99999; font-size:2rem; font-weight:800; color:#2A9626;
    `;
    document.body.appendChild(ov);
  }
  ov.textContent = `⏳ ${msg}`;
  ov.style.display = 'flex';
}

export function hideLoading() {
  const ov = document.getElementById('loadingOverlay');
  if (ov) ov.style.display = 'none';
}

export function showAlert(message, type = 'info') {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.style.cssText = `
    position:fixed; left:50%; bottom:22px; transform:translateX(-50%);
    background:${type === 'error' ? '#e53935' : type === 'success' ? '#2E7D32' : type === 'warning' ? '#FB8C00' : '#2A9626'};
    color:#fff; padding:.6rem .9rem; border-radius:.7rem; font-weight:800;
    box-shadow:0 6px 18px rgba(0,0,0,.25); z-index:10000; opacity:.98;
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

// ============ Hoofd‑UI ============
export async function showMainMenu() {
  const app = document.getElementById('app');
  if (!app) return;
  injectHeadStylesOnce();

  // Schoon vegen (en legacy rommel zeker weg)
  app.innerHTML = '';
  document.querySelectorAll('#omzetCard, .active-session-strip, #sessieOverviewFixed').forEach(n => n.remove());

  // Topbar
  app.appendChild(buildTopbar());

  // Drawer (sidebar)
  app.appendChild(buildDrawer());

  // Content scaffold
  const main = document.createElement('main');
  main.id = 'mainContent';
  main.style.cssText = 'display:flex; flex-direction:column; gap:.7rem; padding:.6rem;';
  app.appendChild(main);

  // Omzetkaart (geen sessie → “vandaag”, met sessie → ook tonen, maar verkoopknoppen komen eronder)
  const omzetMount = document.createElement('div');
  omzetMount.id = 'omzetMount';
  main.appendChild(omzetMount);
  await renderOmzetCard(); // veilig, toont wat er is

  // Mount voor verkoopscherm
  const salesMount = document.createElement('div');
  salesMount.id = 'salesMount';
  main.appendChild(salesMount);

  // Als er een open sessie is → verkoop UI erin
  if (window.actieveSessieRef?.sessie?.endTime === 'OPEN') {
    const { toonVerkoopKnoppen } = await import('./8_verkoopscherm.js');
    await toonVerkoopKnoppen();
  }
}

// ============ Topbar + Drawer ============
function buildTopbar() {
  const bar = document.createElement('header');
  bar.className = 'app-topbar';

  const left = document.createElement('div');
  left.className = 'tb-left';

  const burger = document.createElement('button');
  burger.className = 'tb-btn';
  burger.textContent = '☰';
  burger.onclick = () => toggleDrawer(true);
  left.appendChild(burger);

  const title = document.createElement('div');
  title.className = 'tb-title';
  title.textContent = getActiveTitle() || "Olga's Cheese POS";
  left.appendChild(title);

  const right = document.createElement('div');
  right.className = 'tb-right';

  // Net indicator
  const net = document.createElement('span');
  net.id = 'netBadge';
  net.className = navigator.onLine ? 'net ok' : 'net off';
  right.appendChild(net);

  // Sessieoverzicht knop
  const sessieBtn = document.createElement('button');
  sessieBtn.className = 'tb-btn';
  sessieBtn.textContent = '📊';
  sessieBtn.title = 'Sessieoverzicht';
  sessieBtn.onclick = async () => {
    const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
    const ref = window.actieveSessieRef;
    if (ref?.eventId && ref?.sessieId) openSessionOverviewModal(ref.eventId, ref.sessieId, ref.event?.naam);
    else openSessionOverviewModal();
  };
  right.appendChild(sessieBtn);

  bar.appendChild(left);
  bar.appendChild(right);

  // Online/offline updates
  const update = () => {
    const b = document.getElementById('netBadge');
    if (!b) return;
    b.className = navigator.onLine ? 'net ok' : 'net off';
  };
  window.addEventListener('online', update);
  window.addEventListener('offline', update);

  return bar;
}

function buildDrawer() {
  const panel = document.createElement('aside');
  panel.id = 'sideDrawer';
  panel.className = 'drawer';

  const overlay = document.createElement('div');
  overlay.className = 'drawer-overlay';
  overlay.onclick = () => toggleDrawer(false);
  panel.appendChild(overlay);

  const sheet = document.createElement('div');
  sheet.className = 'drawer-sheet';
  panel.appendChild(sheet);

  const header = document.createElement('div');
  header.className = 'drawer-head';
  header.innerHTML = `<strong>Menu</strong>`;
  const close = document.createElement('button');
  close.className = 'tb-btn';
  close.textContent = '✕';
  close.onclick = () => toggleDrawer(false);
  header.appendChild(close);
  sheet.appendChild(header);

  const list = document.createElement('div');
  list.className = 'drawer-list';
  sheet.appendChild(list);

  // Acties
  list.appendChild(group('Acties', [
    btn('📅 Start sessie', async () => {
      toggleDrawer(false);
      const mod = await import('./1_sessiebeheer.js');
      mod.startSession();
    }),
    btn('🔒 Dagafsluiting', async () => {
      toggleDrawer(false);
      const mod = await import('./1_sessiebeheer.js');
      mod.sluitDagAf();
    }),
    btn('ℹ️ Sessie-gegevens', async () => {
      toggleDrawer(false);
      openSessionMetaModal();
    }),
    btn('📊 Sessieoverzicht', async () => {
      toggleDrawer(false);
      const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
      const ref = window.actieveSessieRef;
      if (ref?.eventId && ref?.sessieId) openSessionOverviewModal(ref.eventId, ref.sessieId, ref.event?.naam);
      else openSessionOverviewModal();
    }),
  ]));

  // Beheer
  list.appendChild(group('Beheer', [
    btn('🎪 Evenementen', async () => { toggleDrawer(false); const m = await import('./5_eventbeheer.js'); m.toonEvenementenMenu(); }),
    btn('📦 Voorraad',    async () => { toggleDrawer(false); const m = await import('./6_beheerVoorraad.js'); m.toonVoorraadModal(); }),
    btn('✈️ Reisplanner', async () => { toggleDrawer(false); const m = await import('./14_reisPlanning.js'); m.openReisPlannerModal(); }),
    // Alleen admin
    (() => {
      const user = JSON.parse(localStorage.getItem('gebruiker')||'{}');
      if (user?.role === 'admin') {
        return btn('👤 Gebruikers', async () => { toggleDrawer(false); const m = await import('./11_gebruikersbeheer.js'); m.beheerGebruikers(); });
      }
   // Inzichten
     list.appendChild(group('Inzichten', [
     btn('📈 Inzichten', async () => {
    toggleDrawer(false);
    const { openInzichtenModal } = await import('./17_inzichten.js');
    openInzichtenModal();
  }),
]));
      const dummy = document.createElement('span'); dummy.style.display='none'; return dummy;
    })(),
  ]));

  // Systeem
  list.appendChild(group('Systeem', [
    btn('🔁 Forceer sync', async () => {
      toggleDrawer(false);
      try {
        const { verkoopManager } = await import('./16_VerkoopManager.js');
        verkoopManager.syncAll();
        showAlert('🔁 Sync getriggerd', 'info');
      } catch { showAlert('⚠️ Sync niet gelukt', 'warning'); }
    }),
  ]));

  return panel;

  function group(t, items) {
    const g = document.createElement('section');
    g.className = 'drawer-group';
    const h = document.createElement('div');
    h.className = 'drawer-title';
    h.textContent = t;
    g.appendChild(h);
    const w = document.createElement('div');
    w.className = 'drawer-items';
    items.forEach(i => w.appendChild(i));
    g.appendChild(w);
    return g;
  }
  function btn(label, onClick) {
    const b = document.createElement('button');
    b.className = 'drawer-item';
    b.textContent = label;
    b.onclick = onClick;
    return b;
  }
}

function toggleDrawer(open) {
  const d = document.getElementById('sideDrawer');
  if (!d) return;
  if (open) d.classList.add('open'); else d.classList.remove('open');
}

function getActiveTitle() {
  const ref = window.actieveSessieRef;
  if (ref?.event && ref?.sessie?.endTime === 'OPEN') {
    return `${ref.event.naam} • ${ref.event.locatie || ''}`.trim();
  }
  const act = (db.evenementen || []).filter(e => e.state === 'active');
  return act.length ? `${act[0].naam} • ${act[0].locatie || ''}` : '';
}

// ============ Omzetkaart (simpel) ============
export async function renderOmzetCard() {
  const mount = document.getElementById('omzetMount');
  if (!mount) return;
  mount.innerHTML = '';

  const card = document.createElement('div');
  card.id = 'omzetCard';
  card.className = 'omzet-card';

  // Default: toon “Omzet vandaag (alle sessies)”
  let title = 'Omzet vandaag (alle sessies)';
  let usd = 0, eur = 0, klanten = 0;

  try {
    // Als er een actieve sessie is, halen we via 12_sessieDetails de bedragen op
    const ref = window.actieveSessieRef;
    if (ref?.eventId && ref?.sessieId) {
      const { getSessionOverview } = await import('./12_sessieDetails.js');
      const ovz = await getSessionOverview(ref.eventId, ref.sessieId, ref?.event?.naam);
      usd = Number(ovz?.totalUSD || 0);
      eur = Number(ovz?.totalEUR || 0);
      klanten = Array.isArray(ovz?.verkopen) ? ovz.verkopen.length : 0;
      title = `${ref.event?.naam || 'Sessie'} — omzet`;
      card.onclick = async () => {
        const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
        openSessionOverviewModal(ref.eventId, ref.sessieId, ref?.event?.naam);
      };
    } else {
      // Geen actieve sessie → klik opent sessie-overzichtlijst
      card.onclick = async () => {
        const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
        openSessionOverviewModal();
      };
    }
  } catch {
    // stille fallback
  }

  card.innerHTML = `
    <div class="omzet-title">💰 ${title}</div>
    <div class="omzet-values">$ ${usd.toFixed(2)} &nbsp; • &nbsp; € ${eur.toFixed(2)}</div>
    <div class="omzet-sub">${klanten} klanten (schatting) • Tik voor sessies</div>
  `;

  mount.appendChild(card);
}

// ============ Meta modal ============
export async function openSessionMetaModal() {
  const ref = window.actieveSessieRef;
  if (!ref?.event || !ref?.sessie) return;

  const overlay = document.createElement('div');
  overlay.className = 'modal';
  const box = document.createElement('div');
  box.style.cssText = 'background:#fff; padding:1rem; border-radius:12px; width:min(92vw,560px); max-height:85vh; overflow:auto;';
  overlay.appendChild(box);

  const close = document.createElement('button');
  close.textContent = '✕';
  close.style.cssText = 'position:absolute; right:16px; top:10px; background:#FFC500; border:none; border-radius:8px; padding:.3rem .6rem; font-weight:800; cursor:pointer;';
  close.onclick = () => overlay.remove();
  box.appendChild(close);

  const h2 = document.createElement('h2');
  h2.textContent = 'Sessiegegevens';
  h2.style.color = '#2A9626';
  box.appendChild(h2);

  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid; grid-template-columns:1fr 1fr; gap:8px;';
  box.appendChild(grid);

  const row = (k, v) => {
    const a = document.createElement('div'); a.style.fontWeight = '800'; a.textContent = k;
    const b = document.createElement('div'); b.textContent = v ?? '-';
    grid.appendChild(a); grid.appendChild(b);
  };

  const s = ref.sessie, e = ref.event;
  row('Event', e.naam);
  row('Locatie', e.locatie || '-');
  row('Type', e.type || '-');
  row('Bus', e.bus || '-');
  row('Sessie-ID', s.id);
  row('Gestart', new Date(s.startTime).toLocaleString('nl-NL'));
  row('Status', s.endTime === 'OPEN' ? 'OPEN' : 'GESLOTEN');
  row('Valuta leidend', (s.valuta || 'USD').toUpperCase());
  row('Koers USD→EUR', (typeof s.exchangeRate === 'number') ? s.exchangeRate.toFixed(2) : '-');
  row('Gebruikers', (s.gebruikers || []).filter(Boolean).join(', ') || '-');

  const actions = document.createElement('div');
  actions.style.cssText = 'display:flex; gap:.5rem; margin-top:.8rem;';
  box.appendChild(actions);

  const btnOvz = document.createElement('button');
  btnOvz.textContent = '📊 Sessieoverzicht';
  btnOvz.style.cssText = 'background:#2A9626; color:#fff; border:none; border-radius:8px; padding:.5rem .8rem; font-weight:800;';
  btnOvz.onclick = async () => {
    const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
    overlay.remove();
    openSessionOverviewModal(e.id, s.id, e.naam);
  };
  actions.appendChild(btnOvz);

  const btnClose = document.createElement('button');
  btnClose.textContent = 'Sluiten';
  btnClose.style.cssText = 'background:#ddd; border:none; border-radius:8px; padding:.5rem .8rem; font-weight:800;';
  btnClose.onclick = () => overlay.remove();
  actions.appendChild(btnClose);

  document.body.appendChild(overlay);
}

// Lazy export wrapper zodat andere modules kunnen importeren zonder cirkel
export async function openSessionOverviewModal(...args) {
  const mod = await import('./12_sessieDetails.js');
  return mod.openSessionOverviewModal(...args);
}

// ============ Styles ============
function injectHeadStylesOnce() {
  if (document.getElementById('ui-head-styles')) return;
  const css = document.createElement('style'); css.id = 'ui-head-styles';
  css.textContent = `
    .app-topbar{
      position:sticky; top:0; z-index:50; display:flex; align-items:center; justify-content:space-between;
      background:#2A9626; color:#fff; padding:.6rem .7rem; box-shadow:0 2px 8px rgba(0,0,0,.15); border-radius:.8rem;
    }
    .tb-left{ display:flex; align-items:center; gap:.5rem; }
    .tb-btn{ background:rgba(255,255,255,.16); border:1px solid rgba(255,255,255,.25); color:#fff; padding:.4rem .6rem; border-radius:.6rem; font-weight:800; }
    .tb-title{ font-weight:900; max-width:65vw; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .tb-right{ display:flex; align-items:center; gap:.4rem; }
    .net{ display:inline-block; width:10px; height:10px; border-radius:50%; background:#bbb; }
    .net.ok{ background:#9AE66E; } .net.off{ background:#FF7043; }

    .drawer{ position:fixed; inset:0; pointer-events:none; z-index:60; }
    .drawer.open{ pointer-events:auto; }
    .drawer-overlay{ position:absolute; inset:0; background:rgba(0,0,0,.25); opacity:0; transition:opacity .2s; }
    .drawer.open .drawer-overlay{ opacity:1; }
    .drawer-sheet{
      position:absolute; top:0; left:0; bottom:0; width:min(420px, 82vw); background:#fff;
      transform:translateX(-100%); transition:transform .25s; box-shadow:2px 0 16px rgba(0,0,0,.2);
      display:flex; flex-direction:column;
    }
    .drawer.open .drawer-sheet{ transform:translateX(0); }
    .drawer-head{ display:flex; align-items:center; justify-content:space-between; padding:.7rem .8rem; background:#1F6D1C; color:#fff; }
    .drawer-list{ padding:.6rem; overflow:auto; }
    .drawer-title{ font-weight:900; color:#2A9626; margin:.4rem 0; }
    .drawer-item{
      width:100%; text-align:left; padding:.55rem .7rem; margin:.25rem 0; border-radius:.6rem; border:1px solid #eee;
      background:#ffc500; font-weight:800;
    }

    .omzet-card{
      background:#2A9626; color:#fff; border-radius:.9rem; padding:1rem;
      box-shadow:0 6px 18px rgba(0,0,0,.15); text-align:center; cursor:pointer;
    }
    .omzet-title{ font-weight:900; font-size:1.05rem; margin-bottom:.25rem; }
    .omzet-values{ font-weight:900; font-size:1.7rem; }
    .omzet-sub{ opacity:.9; margin-top:.2rem; }

    #salesMount{ margin-top:.4rem; }
  `;
  document.head.appendChild(css);
}

// === Sidebar (slide-in) ===================================================
let _sidebarBuilt = false;

export function openSidebar()  { document.getElementById('oc-sidebar')?.classList.add('open'); }
export function closeSidebar() { document.getElementById('oc-sidebar')?.classList.remove('open'); }

export function ensureSidebar() {
  if (_sidebarBuilt) return;
  _injectSidebarStyles();

  // Paneel + overlay
  const wrap = document.createElement('aside');
  wrap.id = 'oc-sidebar';
  wrap.innerHTML = `
    <div class="oc-overlay"></div>
    <nav class="oc-panel" role="menu" aria-label="Hoofdmenu">
      <div class="oc-head">
        <div class="brand">Olga’s Cheese POS</div>
        <button class="oc-close" aria-label="Sluiten">✕</button>
      </div>

      <section class="oc-group">
        <div class="oc-title">Sessie</div>
        <button class="oc-item oc-green"   data-action="start">📅 Dagstart / Hervatten</button>
        <button class="oc-item oc-red"     data-action="close">🔒 Dagafsluiting</button>
        <button class="oc-item oc-blue"    data-action="overview">📊 Sessieoverzicht</button>
        <button class="oc-item oc-slate"   data-action="meta">ℹ️ Sessie‑gegevens</button>
      </section>

      <section class="oc-group">
        <div class="oc-title">Beheer</div>
        <button class="oc-item oc-amber"   data-action="voorraad">📦 Voorraad</button>
        <button class="oc-item oc-indigo"  data-action="events">🎪 Evenementen</button>
        <button class="oc-item oc-purple"  data-action="reis">✈️ Reisplanner</button>
        <button class="oc-item oc-stone"   data-action="gebruikers">👤 Gebruikers</button>
      </section>
      
      <section class="oc-group">
        <div class="oc-title">Inzichten</div>
        <button class="oc-item oc-blue" data-action="inzichten">📈 Inzichten</button>
      </section>
    </nav>
  `;
  document.body.appendChild(wrap);

  // Close hooks
  wrap.querySelector('.oc-overlay').onclick = closeSidebar;
  wrap.querySelector('.oc-close').onclick   = closeSidebar;

  // Acties
  wrap.querySelectorAll('.oc-item').forEach(btn => {
    btn.onclick = async () => {
      const act = btn.dataset.action;
      try {
        if (act === 'start') {
          const { startSession } = await import('./1_sessiebeheer.js');
          closeSidebar(); startSession();
        } else if (act === 'close') {
          const { sluitDagAf } = await import('./1_sessiebeheer.js');
          if (!window.actieveSessieRef?.sessie) {
            const { showAlert } = await import('./4_ui.js');
            showAlert('Geen actieve sessie om af te sluiten.', 'warning');
            return;
          }
          closeSidebar(); sluitDagAf();
        } else if (act === 'overview') {
          const { openSessionOverviewModal } = await import('./12_sessieDetails.js');
          closeSidebar();
          const ref = window.actieveSessieRef;
          if (ref?.eventId && ref?.sessieId) openSessionOverviewModal(ref.eventId, ref.sessieId, ref.event?.naam);
          else openSessionOverviewModal();
        } else if (act === 'meta') {
          const { openSessionMetaModal } = await import('./4_ui.js');
          closeSidebar(); openSessionMetaModal();
        } else if (act === 'voorraad') {
          const { toonVoorraadModal } = await import('./6_beheerVoorraad.js');
          closeSidebar(); toonVoorraadModal();
        } else if (act === 'events') {
          const { toonEvenementenMenu } = await import('./5_eventbeheer.js');
          closeSidebar(); toonEvenementenMenu();
        } else if (act === 'reis') {
          const { openReisPlannerModal } = await import('./14_reisPlanning.js');
          closeSidebar(); openReisPlannerModal();
        } else if (act === 'gebruikers') {
          const { beheerGebruikers } = await import('./11_gebruikersbeheer.js');
          closeSidebar(); beheerGebruikers();
        } else if (act === 'inzichten') {
          const { openInzichtenModal } = await import('./17_inzichten.js');
          closeSidebar();
          openInzichtenModal();
        }
      } catch (err) {
        console.error('Sidebar actie fout:', err);
        const { showAlert } = await import('./4_ui.js');
        showAlert('Actie kon niet worden geopend.', 'error');
      }
    };
  });

  _sidebarBuilt = true;
}

// Call dit 1x vanuit showMainMenu() nadat de header is gerenderd:
export function wireBurgerButton() {
  ensureSidebar();
  // verwacht een element met id="burgerBtn" in je header
  const b = document.getElementById('burgerBtn');
  if (b) b.onclick = openSidebar;
}

function _injectSidebarStyles() {
  if (document.getElementById('oc-sidebar-css')) return;
  const css = document.createElement('style');
  css.id = 'oc-sidebar-css';
  css.textContent = `
    #oc-sidebar { position:fixed; inset:0; z-index:10000; pointer-events:none; }
    #oc-sidebar.open { pointer-events:auto; }
    #oc-sidebar .oc-overlay { position:absolute; inset:0; background:rgba(0,0,0,.35); opacity:0; transition:opacity .2s; }
    #oc-sidebar.open .oc-overlay { opacity:1; }

    #oc-sidebar .oc-panel{
      position:absolute; top:0; left:0; bottom:0; width:min(360px, 86vw);
      background:#fff; transform:translateX(-100%); transition:transform .25s ease;
      box-shadow: 2px 0 16px rgba(0,0,0,.25); display:flex; flex-direction:column;
    }
    #oc-sidebar.open .oc-panel{ transform:translateX(0); }

    .oc-head{ display:flex; justify-content:space-between; align-items:center;
      padding:.75rem .9rem; background:#2A9626; color:#fff; }
    .oc-head .brand{ font-weight:900; }
    .oc-head .oc-close{ background:#fff; color:#2A9626; border:none; border-radius:.5rem; padding:.3rem .6rem; font-weight:900; }

    .oc-group{ padding:.6rem .6rem .2rem; }
    .oc-title{ font-weight:900; color:#2A9626; margin:.35rem .2rem; }

    .oc-item{
      display:block; width:100%; text-align:left; border:none; border-radius:.6rem;
      padding:.6rem .8rem; margin:.25rem 0; font-weight:800; color:#fff; cursor:pointer;
    }
    .oc-item:active{ transform:translateY(1px); }

    /* Kleurvarianten (leesbaar!) */
    .oc-green { background:#2E7D32; }
    .oc-red   { background:#C62828; }
    .oc-blue  { background:#1976D2; }
    .oc-slate { background:#455A64; }
    .oc-amber { background:#FB8C00; }
    .oc-indigo{ background:#5C6BC0; }
    .oc-purple{ background:#8E24AA; }
    .oc-stone { background:#6D4C41; }

    .oc-item:hover { filter:brightness(1.05); }
  `;
  document.head.appendChild(css);
}

// 👉 Zet dit NA de bestaande sidebar CSS, zodat het wint
(function ensureSidebarContrastCSS(){
  if (document.getElementById('oc-sidebar-contrast')) return;
  const css = document.createElement('style');
  css.id = 'oc-sidebar-contrast';
  css.textContent = `
    /* Forceer contrastrijke knoppen in het zijmenu */
    #oc-sidebar .oc-item {
      color: #ffC500 !important;
      background: #2A9626 !important; /* basis groen */
      border: none !important;
    }
    #oc-sidebar .oc-item.oc-green  { background: #2E7D32 !important; }
    #oc-sidebar .oc-item.oc-red    { background: #C62828 !important; }
    #oc-sidebar .oc-item.oc-blue   { background: #1976D2 !important; }
    #oc-sidebar .oc-item.oc-slate  { background: #455A64 !important; }
    #oc-sidebar .oc-item.oc-amber  { background: #FB8C00 !important; }
    #oc-sidebar .oc-item.oc-indigo { background: #5C6BC0 !important; }
    #oc-sidebar .oc-item.oc-purple { background: #8E24AA !important; }
    #oc-sidebar .oc-item.oc-stone  { background: #6D4C41 !important; }

    #oc-sidebar .oc-item:hover { filter: brightness(1.06) !important; }
    #oc-sidebar .oc-item:disabled {
      opacity: .55 !important;
      cursor: not-allowed !important;
      filter: none !important;
    }
  `;
  document.head.appendChild(css);
})();