// 📦 6_beheerVoorraad.js – Voorraadbeheer/transfer/inkoop (heldere UI, compatible met huidige systeem)

import { db, saveVoorraad } from './3_data.js';
import { openProductModal } from './7_beheerProducten.js';
import { toonVerkoopKnoppen } from './8_verkoopscherm.js';
import { showAlert } from './4_ui.js';

// ===== Helpers =====
function ensureBussen() {
  db.voorraad = db.voorraad || {};
  if (!Object.keys(db.voorraad).length) {
    db.voorraad.Rene = {};
    db.voorraad.Pierre = {};
  }
}
function getBussen() {
  ensureBussen();
  return Object.keys(db.voorraad);
}
function packSize(name) {
  const n = String(name || '').toUpperCase();
  if (n.includes('ROOK')) return 10;
  if (n.includes('GEIT')) return 15;
  if (n.includes('BG'))   return 18;
  return 1;
}
function btnPrimary(el) {
  Object.assign(el.style, {
    background:'#2A9626', color:'#fff', border:'none', borderRadius:'10px', padding:'.55rem .9rem', fontWeight:'900'
  });
}
function btnWarn(el) {
  Object.assign(el.style, {
    background:'#FFC500', color:'#1b1b1b', border:'none', borderRadius:'10px', padding:'.55rem .9rem', fontWeight:'900'
  });
}
function btnInfo(el) {
  Object.assign(el.style, {
    background:'#1976D2', color:'#fff', border:'none', borderRadius:'10px', padding:'.55rem .9rem', fontWeight:'900'
  });
}
function btnDanger(el) {
  Object.assign(el.style, {
    background:'#E53935', color:'#fff', border:'none', borderRadius:'10px', padding:'.55rem .9rem', fontWeight:'900'
  });
}
function chip(el, active=false) {
  Object.assign(el.style, {
    padding:'.45rem .8rem', borderRadius:'999px', border:'1px solid #ddd',
    background: active ? '#2A9626' : '#f7f7f7', color: active ? '#fff' : '#222',
    fontWeight:'800', cursor:'pointer'
  });
}

// ===== Public: Voorraad modal (tabs) =====
export function toonVoorraadModal() {
  // Sluit modals
  document.querySelectorAll('.modal').forEach(m => m.remove());
  ensureBussen();

  const modal = document.createElement('div');
  modal.className = 'modal';
  Object.assign(modal.style, {
    position:'fixed', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
    background:'rgba(0,0,0,.35)', zIndex:9999
  });

  const content = document.createElement('div');
  Object.assign(content.style, {
    background:'#fff', padding:'1rem 1.1rem', borderRadius:'14px',
    width:'min(980px, 96vw)', maxHeight:'90vh', overflow:'auto',
    boxShadow:'0 10px 30px rgba(0,0,0,.25)'
  });

  const header = document.createElement('div');
  header.style.display = 'flex';
  header.style.alignItems = 'center';
  header.style.justifyContent = 'space-between';
  header.style.marginBottom = '.6rem';
  header.innerHTML = `<h2 style="margin:0; color:#2A9626">📦 Voorraadbeheer</h2>`;
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '❌ Sluiten';
  btnDanger(closeBtn);
  closeBtn.onclick = () => { modal.remove(); toonVerkoopKnoppen(); };
  header.appendChild(closeBtn);
  content.appendChild(header);

  // Tabs
  const tabRow = document.createElement('div');
  tabRow.style.display = 'flex';
  tabRow.style.gap = '.4rem';
  tabRow.style.flexWrap = 'wrap';

  const t1 = document.createElement('button'); t1.textContent = '🧮 Voorraad';
  const t2 = document.createElement('button'); t2.textContent = '🔄 Verplaatsen';
  const t3 = document.createElement('button'); t3.textContent = '🛒 Inkoop';
  chip(t1, true); chip(t2); chip(t3);
  tabRow.append(t1, t2, t3);
  content.appendChild(tabRow);

  const tabWrap = document.createElement('div');
  tabWrap.style.marginTop = '.6rem';
  content.appendChild(tabWrap);

  modal.appendChild(content);
  document.body.appendChild(modal);

  // Renderers
  const renderVoorraad = () => {
    tabWrap.innerHTML = '';
    tabRow.querySelectorAll('button').forEach(b => chip(b, false)); chip(t1, true);

    // Admin acties
    const gebruiker = JSON.parse(localStorage.getItem('gebruiker')) || {};
    if (gebruiker.role === 'admin') {
      const bar = document.createElement('div');
      bar.style.display = 'flex';
      bar.style.gap = '.5rem';
      bar.style.flexWrap = 'wrap';
      bar.style.marginBottom = '.6rem';

      const btnProd = document.createElement('button');
      btnProd.textContent = '📦 Producten beheren';
      btnInfo(btnProd);
      btnProd.onclick = () => { modal.remove(); setTimeout(openProductModal, 50); };

      const btnInk = document.createElement('button');
      btnInk.textContent = '🛒 Inkoop toevoegen';
      btnPrimary(btnInk);
      btnInk.onclick = () => { modal.remove(); openInkoopModal(); };

      bar.append(btnProd, btnInk);
      tabWrap.appendChild(bar);
    }

    // Tabel per bus
    const bussen = getBussen();
    const grid = document.createElement('div');
    grid.style.display = 'grid';
    grid.style.gridTemplateColumns = '1fr';
    grid.style.gap = '.8rem';

    bussen.forEach(bus => {
      const card = document.createElement('div');
      Object.assign(card.style, {
        border:'1px solid #eee', borderRadius:'12px', padding:'.6rem .7rem'
      });
      const title = document.createElement('div');
      title.innerHTML = `<b>Bus: ${bus}</b>`;
      card.appendChild(title);

      const tableWrap = document.createElement('div');
      tableWrap.style.overflowX = 'auto';
      const table = document.createElement('table');
      table.style.width = '100%';
      table.style.borderCollapse = 'collapse';

      const thead = document.createElement('thead');
      thead.innerHTML = `
        <tr>
          <th style="text-align:left; padding:.45rem; position:sticky; top:0; background:#f5f5f5;">Product</th>
          <th style="padding:.45rem; position:sticky; top:0; background:#f5f5f5;">Aantal</th>
          <th style="padding:.45rem; position:sticky; top:0; background:#f5f5f5;">Opslag</th>
        </tr>`;
      table.appendChild(thead);

      const tbody = document.createElement('tbody');
      db.producten.forEach(p => {
        const tr = document.createElement('tr');

        const curr = Number(db.voorraad[bus]?.[p.naam] || 0);

        tr.innerHTML = `
          <td style="padding:.45rem;">${p.naam}</td>
          <td style="padding:.45rem; text-align:center;">
            <input type="number" data-bus="${bus}" data-prod="${p.naam}" value="${curr}" min="0"
                   style="width:90px; text-align:right; padding:.35rem; border:1px solid #ddd; border-radius:8px;">
          </td>
          <td style="padding:.45rem; text-align:center;">
            <span style="font-size:.85rem; color:#666;">${packSize(p.naam)} per krat/doos</span>
          </td>
        `;
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      tableWrap.appendChild(table);
      card.appendChild(tableWrap);
      grid.appendChild(card);
    });

    tabWrap.appendChild(grid);

    // Opslaan
    const actions = document.createElement('div');
    actions.style.display = 'flex';
    actions.style.justifyContent = 'flex-end';
    actions.style.gap = '.5rem';
    actions.style.marginTop = '.7rem';

    const saveBtn = document.createElement('button');
    saveBtn.textContent = '💾 Opslaan';
    btnPrimary(saveBtn);
    saveBtn.onclick = async () => {
      tabWrap.querySelectorAll('input[type="number"][data-bus]').forEach(inp => {
        const bus = inp.dataset.bus;
        const prod = inp.dataset.prod;
        db.voorraad[bus][prod] = Math.max(0, parseInt(inp.value, 10) || 0);
      });
      await saveVoorraad();
      showAlert('✅ Voorraad opgeslagen', 'success');
      modal.remove(); toonVerkoopKnoppen();
    };

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = '❌ Annuleren';
    btnDanger(cancelBtn);
    cancelBtn.onclick = () => { modal.remove(); toonVerkoopKnoppen(); };

    actions.append(saveBtn, cancelBtn);
    tabWrap.appendChild(actions);
  };

  const renderTransfer = () => {
    tabWrap.innerHTML = '';
    tabRow.querySelectorAll('button').forEach(b => chip(b, false)); chip(t2, true);

    const bussen = getBussen();
    if (bussen.length < 2) {
      tabWrap.innerHTML = `<div style="padding:.7rem; background:#FFF4E5; border:1px solid #FFE0B2; border-radius:10px; color:#6B4E00;">
        Je hebt minimaal twee bussen nodig om te verplaatsen.</div>`;
      return;
    }

    // Kop: bron/dest
    const pick = document.createElement('div');
    pick.style.display = 'grid';
    pick.style.gridTemplateColumns = '1fr 1fr';
    pick.style.gap = '.6rem';
    pick.style.alignItems = 'center';

    const srcSel = document.createElement('select');
    const dstSel = document.createElement('select');
    [srcSel, dstSel].forEach(sel => {
      Object.assign(sel.style, { padding:'.5rem', border:'1px solid #ddd', borderRadius:'8px' });
      bussen.forEach(b => {
        const o = document.createElement('option'); o.value = b; o.textContent = b; sel.appendChild(o);
      });
    });
    dstSel.selectedIndex = 1;

    const swapBtn = document.createElement('button');
    swapBtn.textContent = '⇄ Wissel';
    btnWarn(swapBtn);
    swapBtn.onclick = () => {
      const si = srcSel.selectedIndex;
      srcSel.selectedIndex = dstSel.selectedIndex;
      dstSel.selectedIndex = si;
      renderRows();
    };

    pick.append(
      wrapLabel('Van bus', srcSel),
      wrapLabel('Naar bus', dstSel)
    );

    const toolsRow = document.createElement('div');
    toolsRow.style.display = 'flex';
    toolsRow.style.justifyContent = 'space-between';
    toolsRow.style.alignItems = 'center';
    toolsRow.style.margin = '.6rem 0';

    const hint = document.createElement('div');
    hint.style.color = '#555';
    hint.textContent = 'Vul per product het aantal te verplaatsen stuks in.';

    const fillAllBtn = document.createElement('button');
    fillAllBtn.textContent = '↦ Alles verplaatsen (max)';
    btnInfo(fillAllBtn);

    toolsRow.append(hint, fillAllBtn);

    const list = document.createElement('div');
    list.style.display = 'flex';
    list.style.flexDirection = 'column';
    list.style.gap = '.35rem';

    const renderRows = () => {
      list.innerHTML = '';
      db.producten.forEach(p => {
        const row = document.createElement('div');
        Object.assign(row.style, {
          display:'grid', gridTemplateColumns:'1fr auto 120px', gap:'.5rem', alignItems:'center',
          border:'1px solid #eee', borderRadius:'10px', padding:'.45rem .55rem'
        });
        const avail = Number(db.voorraad[srcSel.value]?.[p.naam] || 0);
        const name = document.createElement('div');
        name.innerHTML = `<div style="font-weight:800">${p.naam}</div>
                          <div style="font-size:.8rem; color:#666;">Beschikbaar: ${avail}</div>`;

        const packTag = document.createElement('div');
        packTag.style.fontSize = '.85rem';
        packTag.style.color = '#666';
        packTag.textContent = `${packSize(p.naam)}/krat/doos`;

        const inp = document.createElement('input');
        Object.assign(inp, { type:'number', min:0, max:avail, value:0 });
        Object.assign(inp.style, {
          width:'120px', textAlign:'right', padding:'.4rem .45rem', border:'1px solid #ddd', borderRadius:'8px'
        });
        inp.oninput = () => {
          const v = Math.max(0, Math.min(avail, parseInt(inp.value, 10) || 0));
          inp.value = v;
        };

        row.append(name, packTag, inp);
        list.appendChild(row);
      });
    };

    fillAllBtn.onclick = () => {
      list.querySelectorAll('input[type="number"]').forEach((inp, i) => {
        const p = db.producten[i];
        const avail = Number(db.voorraad[srcSel.value]?.[p.naam] || 0);
        inp.value = avail;
      });
    };

    const actions = document.createElement('div');
    actions.style.display = 'flex';
    actions.style.justifyContent = 'flex-end';
    actions.style.gap = '.5rem';
    actions.style.marginTop = '.7rem';

    const doBtn = document.createElement('button');
    doBtn.textContent = '✅ Overboeken';
    btnPrimary(doBtn);

    const backBtn = document.createElement('button');
    backBtn.textContent = '❌ Annuleren';
    btnDanger(backBtn);

    doBtn.onclick = async () => {
      if (srcSel.value === dstSel.value) return showAlert('⚠️ Kies twee verschillende bussen.', 'warning');

      let moved = 0;
      list.querySelectorAll('input[type="number"]').forEach((inp, i) => {
        const v = Math.max(0, parseInt(inp.value, 10) || 0);
        if (!v) return;
        const prod = db.producten[i].naam;
        db.voorraad[srcSel.value][prod] = Math.max(0, Number(db.voorraad[srcSel.value][prod] || 0) - v);
        db.voorraad[dstSel.value][prod] = Math.max(0, Number(db.voorraad[dstSel.value][prod] || 0) + v);
        moved += v;
      });
      await saveVoorraad();
      showAlert(`✅ ${moved} stuks verplaatst: ${srcSel.value} → ${dstSel.value}`, 'success');
      modal.remove(); toonVerkoopKnoppen();
    };
    backBtn.onclick = () => { modal.remove(); toonVerkoopKnoppen(); };

    // Init
    renderRows();
    srcSel.onchange = renderRows;
    dstSel.onchange = renderRows;

    tabWrap.append(pick, toolsRow, list, actions);
    actions.append(doBtn, backBtn);
  };

  const renderInkoop = () => {
    tabWrap.innerHTML = '';
    tabRow.querySelectorAll('button').forEach(b => chip(b, false)); chip(t3, true);
    openInkoopModal(); // gebruikt losstaande modal; sluit deze en heropen voorraadmodal indien nodig
    setTimeout(() => { modal.remove(); }, 0);
  };

  // Tab handlers
  t1.onclick = renderVoorraad;
  t2.onclick = renderTransfer;
  t3.onclick = renderInkoop;

  // Start
  renderVoorraad();

  function wrapLabel(label, node) {
    const w = document.createElement('div');
    w.innerHTML = `<div style="font-weight:800; margin-bottom:.2rem;">${label}</div>`;
    w.appendChild(node);
    return w;
  }
}

// ===== Public: Inkoop (per krat/doos) =====
export function openInkoopModal() {
  // Sluit bestaande modals
  document.querySelectorAll('.modal').forEach(m => m.remove());
  ensureBussen();

  const modal = document.createElement('div'); 
  modal.className = 'modal';
  Object.assign(modal.style, {
    position:'fixed', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
    background:'rgba(0,0,0,.35)', zIndex:9999
  });

  const content = document.createElement('div');
  Object.assign(content.style, {
    background:'#fff',
    padding:'1rem 1.2rem',
    borderRadius:'12px',
    width:'min(760px, 94vw)',
    maxHeight:'90vh',
    overflowY:'auto',
    boxShadow:'0 8px 24px rgba(0,0,0,0.25)'
  });

  const h2 = document.createElement('h2');
  h2.textContent = '🛒 Inkoop per krat/doos';
  h2.style.marginTop = '0';
  h2.style.color = '#2A9626';
  content.appendChild(h2);

  // Bus select
  const busWrap = document.createElement('div');
  busWrap.style.display = 'grid';
  busWrap.style.gridTemplateColumns = 'auto 1fr';
  busWrap.style.alignItems = 'center';
  busWrap.style.gap = '.6rem';
  busWrap.style.margin = '.2rem 0 .8rem 0';
  busWrap.innerHTML = `<label style="font-weight:800;">Ontvangende bus</label>`;
  const busSel = document.createElement('select');
  Object.assign(busSel.style, { padding: '.5rem', border: '1px solid #ddd', borderRadius: '8px' });
  getBussen().forEach(b => {
    const o = document.createElement('option'); o.value = b; o.textContent = b; busSel.appendChild(o);
  });
  busWrap.appendChild(busSel);
  content.appendChild(busWrap);

  // Legenda
  const legend = document.createElement('div');
  legend.innerHTML = `
    <div style="font-size:.95rem; color:#444; margin:.2rem 0 .8rem 0;">
      <b>Per verpakking:</b> BG = 18, ROOK = 10, GEIT = 15.<br>
      Met <b>+/−</b> wijzig je het aantal kratten/dozen; daarna kun je <i>losse stuks</i> handmatig aanpassen.
    </div>
  `;
  content.appendChild(legend);

  // Lijst
  const list = document.createElement('div');
  list.style.display = 'flex';
  list.style.flexDirection = 'column';
  list.style.gap = '.45rem';
  content.appendChild(list);

  db.producten.forEach(p => {
    const pack = packSize(p.naam);

    const row = document.createElement('div');
    Object.assign(row.style, {
      display: 'grid',
      gridTemplateColumns: '1fr auto auto auto',
      gap: '.5rem',
      alignItems: 'center',
      border: '1px solid #eee',
      borderRadius: '10px',
      padding: '.5rem .6rem'
    });

    const nameCol = document.createElement('div');
    nameCol.innerHTML = `
      <div style="font-weight:800">${p.naam}</div>
      <div style="font-size:.85rem; color:#666;">per ${pack >= 10 ? 'krat/doos' : 'stuks'}: <b>${pack}</b></div>
    `;

    const btnMin = document.createElement('button');
    btnMin.textContent = '−';
    Object.assign(btnMin.style, {
      width: '42px', height: '36px', borderRadius: '8px',
      background: '#E53935', color: '#fff', border: 'none', fontWeight: '900', fontSize:'1.1rem'
    });

    const crateCol = document.createElement('div');
    crateCol.style.textAlign = 'center';
    crateCol.innerHTML = `
      <div style="font-size:1.05rem; font-weight:900" data-crates>0</div>
      <div style="font-size:.8rem; color:#666">kratten</div>
    `;

    const btnPlus = document.createElement('button');
    btnPlus.textContent = '+';
    Object.assign(btnPlus.style, {
      width: '42px', height: '36px', borderRadius: '8px',
      background: '#2A9626', color: '#fff', border: 'none', fontWeight: '900', fontSize:'1.1rem'
    });

    const unitsWrap = document.createElement('div');
    unitsWrap.style.gridColumn = '1 / -1';
    unitsWrap.style.display = 'grid';
    unitsWrap.style.gridTemplateColumns = 'auto 140px';
    unitsWrap.style.alignItems = 'center';
    unitsWrap.style.gap = '.5rem';
    unitsWrap.innerHTML = `
      <label style="font-weight:700;">Totaal stuks</label>
      <input type="number" min="0" step="1" value="0" data-units
        style="width: 140px; padding:.45rem .5rem; border:1px solid #ddd; border-radius:8px; text-align:right;">
    `;

    row.append(nameCol, btnMin, crateCol, btnPlus, unitsWrap);
    list.appendChild(row);

    const cratesEl = crateCol.querySelector('[data-crates]');
    const unitsEl  = unitsWrap.querySelector('[data-units]');

    function setCrates(newCrates) {
      const c = Math.max(0, Number(newCrates || 0));
      cratesEl.textContent = String(c);
      unitsEl.value = String(c * pack);
    }
    function syncCratesFromUnits() {
      const u = Math.max(0, Number(unitsEl.value || 0));
      const c = Math.floor(u / pack);
      cratesEl.textContent = String(c);
    }

    btnMin.onclick = () => setCrates(Number(cratesEl.textContent) - 1);
    btnPlus.onclick = () => setCrates(Number(cratesEl.textContent) + 1);
    unitsEl.oninput = () => { syncCratesFromUnits(); };

    setCrates(0);
  });

  // Acties
  const bar = document.createElement('div');
  Object.assign(bar.style, { display: 'flex', gap: '.5rem', justifyContent: 'space-between', marginTop: '.8rem', flexWrap:'wrap' });

  const leftBtnWrap = document.createElement('div');
  leftBtnWrap.style.display = 'flex';
  leftBtnWrap.style.gap = '.5rem';

  const btnLoad = document.createElement('button');
  btnLoad.textContent = '📥 Bestelling ophalen';
  btnInfo(btnLoad);
  btnLoad.onclick = () => {
    document.querySelectorAll('.modal').forEach(m => m.remove());
    if (typeof openBestellingModal === 'function') {
      openBestellingModal();
    } else {
      alert('📥 Bestelling ophalen modal niet gevonden.');
    }
  };
  leftBtnWrap.appendChild(btnLoad);

  const rightBtnWrap = document.createElement('div');
  rightBtnWrap.style.display = 'flex';
  rightBtnWrap.style.gap = '.5rem';

  const btnConfirm = document.createElement('button');
  btnConfirm.textContent = '✅ Opslaan in voorraad';
  btnPrimary(btnConfirm);

  btnConfirm.onclick = async () => {
    const bus = busSel.value;
    if (!bus) { showAlert('⚠️ Kies eerst een bus.', 'warning'); return; }

    db.voorraad = db.voorraad || {};
    db.voorraad[bus] = db.voorraad[bus] || {};

    let totalUnitsAdded = 0;
    Array.from(list.children).forEach((row, i) => {
      const p = db.producten[i];
      if (!p) return;
      const unitsEl = row.querySelector('[data-units]');
      const units = Math.max(0, parseInt(unitsEl.value, 10) || 0);
      if (units > 0) {
        const curr = Number(db.voorraad[bus][p.naam] || 0);
        db.voorraad[bus][p.naam] = curr + units;
        totalUnitsAdded += units;
      }
    });

    try {
      await saveVoorraad();
      showAlert(`✅ ${totalUnitsAdded} stuks toegevoegd aan ${bus}.`, 'success');
      modal.remove();
      if (typeof toonVoorraadModal === 'function') setTimeout(() => toonVoorraadModal(), 30);
    } catch (e) {
      console.error(e);
      showAlert('❌ Opslaan voorraad mislukt.', 'error');
    }
  };

  const btnCancel = document.createElement('button');
  btnCancel.textContent = '❌ Annuleren';
  btnDanger(btnCancel);
  btnCancel.onclick = () => { modal.remove(); };

  rightBtnWrap.append(btnConfirm, btnCancel);
  bar.append(leftBtnWrap, rightBtnWrap);
  content.appendChild(bar);

  // Sluitknop in hoek
  const closeTop = document.createElement('button');
  closeTop.textContent = '✕';
  Object.assign(closeTop.style, {
    position:'absolute', top:'10px', right:'12px', background:'#FFC500', color:'#1b1b1b',
    border:'none', borderRadius:'8px', padding:'.25rem .5rem', fontWeight:'900'
  });
  closeTop.onclick = () => modal.remove();
  content.appendChild(closeTop);

  modal.appendChild(content);
  document.body.appendChild(modal);
}

// ===== Public: Bestelling (dummy loader) =====
export function openBestellingModal() {
  document.querySelectorAll('.modal').forEach(m => m.remove());

  const modal = document.createElement('div');
  modal.className = 'modal';
  Object.assign(modal.style, {
    position:'fixed', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
    background:'rgba(0,0,0,.35)', zIndex:9999
  });

  const content = document.createElement('div');
  Object.assign(content.style, {
    background:'#fff', padding:'1rem 1.2rem', borderRadius:'12px',
    width:'min(600px, 94vw)', maxHeight:'80vh', overflowY:'auto',
    boxShadow:'0 8px 24px rgba(0,0,0,0.25)'
  });

  const h2 = document.createElement('h2');
  h2.textContent = '📋 Bestelling ophalen';
  h2.style.marginTop = '0';
  h2.style.color = '#2A9626';
  content.appendChild(h2);

  const lijst = document.createElement('div');
  lijst.style.display = 'flex';
  lijst.style.flexDirection = 'column';
  lijst.style.gap = '.45rem';

  if (!Array.isArray(db.reizen) || !db.reizen.length) {
    const p = document.createElement('p');
    p.textContent = 'Geen geplande reizen gevonden.';
    lijst.appendChild(p);
  } else {
    db.reizen.forEach(reis => {
      const btn = document.createElement('button');
      btn.textContent = `Reis: ${reis.start} → ${reis.end}`;
      btnInfo(btn);
      btn.style.textAlign = 'left';
      btn.onclick = () => {
        modal.remove();
        openInkoopModal();
        setTimeout(() => {
          // Prefill: zet per product #kratten (op basis van crates in reis.bestelling)
          if (Array.isArray(reis.bestelling)) {
            // We zoeken naar inputs in de net geopende inkoop-modal:
            const inoModal = document.querySelector('.modal');
            if (!inoModal) return;
            reis.bestelling.forEach(item => {
              const name = item.product;
              const crates = item.crates || 0;
              const rows = inoModal.querySelectorAll('div[style*="grid-template-columns: 1fr auto auto auto"]');
              // Best-effort mapping: loop producten na in zelfde volgorde:
              db.producten.forEach((p, idx) => {
                if (p.naam === name) {
                  const row = rows[idx];
                  if (!row) return;
                  const cratesEl = row.querySelector('[data-crates]');
                  const unitsEl  = row.querySelector('[data-units]');
                  const pack     = packSize(p.naam);
                  if (cratesEl && unitsEl) {
                    cratesEl.textContent = String(crates);
                    unitsEl.value = String(crates * pack);
                  }
                }
              });
            });
          }
        }, 50);
      };
      lijst.appendChild(btn);
    });
  }

  const back = document.createElement('button');
  back.textContent = '❌ Terug';
  btnDanger(back);
  back.style.marginTop = '.6rem';
  back.onclick = () => { modal.remove(); openInkoopModal(); };

  content.append(lijst, back);
  modal.appendChild(content);
  document.body.appendChild(modal);
}

// Console helpers (optioneel)
window.toonVoorraadModal = toonVoorraadModal;
window.openInkoopModal = openInkoopModal;
window.openBestellingModal = openBestellingModal;