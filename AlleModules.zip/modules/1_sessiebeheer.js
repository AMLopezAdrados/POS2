// modules/1_sessiebeheer.js

import { verkoopManager } from './16_VerkoopManager.js';
import { loadData, db } from './3_data.js';
import { toonVerkoopKnoppen } from './8_verkoopscherm.js';

window.actieveSessieRef = null; // { eventKey, sessieId }
window.actieveSessie = null;

// ---------- helpers ----------
function setActieveSessieRef(eventKey, sessieId) {
  window.actieveSessieRef = { eventKey: String(eventKey), sessieId: String(sessieId) };
  try {
    localStorage.setItem('actieveSessieRef', JSON.stringify(window.actieveSessieRef));
  } catch (e) {
    console.warn('Kon actieveSessieRef niet opslaan:', e);
  }
}

function clearActieveSessieRef() {
  window.actieveSessieRef = null;
  window.actieveSessie = null;
  try { localStorage.removeItem('actieveSessieRef'); } catch(e){}
}

function readStoredRef() {
  try {
    var raw = localStorage.getItem('actieveSessieRef');
    return raw ? JSON.parse(raw) : null;
  } catch(e) {
    return null;
  }
}

function uniqueKeysFromDb() {
  var keys = [];
  if (db && Array.isArray(db.evenementen)) {
    for (var i = 0; i < db.evenementen.length; i++) {
      var ev = db.evenementen[i] || {};
      var k = String(ev.id || ev.naam || '').trim();
      if (k && keys.indexOf(k) === -1) keys.push(k);
    }
  }
  return keys;
}

// ---------- sessie herstel ----------
function restoreActieveSessieRef() {
  var ref = readStoredRef();
  if (!ref) return Promise.resolve();

  return verkoopManager.getSession(ref.eventKey, ref.sessieId).then(function(sessie){
    window.actieveSessieRef = ref;
    window.actieveSessie = sessie;
    console.log('✅ Herstelde actieve sessie', ref.sessieId, 'voor', ref.eventKey);
  }).catch(function(e){
    console.warn('❌ Kan actieve sessie niet herstellen:', e);
    clearActieveSessieRef();
  });
}

// ---------- sessie starten/sluiten ----------
export function startSession(eventKey, meta) {
  meta = meta || {};
  return verkoopManager.createSession(eventKey, meta).then(function(sessie){
    window.actieveSessie = sessie;
    setActieveSessieRef(eventKey, sessie.id);
    toonVerkoopKnoppen();
  }).catch(function(err){
    // Fallback: lokale sessie
    var fakeId = 'local-' + Date.now();
    var sessie = {
      id: fakeId,
      eventKey: String(eventKey),
      startTime: new Date().toISOString(),
      endTime: 'OPEN',
      meta: meta
    };
    window.actieveSessie = sessie;
    setActieveSessieRef(eventKey, fakeId);
    console.warn('ℹ️ createSession niet beschikbaar; lokale sessie gestart:', fakeId, err);
    toonVerkoopKnoppen();
  });
}

export function closeActiveSession() {
  if (!window.actieveSessieRef) {
    console.warn('Geen actieve sessie om te sluiten.');
    return Promise.resolve();
  }
  var ref = window.actieveSessieRef;
  return verkoopManager.closeSession(ref.eventKey, ref.sessieId).then(function(){
    clearActieveSessieRef();
    toonVerkoopKnoppen();
  }).catch(function(err){
    console.warn('ℹ️ closeSession niet beschikbaar; lokale sessie gewist.', err);
    clearActieveSessieRef();
    toonVerkoopKnoppen();
  });
}

// ---------- open sessie check ----------
function checkOpenstaandeSessieBijStart() {
  if (window.actieveSessieRef && window.actieveSessie) {
    console.log('📦 Actieve sessie gevonden in geheugen');
    toonVerkoopKnoppen();
    return Promise.resolve();
  }

  var ref = readStoredRef();
  if (!ref) {
    console.log('ℹ️ Geen open sessie gevonden bij start');
    return Promise.resolve();
  }

  return verkoopManager.getSession(ref.eventKey, ref.sessieId).then(function(sessie){
    if (sessie && String(sessie.endTime) === 'OPEN') {
      window.actieveSessieRef = ref;
      window.actieveSessie = sessie;
      console.log('✅ Actieve sessie hersteld bij start');
      toonVerkoopKnoppen();
    } else {
      console.log('ℹ️ Bewaarde sessie is niet OPEN, opruimen');
      clearActieveSessieRef();
    }
  }).catch(function(){
    console.log('ℹ️ Bewaarde sessie niet gevonden, opruimen');
    clearActieveSessieRef();
  });
}

// ---------- app init ----------
export function initApp() {
  // auth check
  var gebruiker = null;
  try { gebruiker = JSON.parse(localStorage.getItem('gebruiker')); } catch(e){}
  if (!gebruiker) {
    window.location.href = '/login.html';
    return;
  }

  // 1) basisdata laden
  return loadData().then(function(){
    // 2) lijst events bepalen: gebruik listEvents() als die bestaat, anders db
    var hasList = verkoopManager && typeof verkoopManager.listEvents === 'function';
    var p = hasList ? verkoopManager.listEvents().catch(function(){ return []; }) : Promise.resolve([]);

    return p.then(function(serverKeys){
      var keys = Array.isArray(serverKeys) && serverKeys.length ? serverKeys : uniqueKeysFromDb();
      // manifesten warmen (stil falen oké)
      var reqs = keys.map(function(k){
        return verkoopManager.getManifest(k).catch(function(e){
          console.warn('Manifest ophalen mislukt voor', k, e);
          return null;
        });
      });
      return Promise.all(reqs);
    });
  }).then(function(){
    // 3) sessie herstel
    return restoreActieveSessieRef();
  }).then(function(){
    // 4) open sessie check
    return checkOpenstaandeSessieBijStart();
  }).catch(function(e){
    console.error('Init error:', e);
  });
}

// auto-start
initApp();

// ---------- exports voor externe helpers ----------
export {
  setActieveSessieRef,
  clearActieveSessieRef,
  restoreActieveSessieRef,
  checkOpenstaandeSessieBijStart
};