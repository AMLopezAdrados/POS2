// 📦 autoRefresh.js

import { loadData, db } from './3_data.js';
import { toonVerkoopKnoppen } from './8_verkoopscherm.js';

let intervalId = null;
let vorigeUSD = null;
let vorigeEUR = null;

/**
 * Start een interval dat elke 5 seconden:
 * - data herlaadt
 * - verkoopknoppen opnieuw tekent
 * - omzetkaart bijwerkt met animatie als data verandert
 */
export function startAutoRefresh() {
  if (intervalId) return;

  intervalId = setInterval(async () => {
    console.log('🔄 Auto-refresh gestart...');
    await loadData();
    toonVerkoopKnoppen();

    const ref = window.actieveSessieRef;
    if (!ref?.eventId || !ref?.sessieId) return;

    const nieuwEvent = db.evenementen.find(e => e.id === ref.eventId);
    const nieuweSessie = nieuwEvent?.sessions?.find(s => s.id === ref.sessieId);
    if (!nieuwEvent || !nieuweSessie) return;

    // Update actieve referentie na data herladen
    window.actieveSessieRef.event = nieuwEvent;
    window.actieveSessieRef.sessie = nieuweSessie;
    nieuweSessie._parentEvent = nieuwEvent;

    // Bereken omzet
    const omzetUSD = nieuweSessie.verkopen?.reduce((t, v) => t + (v.prijs_usd || 0), 0) || 0;
    const omzetEUR = nieuweSessie.verkopen?.reduce((t, v) => t + (v.prijs_eur || 0), 0) || 0;

    const gewijzigd = (omzetUSD !== vorigeUSD || omzetEUR !== vorigeEUR);
    if (gewijzigd) {
      vorigeUSD = omzetUSD;
      vorigeEUR = omzetEUR;

      const card = document.getElementById('omzetCard');
      if (typeof window.updateOmzetCard === 'function') {
        window.updateOmzetCard();
      }

      if (card) {
        card.style.transition = 'none';
        card.style.boxShadow = '0 0 0 4px #FFC500';
        setTimeout(() => {
          card.style.transition = 'box-shadow 0.8s ease';
          card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
        }, 50);
      }
    }
  }, 5000);
}

/** Stop de auto-refresh en reset state */
export function stopAutoRefresh() {
  if (!intervalId) return;
  clearInterval(intervalId);
  intervalId = null;
  vorigeUSD = null;
  vorigeEUR = null;
  console.log('⏹️ Auto-refresh gestopt.');
}