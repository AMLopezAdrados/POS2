// 📦 10_snijkaas.js – Snijkaas-registratie via verkoopManager (offline-first compatible)

import { db, saveVoorraad } from './3_data.js';
import { showAlert } from './4_ui.js';
import { toonVerkoopKnoppen } from './8_verkoopscherm.js';
import { verkoopManager } from './16_VerkoopManager.js';

let snijkaasTelling = {};

export function initSnijkaasKnop() {
  document.getElementById("snijkaasBtn")?.remove();

  const btn = document.createElement("button");
  btn.id = "snijkaasBtn";
  btn.textContent = "🔪 Snijkaas";
  btn.className = "rood";
  btn.style.position = "fixed";
  btn.style.bottom = "1rem";
  btn.style.left = "1rem";
  btn.onclick = openSnijkaasModal;
  document.body.appendChild(btn);
}

export function openSnijkaasModal() {
  if (!window.actieveSessieRef?.event || !window.actieveSessieRef?.sessie) {
    showAlert("❌ Geen actieve sessie gevonden.", "error");
    return;
  }

  snijkaasTelling = {};

  const overlay = document.createElement("div");
  overlay.className = "modal";
  overlay.id = "snijkaasOverlay";
  Object.assign(overlay.style, {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.3)",
    backdropFilter: "blur(3px)",
    zIndex: 9998
  });

  const modal = document.createElement("div");
  modal.id = "snijkaasModal";
  Object.assign(modal.style, {
    position: "fixed",
    top: "5vh",
    left: "50%",
    transform: "translateX(-50%)",
    width: "90vw",
    maxWidth: "600px",
    maxHeight: "88vh",
    overflowY: "auto",
    background: "#fff",
    borderRadius: "12px",
    padding: "2rem",
    zIndex: 9999,
    boxShadow: "0 8px 20px rgba(0,0,0,0.2)"
  });

  const toegestaneTypes = ["BG", "ROOK", "GEIT", "OUD"];
  const producten = db.producten.filter(p => toegestaneTypes.includes(p.type?.toUpperCase()));

  modal.innerHTML = `
    <h2>🔪 Snijkaas Registratie</h2>
    <p>Voer in hoeveel er van elk product gesneden is.</p>
    <table style="width:100%; border-collapse:collapse; margin-top:1rem;">
      <thead><tr><th style="text-align:left;">Product</th><th style="text-align:right;">Aantal</th><th>Voorraad</th></tr></thead>
      <tbody id="snijkaasBody">
        ${producten.map(p => {
            const voorraad = db.voorraad?.[window.actieveSessieRef.event.bus]?.[p.naam] || 0;
            return `
              <tr>
                <td>${p.naam}</td>
                <td>
                  <button onclick="window.verlaagSnijkaas('${p.naam}')">−</button>
                  <span id="teller-${p.naam}">0</span>
                  <button onclick="window.verhoogSnijkaas('${p.naam}')">+</button>
                </td>
                <td style="text-align:right;">${voorraad}</td>
              </tr>
            `;
          }).join('')}
      </tbody>
    </table>
    <div style="margin-top:1.5rem;">
      <button class="groen" onclick="window.bevestigSnijkaas()">✔ Bevestigen</button>
      <button onclick="window.sluitSnijkaasModal()">❌ Annuleren</button>
    </div>
  `;

  document.body.appendChild(overlay);
  document.body.appendChild(modal);
}

export function sluitSnijkaasModal() {
  document.getElementById('snijkaasOverlay')?.remove();
  document.getElementById('snijkaasModal')?.remove();
  toonVerkoopKnoppen();
}

export async function bevestigSnijkaas() {
  if (!window.actieveSessieRef?.event || !window.actieveSessieRef?.sessie) {
    showAlert("❌ Geen actieve sessie gevonden.", "error");
    return;
  }

  const telling = {};
  Object.entries(snijkaasTelling).forEach(([naam, aantal]) => {
    if (aantal > 0) telling[naam] = aantal;
  });

  if (Object.keys(telling).length === 0) {
    showAlert("⚠️ Geen snijkaas ingevoerd.", "warning");
    return;
  }

  const busNaam = window.actieveSessieRef.event.bus;
  const busVoorraad = db.voorraad?.[busNaam];
  if (!busVoorraad) {
    showAlert(`❌ Voorraad van bus "${busNaam}" niet gevonden.`, "error");
    return;
  }

  // Maak verkoopentries aan
  const sessieId = window.actieveSessieRef.sessie.id;
  const verkopen = [];
  Object.entries(telling).forEach(([naam, aantal]) => {
    const product = db.producten.find(p => p.naam === naam);
    if (!product) return;
    for (let i = 0; i < aantal; i++) {
      verkopen.push({
        product: naam,
        prijs_usd: 0,
        inkoop: product.inkoop,
        tijd: new Date().toISOString(),
        type: "snijkaas",
        sessieId
      });
      busVoorraad[naam] = (busVoorraad[naam] || 0) - 1;
    }
  });

  try {
    await verkoopManager.addVerkopen(window.actieveSessieRef.event.naam, sessieId, verkopen);
    await saveVoorraad();
    sluitSnijkaasModal();
    showAlert("✅ Snijkaas geregistreerd.", "success");
  } catch (err) {
    console.error("❌ Fout bij opslaan:", err);
    showAlert("⚠️ Fout bij opslaan van snijkaas.", "error");
  }
}

// Interactie (offline safe, memory-based)
window.verhoogSnijkaas = function (naam) {
  snijkaasTelling[naam] = (snijkaasTelling[naam] || 0) + 1;
  const teller = document.getElementById(`teller-${naam}`);
  if (teller) teller.textContent = snijkaasTelling[naam];
};

window.verlaagSnijkaas = function (naam) {
  snijkaasTelling[naam] = Math.max(0, (snijkaasTelling[naam] || 0) - 1);
  const teller = document.getElementById(`teller-${naam}`);
  if (teller) teller.textContent = snijkaasTelling[naam];
};

window.bevestigSnijkaas = bevestigSnijkaas;
window.sluitSnijkaasModal = sluitSnijkaasModal;
